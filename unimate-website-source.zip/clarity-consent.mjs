export const CLARITY_PROJECT='z0wpwx4jy4';
export const CONSENT_KEY='unimate-analytics-consent-v1';
export function eligibleForClarity({hostname,search,hash,signedIn,loading}){
 return ['hellounimate.com','www.hellounimate.com'].includes(hostname)&&!search&&['','#/home','#/'].includes(hash)&&!signedIn&&!loading;
}
let loaded=false;
export function startClarity(){
 if(loaded)return;
 const consent=readConsent();
 if(consent!=='accepted')return;
 loaded=true;
 document.documentElement.setAttribute('data-clarity-mask','true');
 const queue=(...args)=>{queue.q.push(args);};queue.q=[];window.clarity=queue;
 queue('consentv2',{analytics_Storage:'granted',ad_Storage:'denied'});
 const script=document.createElement('script');script.async=true;script.src='https://www.clarity.ms/tag/'+CLARITY_PROJECT;script.dataset.unimateClarity='true';document.head.append(script);
}
export function readConsent(){try{return localStorage.getItem(CONSENT_KEY);}catch{return null;}}
export function saveConsent(value){try{localStorage.setItem(CONSENT_KEY,value);}catch{}if(value==='declined'&&loaded){window.clarity?.('consentv2',{analytics_Storage:'denied',ad_Storage:'denied'});window.clarity?.('stop');window.location.reload();}}
// Leave the recorded document before rendering any account or authentication UI.
export function leaveRecordedHome(nextHash){if(!loaded||['','#/home','#/'].includes(nextHash))return false;window.clarity?.('stop');window.location.hash=nextHash;window.location.reload();return true;}

import React,{useEffect,useRef} from 'react';
import {createLanguagePicker} from './language-picker.mjs';
import './language-picker.css';
import {translateUi} from './ui-i18n.mjs';
export function LanguagePicker({value,onChange,label}:{value:'EN'|'简体'|'繁體';onChange:(value:'EN'|'简体'|'繁體')=>void;label?:string}){
 label=label??translateUi(value,'Language');
 const host=useRef<HTMLDivElement>(null),picker=useRef<ReturnType<typeof createLanguagePicker>|null>(null),callback=useRef(onChange);callback.current=onChange;
 useEffect(()=>{if(!host.current)return;picker.current=createLanguagePicker(host.current,{value,onChange:(next:'EN'|'简体'|'繁體')=>callback.current(next),label});return()=>{picker.current?.destroy();picker.current=null;};},[]);
 useEffect(()=>{picker.current?.update(value,label);},[value,label]);
 return <div ref={host} className="unimate-language-host"/>;
}

import React,{useContext,useEffect,useRef,useState} from 'react';
import {CanonicalServiceForm,PrototypeThemeContext,type ServiceCheckoutOrder} from './PrototypeServiceUI';
import {useAuth} from './auth';
import {WebsiteLanguageContext} from './WebsiteShell';
import {useUiText} from './useUiText';
import {ApiError,apiMessage} from './member-api';
import {photoUpload,type Booking,type BookingDetail} from './bookings-api';
import {prototypeBookingPayload} from './prototype-booking.mjs';
import './prototype-member.css';

/** The original questions and controls, with explicit real-account submission. */
export function PrototypeBooking({service,dark,onBookings,onCreated}:{service:'airport'|'cleaning'|'moving';dark:boolean;onBookings:()=>void;onCreated?:(booking:Booking)=>void}){
 const auth=useAuth(),language=useContext(WebsiteLanguageContext),ui=useUiText();
 const [order,setOrder]=useState<ServiceCheckoutOrder|null>(null),[error,setError]=useState(''),[busy,setBusy]=useState(false),[saved,setSaved]=useState<Booking|null>(null),[uncertain,setUncertain]=useState(false);
 const pendingId=useRef<string|null>(null),photoProgress=useRef(0),generation=useRef(0),review=useRef<HTMLDialogElement>(null);
 useEffect(()=>{const version=++generation.current;setOrder(null);setSaved(null);setError('');setBusy(false);setUncertain(false);pendingId.current=null;photoProgress.current=0;return()=>{if(generation.current===version)generation.current++;};},[auth.user?.id,service]);
 useEffect(()=>{if(order)review.current?.showModal();},[order]);
 function prepare(value:ServiceCheckoutOrder){try{prototypeBookingPayload(value);setError('');setOrder(value);}catch(problem){setError(problem instanceof Error?problem.message:apiMessage(problem));}}
 async function save(){if(!order||busy)return;const version=generation.current;setBusy(true);setError('');try{
   const payload=prototypeBookingPayload(order),uploads=[];
   // Validate every file before creating a booking. Only local picker URIs are accepted.
   for(const [index,uri] of (order.intake?.photos||[]).entries()){
    if(!/^(blob:|data:image\/)/.test(uri))throw Error('Please select your photos again.');
    const blob=await(await fetch(uri)).blob();uploads.push(await photoUpload(new File([blob],`request-${index+1}.${blob.type==='image/png'?'png':blob.type==='image/webp'?'webp':'jpg'}`,{type:blob.type})));
   }
   if(version!==generation.current)return;
   if(!pendingId.current){let result:BookingDetail;try{result=await auth.request<BookingDetail>('/api/member/bookings',{method:'POST',body:payload});}catch(problem){if(problem instanceof ApiError&&(problem.status===0||problem.status>=500))setUncertain(true);throw problem;}if(version!==generation.current)return;pendingId.current=result.row.id;}
   for(let index=photoProgress.current;index<uploads.length;index++){await auth.request('/api/member/bookings/'+encodeURIComponent(pendingId.current)+'/photos',{method:'POST',body:{group:'request',...uploads[index]}});if(version!==generation.current)return;photoProgress.current=index+1;}
   if(version===generation.current){const result=await auth.request<BookingDetail>('/api/member/bookings/'+encodeURIComponent(pendingId.current));if(version!==generation.current)return;if(onCreated)onCreated(result.row);else setSaved(result.row);setOrder(null);}
  }catch(problem){if(version===generation.current)setError((pendingId.current?ui('Your request is saved. Some photos could not be uploaded. Retry to finish without creating another request. '):'')+(problem instanceof Error?problem.message:apiMessage(problem)));}finally{if(version===generation.current)setBusy(false);}}
 return <section className={'prototype-booking '+(dark?'unimate-dark':'unimate-light')}>
  {error&&!order&&<p className="fresh-error" role="alert">{ui(error)}</p>}
  {saved?<div className="fresh-account-panel" role="status"><h1>{ui('Request received')}</h1><p>{ui('Job reference')}: <strong>{saved.reference||saved.id}</strong></p><p>{ui('Quote this job code when contacting UniMate about questions or problems.')}</p><p>{ui('Your answers and photos are saved to your account. The team will confirm availability and a quote. No payment has been taken.')}</p><button className="fresh-button" onClick={onBookings}>{ui('My bookings')}</button></div>:<PrototypeThemeContext.Provider value={dark}><CanonicalServiceForm key={auth.user?.id+service} type={service==='airport'?'Airport transfer':service==='moving'?'Moving':'Cleaning'} language={language} onCheckout={prepare}/></PrototypeThemeContext.Provider>}
  {order&&<dialog ref={review} className="fresh-dialog prototype-request-review" onCancel={event=>{if(busy||pendingId.current)event.preventDefault();else setOrder(null);}} aria-label={ui('Review request')}>
   <h2>{ui('Review request')}</h2><p className="fresh-notice">{ui('This is a service request, not a confirmed booking. The team will confirm availability and the final quote. No payment is taken here.')}</p>
   <dl><div><dt>{ui('Preferred date')}</dt><dd>{order.bookingDate} · {order.bookingTime}</dd></div><div><dt>{ui('Address / route')}</dt><dd>{order.bookingAddress}</dd></div>{order.intake?.fields.map((field,index)=><div key={index}><dt>{ui(field.label)}</dt><dd>{ui(field.value)}</dd></div>)}<div><dt>{ui('Photos')}</dt><dd>{order.intake?.photos.length||0}</dd></div></dl>
   {error&&<p className="fresh-error" role="alert">{ui(error)}</p>}{uncertain&&<p className="fresh-notice">{ui('We could not confirm the response. Check My bookings before submitting again to avoid a duplicate request.')}</p>}
   <div className="fresh-actions"><button className="fresh-button" disabled={busy||uncertain} onClick={()=>void save()}>{ui(busy?'Saving…':pendingId.current?'Retry photo upload':'Send request')}</button><button className="fresh-button fresh-secondary" disabled={busy||!!pendingId.current||uncertain} onClick={()=>setOrder(null)}>{ui('Edit answers')}</button>{(pendingId.current||uncertain)&&<button className="fresh-text-button" disabled={busy} onClick={onBookings}>{ui('My bookings')}</button>}</div>
  </dialog>}
 </section>;
}

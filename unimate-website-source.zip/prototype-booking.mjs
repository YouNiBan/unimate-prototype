/** Preserve every prototype answer in the existing real-booking API. */
export function prototypeBookingPayload(order) {
  if (!order || !['cleaning','moving','airport'].includes(order.service)) throw Error('Choose a service.');
  const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const parts=/^(\d{1,2}) ([A-Z][a-z]{2}) (\d{4})$/.exec(order.bookingDate||'');
  const date=parts?`${parts[3]}-${String(months.indexOf(parts[2])+1).padStart(2,'0')}-${parts[1].padStart(2,'0')}`:order.bookingDate;
  if(!/^\d{4}-\d{2}-\d{2}$/.test(date||'')||new Date(date).toISOString().slice(0,10)!==date)throw Error('Choose a valid preferred date.');
  const fields=order.intake?.fields||[];
  const missing=label=>!fields.find(field=>field.label===label)?.value?.trim()||fields.find(field=>field.label===label)?.value==='Not provided';
  if(order.service==='moving'&&(missing('Pickup address')||missing('Drop-off address'))||order.service==='airport'&&missing('London address'))throw Error('Enter the full address, including the flat or house number and postcode.');
  const address=order.bookingAddress?.trim();
  if(!address||address.length<3||address.length>500)throw Error('Enter a full address or route of up to 500 characters.');
  const notes=[`Preferred time: ${order.bookingTime||order.when||''}`,...fields.map(field=>`${field.label}: ${field.value}`)].join('\n');
  if(notes.length>4000)throw Error('Your answers are too long to save. Shorten the special instructions and try again.');
  return {service:order.service==='airport'?'airport_transfer':order.service,title:order.title,requestedDate:date,address,notes};
}

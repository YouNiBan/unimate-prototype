import React,{useEffect,useState} from 'react';
import {useAuth} from './auth';
export function MemberAvatar({name,src,team=false,banner=false}:{name:string;src?:string|null;team?:boolean;banner?:boolean}){
 const {request,user}=useAuth(),[url,setUrl]=useState('');
 useEffect(()=>{setUrl('');if(!src||!/^\/api\/(?:member\/)?(?:people\/[^/?]+\/(?:avatar|banner)|support\/[^/?]+\/avatar)(?:\?v=\d+)?$/.test(src))return;const c=new AbortController();let object='';void request<Blob>(src,{binary:true,signal:c.signal}).then(blob=>{if(c.signal.aborted||!['image/jpeg','image/png','image/webp'].includes(blob.type)||blob.size>512000)return;object=URL.createObjectURL(blob);setUrl(object);}).catch(()=>{});return()=>{c.abort();if(object)URL.revokeObjectURL(object);};},[src,request,user?.id]);
 return <span className={banner?'member-profile-banner':'member-avatar'+(team?' is-team':'')} aria-label={banner?'Profile banner':name+' profile picture'}>{url?<img src={url} alt="" onError={()=>setUrl('')}/>:!banner&&(team?'U':name.trim().split(/\s+/).slice(0,2).map(v=>v[0]||'').join('').toUpperCase()||'?')}</span>;
}

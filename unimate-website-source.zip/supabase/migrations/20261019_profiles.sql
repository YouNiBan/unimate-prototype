-- Run once in the new UniMate Supabase project. This creates no sample users.
-- Public-facing profile discovery can be added separately with explicit consent.
begin;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '' check (char_length(display_name) <= 80),
  avatar_url text check (avatar_url is null or char_length(avatar_url) <= 2048),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
revoke all on table public.profiles from anon, authenticated;
grant select on table public.profiles to authenticated;
grant insert (id, display_name, avatar_url) on public.profiles to authenticated;
grant update (display_name, avatar_url) on public.profiles to authenticated;

create policy "Read own profile"
  on public.profiles for select to authenticated
  using ((select auth.uid()) = id);

create policy "Create own profile"
  on public.profiles for insert to authenticated
  with check ((select auth.uid()) = id);

create policy "Update own profile"
  on public.profiles for update to authenticated
  using ((select auth.uid()) = id)
  with check ((select auth.uid()) = id);

create function public.unimate_set_profile_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

revoke all on function public.unimate_set_profile_updated_at() from public, anon, authenticated;

create trigger unimate_profile_updated_at
  before update on public.profiles
  for each row execute function public.unimate_set_profile_updated_at();

-- Metadata is suitable for a display name, never for roles or verification.
-- A function-owned insert creates the profile while email confirmation is pending.
create function public.unimate_create_profile()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, left(coalesce(new.raw_user_meta_data ->> 'display_name', ''), 80));
  return new;
end;
$$;

revoke all on function public.unimate_create_profile() from public, anon, authenticated;

create trigger unimate_auth_user_created
  after insert on auth.users
  for each row execute function public.unimate_create_profile();

commit;

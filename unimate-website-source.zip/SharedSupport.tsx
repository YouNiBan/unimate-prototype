import {UniMateSelect} from './UniMateSelect';
import {useUiText,useUiLocale} from './useUiText';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useAuth } from './auth';
import { AppIonicons } from './AppIcons';
import { apiMessage } from './member-api';
import { supportApi, SupportCategory, SupportDetail, SupportDraft, SupportList, SupportStatus, SupportUpload } from './support-api';
import { createSharedChat, createComposerTools } from './shared-chat.mjs';
import './shared-chat.css';

const emptyList: SupportList = { rows: [], total: 0, page: 1, counts: { open: 0, closed: 0 }, unread: 0 };
const categories: [SupportCategory, string][] = [['general', 'General enquiry'], ['booking', 'Booking help'], ['technical', 'Technical help']];

function Conversation({ detail, draft, onSend, onStatus, onPage, onBack, onRefresh, onSeen, loadAttachment }: {
  detail: SupportDetail; draft: SupportDraft;
  onSend: (body: string, clientId: string, attachments: SupportUpload[]) => Promise<void>;
  onStatus: (next: SupportStatus, expected: SupportStatus) => Promise<void>;
  onPage: (page: number) => void; onBack: () => void; onRefresh: () => void; onSeen: () => void;
  loadAttachment: (url: string, signal: AbortSignal) => Promise<Blob>;
}) {
  const locale=useUiLocale();
  const host = useRef<HTMLDivElement>(null);
  const renderer = useRef<ReturnType<typeof createSharedChat> | null>(null);
  useEffect(() => {
    if (!host.current) return;
    renderer.current = createSharedChat(host.current);
    return () => { renderer.current?.destroy(); renderer.current = null; };
  }, []);
  useEffect(() => {
    renderer.current?.update({ ...detail, draft, viewer: 'member', onSend, onStatus, onPage, onBack, onRefresh, loadAttachment });
    // Explicit read acknowledgement only after this selected page has rendered.
    if (renderer.current && detail.page === 1 && document.visibilityState === 'visible') onSeen();
  }, [locale, detail, draft, onSend, onStatus, onPage, onBack, onRefresh, onSeen, loadAttachment]);
  return <div ref={host}/>;
}

function ComposerTools({ input, draft, disabled, onChange, onError, onBusy, onTextChange }: {
  input: React.RefObject<HTMLTextAreaElement | null>; draft: SupportDraft; disabled: boolean;
  onChange: () => void; onError: (message: string) => void; onBusy: (busy: boolean) => void; onTextChange: (value: string) => void;
}) {
  const host = useRef<HTMLDivElement>(null);
  const tools = useRef<ReturnType<typeof createComposerTools> | null>(null);
  useEffect(() => {
    if (!host.current || !input.current) return;
    tools.current = createComposerTools(host.current, { input: input.current, getDraft: () => draft, onChange, onError, onBusy, onTextChange });
    return () => { tools.current?.destroy(); tools.current = null; };
  }, [draft, input, onChange, onError, onBusy, onTextChange]);
  useEffect(() => { tools.current?.setDisabled(disabled); }, [disabled]);
  return <div ref={host}/>;
}

export function SharedSupport({ startNew = false }: { startNew?: boolean } = {}) {
 const ui=useUiText();const locale=useUiLocale();
  const auth = useAuth();
  const api = useMemo(() => supportApi(auth.request), [auth.request]);
  const [list, setList] = useState<SupportList>(emptyList);
  const [selected, setSelected] = useState<string | null>(null);
  const [detail, setDetail] = useState<SupportDetail | null>(null);
  const [status, setStatus] = useState('all');
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(1);
  const [messagePage, setMessagePage] = useState(1);
  const [creating, setCreating] = useState(startNew);
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState<SupportCategory>('general');
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  const [preparing, setPreparing] = useState(false);
  const [, setAttachmentRevision] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [listError, setListError] = useState('');
  const [detailError, setDetailError] = useState('');
  const alive = useRef(true);
  const generation = useRef(0);
  const listRequest = useRef(0);
  const detailRequest = useRef(0);
  const drafts = useRef<Record<string, SupportDraft>>({});
  const readAttempts = useRef(new Set<string>());
  const createAttempt = useRef({ payload: '', clientId: '' });
  const newDraft = useRef<SupportDraft>({ body: '', attachments: [] });
  const newInput = useRef<HTMLTextAreaElement>(null);
  newDraft.current.body = body;
  const attachmentsChanged = useCallback(() => { createAttempt.current = { payload: '', clientId: '' }; setAttachmentRevision(value => value + 1); }, []);
  const currentSelection = useRef(selected);
  currentSelection.current = selected;

  useEffect(() => {
    alive.current = true;
    generation.current++;
    drafts.current = {};
    readAttempts.current.clear();
    createAttempt.current = { payload: '', clientId: '' };
    newDraft.current = { body: '', attachments: [] };
    const linked=new URLSearchParams(window.location.hash.split('?')[1]||'').get('conversation');setList(emptyList); setSelected(linked); setDetail(null);
    setCreating(startNew&&!linked); setSubject(''); setBody(''); setError(''); setListError(''); setDetailError('');
    return () => { alive.current = false; generation.current++; };
  }, [auth.user?.id, auth.sessionVersion, startNew]);

  const refreshList = useCallback(async () => {
    const version = ++listRequest.current, account = generation.current;
    try {
      const result = await api.list(status, query, page);
      if (alive.current && account === generation.current && version === listRequest.current) { setList(result); setListError(''); }
    } catch (failure) {
      if (alive.current && account === generation.current && version === listRequest.current) setListError(apiMessage(failure));
    } finally {
      if (alive.current && account === generation.current && version === listRequest.current) setLoading(false);
    }
  }, [api, status, query, page]);
  const refreshDetail = useCallback(async () => {
    if (!selected) return;
    const version = ++detailRequest.current, account = generation.current;
    try {
      const result = await api.detail(selected, messagePage);
      if (alive.current && account === generation.current && version === detailRequest.current && currentSelection.current === selected) { setDetail(result); setDetailError(''); }
    } catch (failure) {
      if (alive.current && account === generation.current && version === detailRequest.current) setDetailError(apiMessage(failure));
    }
  }, [api, selected, messagePage]);
  const refresh = useCallback(() => { void refreshList(); void refreshDetail(); }, [refreshList, refreshDetail]);
  useEffect(() => { setLoading(true); void refreshList(); }, [refreshList, auth.sessionVersion]);
  useEffect(() => { void refreshDetail(); }, [refreshDetail, auth.sessionVersion]);
  useEffect(() => {
    const poll = () => { if (document.visibilityState === 'visible') refresh(); };
    const timer = setInterval(poll, 15_000);
    document.addEventListener('visibilitychange', poll);
    return () => { clearInterval(timer); document.removeEventListener('visibilitychange', poll); };
  }, [refresh]);
  const select = (id: string) => { setSelected(id); setDetail(null); setMessagePage(1); setCreating(false); setError(''); setDetailError(''); };
  const back = useCallback(() => { setSelected(null); setDetail(null); detailRequest.current++; }, []);
  const onSeen = useCallback(() => {
    if (!detail || detail.page !== 1 || !detail.conversation.unreadCount) return;
    const marker = `${detail.conversation.id}:${detail.messages.at(-1)?.id}`;
    if (readAttempts.current.has(marker)) return;
    readAttempts.current.add(marker);
    const account = generation.current;
    void api.read(detail.conversation.id).then(() => {
      if (alive.current && account === generation.current) void refreshList();
    }).catch(failure => {
      readAttempts.current.delete(marker);
      if (alive.current && account === generation.current) setError(apiMessage(failure));
    });
  }, [api, detail, refreshList]);
  const onSend = useCallback(async (message: string, clientId: string, attachments: SupportUpload[]) => {
    if (!selected) return;
    const account = generation.current;
    await api.send(selected, message, clientId, attachments);
    if (alive.current && account === generation.current && currentSelection.current === selected) {
      setMessagePage(1); await refreshDetail(); await refreshList();
    }
  }, [api, selected, refreshDetail, refreshList]);
  const loadAttachment = useCallback((url: string, signal: AbortSignal) => {
    if (!selected) return Promise.reject(new Error('Attachment unavailable.'));
    return api.attachment(selected, url, signal);
  }, [api, selected]);
  const onStatus = useCallback(async (_next: SupportStatus, expected: SupportStatus) => {
    if (!selected) return;
    const account = generation.current;
    await api.reopen(selected, expected);
    if (alive.current && account === generation.current && currentSelection.current === selected) { await refreshDetail(); await refreshList(); }
  }, [api, selected, refreshDetail, refreshList]);
  const create = async (event: React.FormEvent) => {
    event.preventDefault();
    if (busy || preparing) return;
    const payload = { subject: subject.trim(), category, body: body.trim(), attachments: newDraft.current.attachments || [] };
    const fingerprint = JSON.stringify(payload);
    if (createAttempt.current.payload !== fingerprint) createAttempt.current = { payload: fingerprint, clientId: crypto.randomUUID() };
    const account = generation.current;
    setBusy(true); setError('');
    try {
      const result = await api.create({ ...payload, clientId: createAttempt.current.clientId });
      if (!alive.current || account !== generation.current) return;
      setSubject(''); setBody(''); newDraft.current = { body: '', attachments: [] }; createAttempt.current = { payload: '', clientId: '' };
      select(result.conversation.id); setDetail(result); await refreshList();
    } catch (failure) { if (alive.current && account === generation.current) setError(apiMessage(failure)); }
    finally { if (alive.current && account === generation.current) setBusy(false); }
  };
  const activeDetail = detail?.conversation.id === selected ? detail : null;
  const draft = selected ? (drafts.current[selected] ??= { body: '' }) : null;
  return <section className="support-workspace" aria-label={ui("Support inbox")}>
    <div className="support-workspace-header"><div><h1>{ui("Messages")}</h1><p className="support-workspace-intro">{ui("Your conversations with UniMate Support.")} {auth.mailMode === 'local' ? ui("Local testing.") : ''}</p></div><button className="fresh-button support-compose-button" onClick={() => { setCreating(true); setError(''); }}><span className="support-compose-icon" aria-hidden="true"><AppIonicons name="create-outline" size={16} color="currentColor"/></span><span>{ui("New message")}</span></button></div>
    <p className="support-note">{ui("This inbox is for support enquiries. Friend and group chats are not available yet.")}</p>
    {(error || listError || detailError) && <p className="support-error" role="alert">{ui(error) || detailError || listError}</p>}
    {creating ? <form className="support-new-form" onSubmit={create}>
      <h2>{ui("Contact UniMate Support")}</h2><p className="support-note">{ui("Tell us what you need help with.")}</p>
      <label>{ui("Category")}<UniMateSelect value={category} disabled={busy} onChange={event => setCategory(event.target.value as SupportCategory)}>{categories.map(([id, name]) => <option key={id} value={id}>{name}</option>)}</UniMateSelect></label>
      <label>{ui("Subject")}<input value={subject} onChange={event => setSubject(event.target.value)} minLength={2} maxLength={120} required disabled={busy}/></label>
      <label>{ui("Your message")}<textarea ref={newInput} value={body} onChange={event => setBody(event.target.value)} required={!newDraft.current.attachments?.length} maxLength={4000} disabled={busy}/></label>
      <ComposerTools input={newInput} draft={newDraft.current} disabled={busy} onChange={attachmentsChanged} onError={setError} onBusy={setPreparing} onTextChange={setBody}/>
      <div className="support-new-actions"><button type="button" className="fresh-button fresh-secondary" disabled={busy || preparing} onClick={() => setCreating(false)}>{ui("Back to inbox")}</button><button className="fresh-button" type="submit" disabled={busy || preparing || subject.trim().length < 2 || (!body.trim() && !newDraft.current.attachments?.length)}>{busy ? ui("Sending…") : preparing ? ui("Preparing files…") : ui("Send message")}</button></div>
    </form> : <div className={`support-inbox${selected ? ' has-selection' : ''}`}>
      <div className="support-inbox-list">
        <form className="support-inbox-search" onSubmit={event => { event.preventDefault(); setQuery(search.trim()); setPage(1); }}><input type="search" aria-label={ui("Search support conversations")} placeholder={ui("Search conversations")} maxLength={100} value={search} onChange={event => setSearch(event.target.value)}/><button type="submit">{ui("Search")}</button></form>
        <div className="support-inbox-tools" aria-label={ui("Conversation status")}>{(['all', 'open', 'closed'] as const).map(value => <button key={value} aria-pressed={status === value} onClick={() => { setStatus(value); setPage(1); }}>{value[0].toUpperCase() + value.slice(1)}{value !== 'all' ? ` (${list.counts[value]})` : ''}</button>)}<button className="support-refresh" onClick={refresh}>{ui("Refresh")}</button></div>
        {loading && <p className="support-note" role="status">{ui("Loading conversations…")}</p>}
        <div className="support-conversation-list">{list.rows.map(row => <button className="support-conversation" key={row.id} aria-pressed={selected === row.id} onClick={() => select(row.id)}><strong>{row.subject}{row.unreadCount > 0 && <span className="support-unread" aria-label={`${row.unreadCount} unread messages`}>{row.unreadCount}</span>}</strong><small>{row.reference && <>{row.reference} · </>}{ui(row.teamName||"UniMate Support")} · {row.status === 'open' ? ui("Open") : ui("Closed")}</small><p>{row.lastMessage || ui("No messages yet")}</p></button>)}</div>
        {!loading && !list.rows.length && <p className="support-note">{query || status !== 'all' ? ui("No conversations match this filter.") : ui("No conversations yet. Start a new message when you need help.")}</p>}
        <div className="support-list-pager">{page > 1 && <button onClick={() => setPage(page - 1)}>{ui("Previous")}</button>}{page * 25 < list.total && <button onClick={() => setPage(page + 1)}>{ui("Next")}</button>}</div>
      </div>
      <div className="support-conversation-view">{activeDetail && draft ? <Conversation key={activeDetail.conversation.id} detail={activeDetail} draft={draft} onSend={onSend} onStatus={onStatus} onPage={setMessagePage} onBack={back} onRefresh={refresh} onSeen={onSeen} loadAttachment={loadAttachment}/> : <div className="support-inbox-placeholder">{selected ? ui("Loading conversation…") : ui("Choose a conversation, or start a new message.")}{selected && <button className="fresh-text-button" onClick={back}>{ui("Back to inbox")}</button>}</div>}</div>
    </div>}
  </section>;
}

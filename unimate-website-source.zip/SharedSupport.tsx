import {UniMateSelect} from './UniMateSelect';
import {useUiText,useUiLocale} from './useUiText';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useAuth } from './auth';
import { AppIonicons } from './AppIcons';
import {MemberAvatar} from './MemberAvatar';
import { apiMessage } from './member-api';
import { supportApi, SupportCategory, SupportDetail, SupportDraft, SupportList, SupportStatus, SupportUpload } from './support-api';
import { createSharedChat, createComposerTools } from './shared-chat.mjs';
import './shared-chat.css';

const emptyList: SupportList = { rows: [], total: 0, page: 1, counts: { open: 0, closed: 0 }, unread: 0 };
const categories: [SupportCategory, string][] = [['general', 'General enquiry'], ['booking', 'Booking help'], ['technical', 'Technical help']];

function Conversation({ detail, draft, onSend, onStatus, onPage, onBack, onRefresh, onSeen, loadAttachment }: {
  detail: SupportDetail; draft: SupportDraft;
  onSend: (body: string, clientId: string, attachments: SupportUpload[]) => Promise<void>;
  onStatus: (next: SupportStatus, expected: SupportStatus) => Promise<void>;
  onPage: (page: number) => void; onBack: () => void; onRefresh: () => void; onSeen: () => void;
  loadAttachment: (url: string, signal: AbortSignal) => Promise<Blob>;
}) {
  const locale=useUiLocale(),auth=useAuth();
  const host = useRef<HTMLDivElement>(null);
  const renderer = useRef<ReturnType<typeof createSharedChat> | null>(null);
  useEffect(() => {
    if (!host.current) return;
    renderer.current = createSharedChat(host.current);
    return () => { renderer.current?.destroy(); renderer.current = null; };
  }, []);
  useEffect(() => {
    renderer.current?.update({ ...detail, draft, viewer: 'member', viewerId:auth.user?.id, loadAvatar:(url:string,signal:AbortSignal)=>{if(!/^\/api\/member\/(?:people\/[^/?]+\/avatar|support\/[^/?]+\/avatar)(?:\?v=\d+)?$/.test(url))throw Error('Photo unavailable.');return auth.request<Blob>(url,{binary:true,signal});}, onSend, onStatus, onPage, onBack, onRefresh, loadAttachment });
    // Explicit read acknowledgement only after this selected page has rendered.
    if (renderer.current && detail.page === 1 && document.visibilityState === 'visible') onSeen();
  }, [locale, detail, draft, onSend, onStatus, onPage, onBack, onRefresh, onSeen, loadAttachment]);
  return <div ref={host} className="shared-chat-mount"/>;
}

function ComposerTools({ input, draft, disabled, onChange, onError, onBusy, onTextChange }: {
  input: React.RefObject<HTMLTextAreaElement | null>; draft: SupportDraft; disabled: boolean;
  onChange: () => void; onError: (message: string) => void; onBusy: (busy: boolean) => void; onTextChange: (value: string) => void;
}) {
  const host = useRef<HTMLDivElement>(null);
  const tools = useRef<ReturnType<typeof createComposerTools> | null>(null);
  useEffect(() => {
    if (!host.current || !input.current) return;
    tools.current = createComposerTools(host.current, { input: input.current, getDraft: () => draft, onChange, onError, onBusy, onTextChange });
    return () => { tools.current?.destroy(); tools.current = null; };
  }, [draft, input, onChange, onError, onBusy, onTextChange]);
  useEffect(() => { tools.current?.setDisabled(disabled); }, [disabled]);
  return <div ref={host}/>;
}

export function SharedSupport({ startNew = false }: { startNew?: boolean } = {}) {
 const ui=useUiText();const locale=useUiLocale();
  const auth = useAuth();
  const api = useMemo(() => supportApi(auth.request), [auth.request]);
  const directApi=useMemo(()=>supportApi(auth.request,'direct'),[auth.request]);
  const [channel,setChannel]=useState<'support'|'direct'>('support'),[inboxMode,setInboxMode]=useState('all');
  const selectedApi=channel==='direct'?directApi:api;
  const [list, setList] = useState<SupportList>(emptyList);
  const [selected, setSelected] = useState<string | null>(null);
  const [detail, setDetail] = useState<SupportDetail | null>(null);
  const [status, setStatus] = useState('all');
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(1);
  const [messagePage, setMessagePage] = useState(1);
  const [creating, setCreating] = useState(startNew);
  const [subject, setSubject] = useState('');
  const [jobCode,setJobCode]=useState('');
  const [category, setCategory] = useState<SupportCategory>('general');
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  const [preparing, setPreparing] = useState(false);
  const [, setAttachmentRevision] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [listError, setListError] = useState('');
  const [detailError, setDetailError] = useState('');
  const alive = useRef(true);
  const generation = useRef(0);
  const listRequest = useRef(0);
  const detailRequest = useRef(0);
  const drafts = useRef<Record<string, SupportDraft>>({});
  const readAttempts = useRef(new Set<string>());
  const createAttempt = useRef({ payload: '', clientId: '' });
  const newDraft = useRef<SupportDraft>({ body: '', attachments: [] });
  const newInput = useRef<HTMLTextAreaElement>(null);
  newDraft.current.body = body;
  const attachmentsChanged = useCallback(() => { createAttempt.current = { payload: '', clientId: '' }; setAttachmentRevision(value => value + 1); }, []);
  const currentSelection = useRef(selected);
  currentSelection.current = selected;

  useEffect(() => {
    alive.current = true;
    generation.current++;
    drafts.current = {};
    readAttempts.current.clear();
    createAttempt.current = { payload: '', clientId: '' };
    newDraft.current = { body: '', attachments: [] };
    const params=new URLSearchParams(window.location.hash.split('?')[1]||''),direct=params.get('direct'),linked=direct||params.get('conversation');setChannel(direct?'direct':'support');setList(emptyList); setSelected(linked); setDetail(null);
    setCreating(startNew&&!linked); setSubject(''); setJobCode(''); setBody(''); setError(''); setListError(''); setDetailError('');
    return () => { alive.current = false; generation.current++; };
  }, [auth.user?.id, auth.sessionVersion, startNew]);

  const refreshList = useCallback(async () => {
    const version = ++listRequest.current, account = generation.current;
    try {
      const [support,direct]=await Promise.all([inboxMode==='direct'?Promise.resolve(emptyList):api.list(status,query,page),inboxMode==='support'?Promise.resolve(emptyList):directApi.list()]);
      const directRows=direct.rows.filter(r=>r.audience==='personal'&&status!=='closed'&&(!query||[r.participant.name,r.subject,r.lastMessage].join(' ').toLowerCase().includes(query.toLowerCase())));
      const result:SupportList={...support,rows:[...support.rows.map(r=>({...r,channel:'support' as const})),...directRows.slice((page-1)*25,page*25).map(r=>({...r,channel:'direct' as const}))].sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt)),total:Math.max(support.total,directRows.length),counts:{open:support.counts.open+directRows.length,closed:support.counts.closed},unread:support.unread+direct.unread};
      if (alive.current && account === generation.current && version === listRequest.current) { setList(result); setListError(''); }
    } catch (failure) {
      if (alive.current && account === generation.current && version === listRequest.current) setListError(apiMessage(failure));
    } finally {
      if (alive.current && account === generation.current && version === listRequest.current) setLoading(false);
    }
  }, [api,directApi,inboxMode,status,query,page]);
  const refreshDetail = useCallback(async () => {
    if (!selected) return;
    const version = ++detailRequest.current, account = generation.current;
    try {
      const result = await selectedApi.detail(selected, messagePage);
      if (alive.current && account === generation.current && version === detailRequest.current && currentSelection.current === selected) { setDetail(result); setDetailError(''); }
    } catch (failure) {
      if (alive.current && account === generation.current && version === detailRequest.current) {setDetailError(apiMessage(failure));if((failure as {status?:number}).status===403||(failure as {status?:number}).status===404)setDetail(null);}
    }
  }, [selectedApi, selected, messagePage]);
  const refresh = useCallback(() => { void refreshList(); void refreshDetail(); }, [refreshList, refreshDetail]);
  useEffect(() => { setLoading(true); void refreshList(); }, [refreshList, auth.sessionVersion]);
  useEffect(() => { void refreshDetail(); }, [refreshDetail, auth.sessionVersion]);
  useEffect(() => {
    const poll = () => { if (document.visibilityState === 'visible') refresh(); };
    const timer = setInterval(poll, 15_000);
    document.addEventListener('visibilitychange', poll);
    return () => { clearInterval(timer); document.removeEventListener('visibilitychange', poll); };
  }, [refresh]);
  const select = (id: string,nextChannel:'support'|'direct'='support') => { setChannel(nextChannel);setSelected(id); setDetail(null); setMessagePage(1); setCreating(false); setError(''); setDetailError(''); };
  const back = useCallback(() => { setSelected(null); setDetail(null); detailRequest.current++; }, []);
  const onSeen = useCallback(() => {
    if (!detail || detail.page !== 1 || !detail.conversation.unreadCount) return;
    const marker = `${detail.conversation.id}:${detail.messages.at(-1)?.id}`;
    if (readAttempts.current.has(marker)) return;
    readAttempts.current.add(marker);
    const account = generation.current;
    void selectedApi.read(detail.conversation.id).then(() => {
      if (alive.current && account === generation.current) void refreshList();
    }).catch(failure => {
      readAttempts.current.delete(marker);
      if (alive.current && account === generation.current) setError(apiMessage(failure));
    });
  }, [selectedApi, detail, refreshList]);
  const onSend = useCallback(async (message: string, clientId: string, attachments: SupportUpload[]) => {
    if (!selected) return;
    const account = generation.current;
    await selectedApi.send(selected, message, clientId, attachments);
    if (alive.current && account === generation.current && currentSelection.current === selected) {
      setMessagePage(1); await refreshDetail(); await refreshList();
    }
  }, [selectedApi, selected, refreshDetail, refreshList]);
  const loadAttachment = useCallback((url: string, signal: AbortSignal) => {
    if (!selected) return Promise.reject(new Error('Attachment unavailable.'));
    return selectedApi.attachment(selected, url, signal);
  }, [selectedApi, selected]);
  const onStatus = useCallback(async (_next: SupportStatus, expected: SupportStatus) => {
    if (!selected) return;
    const account = generation.current;
    await api.reopen(selected, expected);
    if (alive.current && account === generation.current && currentSelection.current === selected) { await refreshDetail(); await refreshList(); }
  }, [selectedApi, selected, refreshDetail, refreshList]);
  const create = async (event: React.FormEvent) => {
    event.preventDefault();
    if (busy || preparing) return;
    const payload = { subject: subject.trim(), category, body: body.trim(), attachments: newDraft.current.attachments || [], ...(category==='booking'&&jobCode.trim()?{bookingReference:jobCode.trim().toUpperCase()}:{}) };
    const fingerprint = JSON.stringify(payload);
    if (createAttempt.current.payload !== fingerprint) createAttempt.current = { payload: fingerprint, clientId: crypto.randomUUID() };
    const account = generation.current;
    setBusy(true); setError('');
    try {
      const result = await api.create({ ...payload, clientId: createAttempt.current.clientId });
      if (!alive.current || account !== generation.current) return;
      setSubject(''); setJobCode(''); setBody(''); newDraft.current = { body: '', attachments: [] }; createAttempt.current = { payload: '', clientId: '' };
      select(result.conversation.id); setDetail(result); await refreshList();
    } catch (failure) { if (alive.current && account === generation.current) setError(apiMessage(failure)); }
    finally { if (alive.current && account === generation.current) setBusy(false); }
  };
  const activeDetail = detail?.conversation.id === selected ? detail : null;
  const draft = selected ? (drafts.current[selected] ??= { body: '' }) : null;
  return <section className="support-workspace" aria-label={ui("Support inbox")}>
    <div className="support-workspace-header"><div><h1>{ui("Messages")}</h1><p className="support-workspace-intro">{ui("Your conversations with friends and UniMate teams.")} {auth.mailMode === 'local' ? ui("Local testing.") : ''}</p></div><button className="fresh-button support-compose-button" onClick={() => { setCreating(true); setError(''); }}><span className="support-compose-icon" aria-hidden="true"><AppIonicons name="create-outline" size={16} color="currentColor"/></span><span>{ui("New message")}</span></button></div>
    <p className="support-note">{ui("Personal chats are for friends only. Official UniMate teams handle support and service enquiries.")}</p>
    {!creating&&<nav className="support-channel-tabs" aria-label={ui('Message inboxes')}>{[['all','All messages'],['direct','Friends'],['support','UniMate teams']].map(([value,title])=><button key={value} aria-pressed={inboxMode===value} onClick={()=>{setInboxMode(value);setPage(1);back();}}>{ui(title)}</button>)}</nav>}
    {(error || listError || detailError) && <p className="support-error" role="alert">{ui(error) || detailError || listError}</p>}
    {creating ? <form className="support-new-form" onSubmit={create}>
      <h2>{ui("Contact UniMate Support")}</h2><p className="support-note">{ui("Tell us what you need help with.")}</p>
      <label>{ui("Category")}<UniMateSelect value={category} disabled={busy} onChange={event => setCategory(event.target.value as SupportCategory)}>{categories.map(([id, name]) => <option key={id} value={id}>{name}</option>)}</UniMateSelect></label>
      <label>{ui("Subject")}<input value={subject} onChange={event => setSubject(event.target.value)} minLength={2} maxLength={120} required disabled={busy}/></label>
      {category==='booking'&&<label>{ui('Job code (optional)')}<input value={jobCode} onChange={event=>setJobCode(event.target.value)} placeholder="UM-000001" maxLength={23} pattern="[Uu][Mm]-[0-9]{6,20}" disabled={busy}/><small>{ui('Use the code from your booking. Only your own or assigned jobs can be linked.')}</small></label>}
      <label>{ui("Your message")}<textarea ref={newInput} value={body} onChange={event => setBody(event.target.value)} required={!newDraft.current.attachments?.length} maxLength={4000} disabled={busy}/></label>
      <ComposerTools input={newInput} draft={newDraft.current} disabled={busy} onChange={attachmentsChanged} onError={setError} onBusy={setPreparing} onTextChange={setBody}/>
      <div className="support-new-actions"><button type="button" className="fresh-button fresh-secondary" disabled={busy || preparing} onClick={() => setCreating(false)}>{ui("Back to inbox")}</button><button className="fresh-button" type="submit" disabled={busy || preparing || subject.trim().length < 2 || (!body.trim() && !newDraft.current.attachments?.length)}>{busy ? ui("Sending…") : preparing ? ui("Preparing files…") : ui("Send message")}</button></div>
    </form> : <div className={`support-inbox${selected ? ' has-selection' : ''}`}>
      <div className="support-inbox-list">
        <form className="support-inbox-search" onSubmit={event => { event.preventDefault(); setQuery(search.trim()); setPage(1); }}><input type="search" aria-label={ui("Search support conversations")} placeholder={ui("Search conversations")} maxLength={100} value={search} onChange={event => setSearch(event.target.value)}/><button type="submit">{ui("Search")}</button></form>
        <div className="support-inbox-tools" aria-label={ui("Conversation status")}>{(['all', 'open', 'closed'] as const).map(value => <button key={value} aria-pressed={status === value} onClick={() => { setStatus(value); setPage(1); }}>{value[0].toUpperCase() + value.slice(1)}{value !== 'all' ? ` (${list.counts[value]})` : ''}</button>)}<button className="support-refresh" onClick={refresh}>{ui("Refresh")}</button></div>
        {loading && <p className="support-note" role="status">{ui("Loading conversations…")}</p>}
        <div className="support-conversation-list">{list.rows.map(row=><button className="support-conversation" key={row.channel+row.id} aria-pressed={selected===row.id&&channel===row.channel} onClick={()=>select(row.id,row.channel)}><MemberAvatar name={row.channel==='direct'?row.participant.name:row.teamName||'UniMate Support'} src={row.channel==='direct'?row.participant.avatarUrl:null} team={row.channel!=='direct'}/><span className="support-conversation-copy"><strong>{row.channel==='direct'?row.participant.name:ui(row.teamName||'UniMate Support')}{row.unreadCount>0&&<span className="support-unread" aria-label={`${row.unreadCount} unread messages`}>{row.unreadCount}</span>}</strong><small>{row.audience==='staff_internal'&&<>{ui('Internal staff chat')} · </>}{row.subject}{row.bookingReference&&<> · {row.bookingReference}</>}</small><p>{row.lastMessage||ui('No messages yet')}</p></span><time>{new Date(row.updatedAt).toLocaleDateString(locale,{day:'numeric',month:'short'})}</time></button>)}</div>
        {!loading && !list.rows.length && <p className="support-note">{query || status !== 'all' ? ui("No conversations match this filter.") : ui("No conversations yet. Start a new message when you need help.")}</p>}
        <div className="support-list-pager">{page > 1 && <button onClick={() => setPage(page - 1)}>{ui("Previous")}</button>}{page * 25 < list.total && <button onClick={() => setPage(page + 1)}>{ui("Next")}</button>}</div>
      </div>
      <div className="support-conversation-view">{activeDetail && draft ? <Conversation key={activeDetail.conversation.id} detail={activeDetail} draft={draft} onSend={onSend} onStatus={onStatus} onPage={setMessagePage} onBack={back} onRefresh={refresh} onSeen={onSeen} loadAttachment={loadAttachment}/> : <div className="support-inbox-placeholder">{selected ? ui("Loading conversation…") : ui("Choose a conversation, or start a new message.")}{selected && <button className="fresh-text-button" onClick={back}>{ui("Back to inbox")}</button>}</div>}</div>
    </div>}
  </section>;
}

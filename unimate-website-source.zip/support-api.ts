import { ApiOptions } from './member-api';

export type SupportCategory = 'general' | 'booking' | 'technical';
export type SupportStatus = 'open' | 'closed';
export type SupportConversation = {
  id: string; reference?: string; bookingReference?: string | null; audience?: 'staff_internal' | 'client_team' | 'personal'; channel?:'support'|'direct'; teamName?:string; teamId?:string; subject: string; category: SupportCategory; status: SupportStatus;
  participant: { id: string; name: string; role: 'student' | 'staff'; avatarUrl?:string|null };
  updatedAt: string; lastMessage: string; unreadCount: number; bookingId: string | null;
};
export type SupportUpload = { filename: string; mime: string; base64: string };
export type SupportAttachment = { id: string; filename: string; mime: string; bytes: number; url: string };
export type SupportMessage = {
  id: string; reference?: string; body: string; createdAt: string;
  sender: { id: string; name: string; kind: 'member' | 'support'; avatarUrl?:string|null }; clientId: string; attachments?: SupportAttachment[];
};
export type SupportDetail = { conversation: SupportConversation; messages: SupportMessage[]; total: number; page: number };
export type SupportList = { rows: SupportConversation[]; total: number; page: number; counts: { open: number; closed: number }; unread: number };
export type SupportDraft = { body: string; clientId?: string; attemptBody?: string; attachments?: SupportUpload[] };
export type SupportRequest = <T>(path: string, options?: Omit<ApiOptions, 'csrf'>) => Promise<T>;
const prefix = '/api/member/support';
const item = (id: string) => `${prefix}/${encodeURIComponent(id)}`;
export function privateSupportAttachmentPath(conversationId: string, path: string) {
  const expected = item(conversationId) + '/attachments/';
  if (!path.startsWith(expected) || !/^[a-zA-Z0-9_-]+$/.test(path.slice(expected.length))) throw Error('Attachment unavailable.');
  return path;
}
export function supportApi(request: SupportRequest,channel:'support'|'direct'='support') {
 const prefix='/api/member/'+channel,item=(id:string)=>prefix+'/'+encodeURIComponent(id);
  return {
    list: (status = 'all', q = '', page = 1) => request<SupportList>(`${prefix}?${new URLSearchParams({ status, q, page: String(page) })}`),
    detail: (id: string, page = 1) => request<SupportDetail>(`${item(id)}?page=${page}`),
    create: (body: { subject: string; category: SupportCategory; body: string; clientId: string; bookingId?: string; bookingReference?: string; attachments?: SupportUpload[] }) =>
      request<SupportDetail>(prefix, { method: 'POST', body }),
    send: (id: string, body: string, clientId: string, attachments: SupportUpload[] = []) =>
      request<{ message: SupportMessage; conversation: SupportConversation }>(`${item(id)}/messages`, { method: 'POST', body: { body, clientId, attachments } }),
    attachment: (id: string, path: string, signal?: AbortSignal) => {const expected=item(id)+'/attachments/';if(!path.startsWith(expected)||!/^[-a-zA-Z0-9_]+$/.test(path.slice(expected.length)))throw Error('Attachment unavailable.');return request<Blob>(path,{binary:true,signal});},
    read: (id: string) => request<{ ok: boolean; conversation: SupportConversation }>(`${item(id)}/read`, { method: 'POST', body: {} }),
    reopen: (id: string, expectedStatus: SupportStatus) =>
      request<{ conversation: SupportConversation }>(`${item(id)}/status`, { method: 'POST', body: { status: 'open', expectedStatus } }),
  };
}

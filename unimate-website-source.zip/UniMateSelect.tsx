import React, {useLayoutEffect, useRef} from 'react';
import {enhanceSelect} from './unimate-select.mjs';
import './unimate-select.css';

export function UniMateSelect(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  const select=useRef<HTMLSelectElement>(null),host=useRef<HTMLSpanElement>(null);
  const picker=useRef<ReturnType<typeof enhanceSelect>>(null);
  useLayoutEffect(()=>{
    if(select.current&&host.current)picker.current=enhanceSelect(select.current,host.current);
    return ()=>{picker.current?.destroy();picker.current=null;};
  },[]);
  useLayoutEffect(()=>{picker.current?.refresh();});
  return <span className="unimate-select-host" ref={host}><select {...props} ref={select}/></span>;
}

import type {ServiceCheckoutOrder} from './PrototypeServiceUI';
export function prototypeBookingPayload(order:ServiceCheckoutOrder):{service:'cleaning'|'moving'|'airport_transfer';title:string;requestedDate:string;address:string;notes:string};

export function enhanceSelect(select: HTMLSelectElement, host?: HTMLElement): {refresh():void; destroy():void} | null;
export function installSelects(root: HTMLElement): () => void;

import type { SupportConversation, SupportMessage, SupportDraft, SupportStatus, SupportUpload } from './support-api';
export type SharedChatProps = {
  viewer: 'member' | 'support'; conversation: SupportConversation; messages: SupportMessage[];
  total: number; page: number; draft: SupportDraft;
  onSend: (body: string, clientId: string, attachments: SupportUpload[]) => Promise<void>;
  onStatus: (status: SupportStatus, expectedStatus: SupportStatus) => Promise<void>;
  onPage: (page: number) => void; onBack?: () => void; onRefresh?: () => void;
  loadAttachment?: (url: string, signal: AbortSignal) => Promise<Blob>;
};
export function createSharedChat(container: HTMLElement): { update(props: SharedChatProps): void; destroy(): void };
export function encodeChatAttachments(files: File[], existingCount?: number): Promise<SupportUpload[]>;
export function createComposerTools(container: HTMLElement, options: {
  input: HTMLTextAreaElement; getDraft: () => SupportDraft; onChange?: () => void;
  onError: (message: string) => void; onBusy?: (busy: boolean) => void; onTextChange?: (value: string) => void;
}): { refresh(): void; setDisabled(value: boolean): void; destroy(): void };

export function createComposeIcon(doc: Document): SVGSVGElement;

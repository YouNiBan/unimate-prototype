import {editPhoto} from './photo-editor.mjs';
import React,{useEffect,useRef,useState} from 'react';
import {useAuth} from './auth';
import {useUiLocale,useUiText} from './useUiText';
import {AppIonicons} from './AppIcons';
import {apiMessage} from './member-api';
import {UniMateSelect} from './UniMateSelect';
import {countryCodes} from './StudentOnboarding';
export type EditableProfile={name:string;fullName?:string;birthday:string;country:string;province:string;university?:string;bio?:string;interests?:string[];avatar?:string;banner?:string;revision?:number;profileEditorEnabled?:boolean};
const suggestions=['Travel','Food','Photography','Music','Sports','Films','Gaming','Art','Reading','Nightlife','Volunteering','City walks'];
// Re-encoding strips camera metadata and keeps high-resolution phone photos within a bounded upload.
export async function prepareProfileImage(file:File,banner:boolean):Promise<string>{
 if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw Error('Choose a JPEG, PNG or WebP photo.');
 if(file.size>20*1024*1024)throw Error('Choose a photo up to 20 MB.');
 const url=URL.createObjectURL(file);
 try{const image=await new Promise<HTMLImageElement>((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(Error('This photo could not be opened. Choose another image.'));img.src=url;});
  if(!image.naturalWidth||!image.naturalHeight)throw Error('This photo could not be opened.');
  const canvas=document.createElement('canvas'),ratio=Math.min(1,(banner?1600:1024)/Math.max(image.naturalWidth,image.naturalHeight));canvas.width=Math.max(1,Math.round(image.naturalWidth*ratio));canvas.height=Math.max(1,Math.round(image.naturalHeight*ratio));const ctx=canvas.getContext('2d');if(!ctx)throw Error('Photo editing is unavailable in this browser.');ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);
  for(const quality of [.88,.75,.6,.45]){const result=canvas.toDataURL('image/jpeg',quality);if(result.length<=680000)return result;}
  throw Error('This photo is too detailed. Please choose a smaller photo.');
 }finally{URL.revokeObjectURL(url);}
}
export function ProfileEditor({onSaved}:{onSaved:(profile:EditableProfile)=>void}){
 const {request,refreshSession,user}=useAuth(),ui=useUiText(),locale=useUiLocale();
 const [profile,setProfile]=useState<EditableProfile|null>(null),[error,setError]=useState(''),[notice,setNotice]=useState(''),[busy,setBusy]=useState(false),[processing,setProcessing]=useState(false),[custom,setCustom]=useState(''),[retry,setRetry]=useState(0);
 const banner=useRef<HTMLInputElement>(null),camera=useRef<HTMLInputElement>(null),library=useRef<HTMLInputElement>(null),alive=useRef(true);
 useEffect(()=>{alive.current=true;return()=>{alive.current=false;};},[]);
 useEffect(()=>{const c=new AbortController();void request<EditableProfile>('/api/member/profile',{signal:c.signal}).then(p=>{if(!c.signal.aborted)setProfile({...p,bio:p.bio||'',interests:p.interests||[],avatar:p.avatar||'',banner:p.banner||''});}).catch(e=>{if(!c.signal.aborted)setError(apiMessage(e));});return()=>c.abort();},[request,user?.id,retry]);
 function update<K extends keyof EditableProfile>(key:K,value:EditableProfile[K]){setProfile(p=>p?{...p,[key]:value}:p);setNotice('');}
 async function photo(event:React.ChangeEvent<HTMLInputElement>,key:'avatar'|'banner'){const file=event.target.files?.[0];event.target.value='';if(!file)return;setProcessing(true);setError('');setNotice('');try{const data=await prepareProfileImage(file,key==='banner');if(alive.current)update(key,data);}catch(e){if(alive.current)setError(e instanceof Error?e.message:'Photo upload failed.');}finally{if(alive.current)setProcessing(false);}}
 async function adjust(key:'avatar'|'banner'){if(!profile?.[key])return;setError('');try{const blob=await(await fetch(profile[key]!)).blob();const edited=await editPhoto(new File([blob],key+'.jpg',{type:blob.type}),{aspect:key==='avatar'?'1':'3',circle:key==='avatar'});if(edited&&alive.current)update(key,await prepareProfileImage(edited as File,key==='banner'));}catch(e){setError(e instanceof Error?e.message:'Photo upload failed.');}}
 function toggle(value:string){if(!profile)return;const selected=profile.interests||[];if(selected.includes(value))update('interests',selected.filter(v=>v!==value));else if(selected.length<12)update('interests',[...selected,value]);else setError('Choose up to 12 interests.');}
 function add(){const value=custom.trim();if(!value||!profile)return;if((profile.interests||[]).some(v=>v.toLowerCase()===value.toLowerCase())){setCustom('');return;}if((profile.interests||[]).length>=12){setError('Choose up to 12 interests.');return;}toggle(value);setCustom('');}
 async function save(e:React.FormEvent){e.preventDefault();if(!profile||busy||processing)return;setBusy(true);setError('');setNotice('');try{const result=await request<{profile:EditableProfile}>('/api/member/profile',{method:'POST',body:{name:profile.name,fullName:profile.fullName||undefined,birthday:profile.birthday,country:profile.country,province:profile.province,bio:profile.bio,interests:profile.interests,avatar:profile.avatar,banner:profile.banner,revision:profile.revision||0,draft:true}});setProfile(result.profile);onSaved(result.profile);setNotice('Profile saved.');await refreshSession(true);}catch(e){setError(apiMessage(e));}finally{setBusy(false);}}
 if(!profile)return <div>{error?<><p role="alert" className="fresh-error">{ui(error)}</p><button className="fresh-button" onClick={()=>{setError('');setRetry(v=>v+1);}}>{ui('Try again')}</button></>:<p role="status">{ui('Loading your profile…')}</p>}</div>;
 const countries=new Intl.DisplayNames([locale],{type:'region'}),selected=profile.interests||[],tags=[...new Set([...suggestions,...selected])];
 return <><form className="profile-editor" onSubmit={save}>
 <fieldset disabled={busy||processing||!profile.profileEditorEnabled}>
 {profile.banner&&<img className="profile-editor-banner" src={profile.banner} alt={ui('Profile banner preview')}/>}
 <button className="fresh-button fresh-secondary profile-banner-button" type="button" onClick={()=>banner.current?.click()}><AppIonicons name="image-outline" size={18} color="currentColor"/>{ui('Change profile banner')}</button>
 <input ref={banner} type="file" accept="image/jpeg,image/png,image/webp" hidden aria-label={ui('Choose profile banner')} onChange={e=>void photo(e,'banner')}/>
 {profile.banner&&<button type="button" className="fresh-text-button" onClick={()=>void adjust('banner')}>Adjust banner</button>}{profile.banner&&<button type="button" className="fresh-text-button" onClick={()=>update('banner','')}>{ui('Remove banner')}</button>}
 <div className="profile-editor-photo">{profile.avatar?<img src={profile.avatar} alt={ui('Profile photo preview')}/>:<AppIonicons name="camera-outline" size={30} color="currentColor"/>}</div><p className="profile-photo-caption">{ui('Upload or change profile photo')}</p>
 <div className="profile-photo-actions"><button type="button" className="fresh-button fresh-secondary" onClick={()=>camera.current?.click()}><AppIonicons name="camera-outline" size={18} color="currentColor"/>{ui('Camera')}</button><button type="button" className="fresh-button fresh-secondary" onClick={()=>library.current?.click()}><AppIonicons name="images-outline" size={18} color="currentColor"/>{ui('Photo library')}</button></div>
 <input ref={camera} type="file" accept="image/jpeg,image/png,image/webp" capture="user" hidden aria-label={ui('Take profile photo')} onChange={e=>void photo(e,'avatar')}/><input ref={library} type="file" accept="image/jpeg,image/png,image/webp" hidden aria-label={ui('Choose profile photo')} onChange={e=>void photo(e,'avatar')}/>
 {profile.avatar&&<button type="button" className="fresh-text-button" onClick={()=>void adjust('avatar')}>{ui('Adjust profile photo')}</button>}{profile.avatar&&<button type="button" className="fresh-text-button" onClick={()=>update('avatar','')}>{ui('Remove profile photo')}</button>}
 <small className="fresh-muted">{ui('JPEG, PNG or WebP, up to 20 MB. Photos are optimised before saving.')}</small>
 <label>{ui('Full name (private)')}<input required minLength={2} maxLength={80} value={profile.fullName||''} autoComplete="name" placeholder={ui('Your full name, including surname')} onChange={e=>update('fullName',e.target.value)}/><small className="fresh-muted">{ui('For UniMate account records only. Your public display name is separate.')}</small></label>
 <label>{ui('Display name')}<input required minLength={2} maxLength={80} value={profile.name} autoComplete="nickname" onChange={e=>update('name',e.target.value)}/></label>
 <label>{ui('Bio')}<textarea maxLength={500} rows={5} value={profile.bio||''} onChange={e=>update('bio',e.target.value)}/></label>
 <h2>{ui('Student details')}</h2><p className="fresh-muted">{ui('Your birthday is used to calculate your age and is kept private. Your origin details are not shown on your profile.')}</p>
 <label>{ui('Birthday (YYYY-MM-DD)')}<input type="date" min="1900-01-01" max={new Date().toISOString().slice(0,10)} value={profile.birthday} onChange={e=>update('birthday',e.target.value)}/></label>
 <label>{ui('Country of origin')}<UniMateSelect value={profile.country} onChange={e=>update('country',e.target.value)}><option value="">{ui('Choose your country or region')}</option>{profile.country&&!countryCodes.includes(profile.country)&&<option value={profile.country}>{profile.country}</option>}{countryCodes.map(id=>({id,name:countries.of(id)||id})).sort((a,b)=>a.name.localeCompare(b.name,locale)).map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</UniMateSelect></label>
 <label>{ui('Province, city or state')}<input maxLength={100} value={profile.province} onChange={e=>update('province',e.target.value)}/></label>
 <h2>{ui('Hobbies and interests')}</h2><p className="fresh-muted">{ui('Choose up to 12 tags to help like-minded students find you.')}</p><div className="profile-interest-tags">{tags.map(tag=><button type="button" key={tag} aria-pressed={selected.includes(tag)} onClick={()=>toggle(tag)}>{ui(tag)}{selected.includes(tag)&&' ✓'}</button>)}</div>
 <div className="profile-add-interest"><input aria-label={ui('Add another interest')} placeholder={ui('Add another interest')} maxLength={30} value={custom} onChange={e=>setCustom(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'){e.preventDefault();add();}}}/><button type="button" className="fresh-button" aria-label={ui('Add interest')} disabled={!custom.trim()} onClick={add}>+</button></div>
 <button className="fresh-button profile-save" type="submit">{ui(busy?'Saving…':processing?'Preparing photo…':'Save profile')}</button>
 </fieldset>
 {!profile.profileEditorEnabled&&<p className="fresh-notice">{ui('The profile editor is not available on this server yet. No changes have been saved.')}</p>}
 {processing&&<p role="status">{ui('Preparing photo…')}</p>}{error&&<p className="fresh-error" role="alert">{ui(error)}</p>}{notice&&<p className="fresh-notice" role="status">{ui(notice)}</p>}
 </form></>;
}

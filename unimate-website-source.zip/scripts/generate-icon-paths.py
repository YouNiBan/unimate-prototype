"""Regenerate exact SVG outlines from UniMate's original Ionicons font.

Requires fonttools. Runtime website builds use the checked-in JSON and do not
need Python or fonttools.
"""
import json
from pathlib import Path
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.ttLib import TTFont

assets = Path(__file__).resolve().parent.parent / 'assets' / 'icons'
font = TTFont(assets / 'Ionicons.ttf')
glyphs = font.getGlyphSet()
characters = font.getBestCmap()
names = json.loads((assets / 'Ionicons.json').read_text())
paths = {}
for name, codepoint in names.items():
    pen = SVGPathPen(glyphs)
    glyphs[characters[codepoint]].draw(pen)
    paths[name] = pen.getCommands()
(assets / 'ionicons-paths.json').write_text(json.dumps(paths, separators=(',', ':')) + '\n')

// Mechanical extraction of the canonical prototype components. Run from this
// checkout; no fixtures, authentication or simulated checkout are copied.
import ts from 'typescript';
import {readFileSync, writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';

const input=resolve('../unimate-prototype/App.tsx');
const text=readFileSync(input,'utf8');
const program=ts.createProgram([input],{jsx:ts.JsxEmit.ReactJSX,target:ts.ScriptTarget.ESNext,module:ts.ModuleKind.ESNext,skipLibCheck:true});
const source=program.getSourceFile(input),checker=program.getTypeChecker();
const statementFor=node=>{if(node?.getSourceFile()!==source)return null;while(node.parent&&node.parent!==source)node=node.parent;return node.parent===source?node:null;};
const selected=new Set();
const include=statement=>{if(!statement||selected.has(statement))return;selected.add(statement);const visit=node=>{if(ts.isIdentifier(node)){const symbol=checker.getSymbolAtLocation(node);for(const declaration of symbol?.declarations||[])include(statementFor(declaration));}ts.forEachChild(node,visit);};visit(statement);};
for(const name of ['ServiceForm','ServiceCheckoutOrder','DarkModeContext','EventCard','AvailabilityCalendar','SelectField']){
 const declaration=source.statements.find(node=>node.name?.text===name||ts.isVariableStatement(node)&&node.declarationList.declarations.some(item=>item.name.getText(source)===name));
 if(!declaration)throw Error('Missing canonical component: '+name);include(declaration);
}
const hash=createHash('sha256').update(text).digest('hex');
// Production-only copy corrections: no sample address, no simulated checkout,
// and preferred times do not pretend to be confirmed staff availability.
const corrections=[
 ['"University College London · WC1E 6BT"','""'],
 ['"Continue to payment", "继续付款", "繼續付款"','"Review request", "查看服务申请", "查看服務申請"'],
 ['"Review estimate & payment", "查看估价并付款", "查看估價並付款"','"Review request", "查看服务申请", "查看服務申請"'],
 ['"Only times outside staff bookings and blocked hours are shown.", "仅显示员工已有预订和封锁时间之外的时段。", "只顯示員工已有預訂及封鎖時間以外的時段。"','"Choose your preferred time. The team will confirm availability.", "请选择偏好时段，团队将确认是否可预约。", "請選擇偏好時段，團隊將確認是否可預約。"'],
];
const fixture=statement=>ts.isVariableStatement(statement)&&statement.declarationList.declarations.some(item=>['events','friends'].includes(item.name.getText(source)));
let extracted=source.statements.filter(statement=>selected.has(statement)&&!fixture(statement)).map(statement=>statement.getFullText(source)).join('\n');
for(const [before,after] of corrections)extracted=extracted.replaceAll(before,after);
// Replace only the sample-index translation lookup; real event titles/dates and
// venues are user content, not positions in the prototype's three demo records.
extracted=extracted.replaceAll('(typeof events)[number]','CanonicalEvent').replaceAll('(typeof friends)[number]','CanonicalGoingFriend');
extracted=extracted.replace(/  const position = events\.findIndex[\s\S]*?(?=  const soldOut =)/,'  const dates=event.date,places=event.place,tags=event.tag,title=language==="EN"?event.title:(event.zh||event.title);\n  const price=event.price==="Free"?tr(language,"Free","免费","免費"):event.price;\n');
const types='export type CanonicalGoingFriend={username:string;color:string;initials:string;fullName:string};\nexport type CanonicalEvent={title:string;zh:string;date:string;time:string;place:string;price:string;age:string;lastEntry:string;category:string;tag:string;going:number;spotsLeft:number;releaseAt:string;summary:string;image:string};\n';
const output='// Generated from the GitHub prototype App.tsx; do not hand-edit.\n// Source SHA-256: '+hash+'\n'+types+extracted+'\nexport {ServiceForm as CanonicalServiceForm,DarkModeContext as PrototypeThemeContext,EventCard as CanonicalEventCard,AvailabilityCalendar as CanonicalCalendar,SelectField as CanonicalSelect};\nexport type {ServiceCheckoutOrder};\n';
if(/const (events|friends|restaurants|products)\s*=/.test(output))throw Error('Unexpected demo fixtures in service UI');
writeFileSync(resolve('PrototypeServiceUI.tsx'),output);
console.log('Extracted canonical service forms with '+selected.size+' dependency declarations; no demo records.');

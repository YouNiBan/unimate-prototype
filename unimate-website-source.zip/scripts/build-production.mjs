import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';

// Public deployment configuration, never a server credential. Local development
// still uses EXPO_PUBLIC_API_URL from .env.local and does not run this script.
const apiOrigin = new URL(process.env.EXPO_PUBLIC_API_URL?.trim() || 'https://admin.hellounimate.com');
if (apiOrigin.protocol !== 'https:' || apiOrigin.username || apiOrigin.password || apiOrigin.pathname !== '/' || apiOrigin.search || apiOrigin.hash) {
  throw new Error('Production builds require a complete HTTPS account API origin.');
}
const require = createRequire(import.meta.url);
const result = spawnSync(process.execPath, [require.resolve('expo/bin/cli'), 'export', '--platform', 'web'], {
  stdio: 'inherit',
  env: { ...process.env, EXPO_PUBLIC_API_URL: apiOrigin.origin },
});
if (result.error) throw result.error;
process.exitCode = result.status ?? 1;

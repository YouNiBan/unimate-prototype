import {UniMateSelect} from './UniMateSelect';
import {useUiText,useUiLocale} from './useUiText';
import React, { useEffect, useRef, useState } from 'react';
import { useAuth } from './auth';
import { AppIonicons } from './AppIcons';
import { ApiError, apiMessage } from './member-api';
import { bookingPath, bookingPrice, bookingStatus, photoLabels, photoUpload, privatePhotoPath, serviceLabels, type Booking, type BookingDetail, type BookingPhoto, type PhotoGroup, type Service } from './bookings-api';
import './shared-bookings.css';
import {BookingPayment} from './BookingPayment';

const formatDate = (value: string,locale: string) => { const date = new Date(value); return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString(locale, { day: 'numeric', month: 'short', year: 'numeric' }); };
const formatTime = (value: string,locale: string) => { const date = new Date(value); return Number.isNaN(date.getTime()) ? value : date.toLocaleString(locale, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', timeZone: 'Europe/London' }); };
const serviceIcons = { cleaning: 'home', moving: 'cube', airport_transfer: 'car-sport' } as const;
const serviceColors = { cleaning: '#f28a18', moving: '#00a1a7', airport_transfer: '#17a957' };

function PrivatePhoto({ bookingId, photo }: { bookingId: string; photo: BookingPhoto }) {
 const ui=useUiText();const locale=useUiLocale();
  const { request, user } = useAuth();
  const [src, setSrc] = useState('');
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  const [visible, setVisible] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const figure = useRef<HTMLElement>(null);
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    if (typeof IntersectionObserver === 'undefined') { setVisible(true); return; }
    const observer = new IntersectionObserver(entries => { if (entries.some(entry => entry.isIntersecting)) { setVisible(true); observer.disconnect(); } }, { rootMargin: '150px' });
    if (figure.current) observer.observe(figure.current);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (!visible) return;
    let current = true, objectUrl = '';
    const controller = new AbortController();
    setSrc(''); setError('');
    void (async () => {
      try {
        const blob = await request<Blob>(privatePhotoPath(bookingId, photo), { binary: true, signal: controller.signal });
        if (!current) return;
        if (!['image/png', 'image/jpeg', 'image/webp'].includes(blob.type) || !blob.size || blob.size > 5 * 1024 * 1024) throw new ApiError('This photo could not be opened.');
        objectUrl = URL.createObjectURL(blob); setSrc(objectUrl);
      } catch (problem) { if (current) setError(apiMessage(problem)); }
    })();
    return () => { current = false; controller.abort(); if (objectUrl) URL.revokeObjectURL(objectUrl); };
  }, [visible, bookingId, photo.id, photo.url, user?.id, request, attempt]);
  useEffect(() => { if (expanded) dialog.current?.showModal(); }, [expanded]);
  return <figure className="booking-photo" ref={figure}>
    {error ? <div className="booking-photo-placeholder"><AppIonicons name="image-outline" size={25} color="currentColor"/><span>{ui(error)}</span><button type="button" className="fresh-text-button" onClick={() => setAttempt(value => value + 1)}>{ui("Try again")}</button></div> : src ? <button type="button" className="booking-photo-open" onClick={() => setExpanded(true)} aria-label={ui("Enlarge photo")+": "+photo.filename}><img src={src} alt={photo.filename} onError={() => setError('This photo could not be opened.')}/></button> : <div className="booking-photo-placeholder" role="status">{ui("Loading photo…")}</div>}
    <figcaption>{photo.filename}</figcaption>
    {expanded && src && <dialog className="fresh-dialog booking-photo-dialog" ref={dialog} onCancel={() => setExpanded(false)} onClick={event => { if (event.target === event.currentTarget) setExpanded(false); }}><div className="fresh-dialog-heading"><h2>{ui(photoLabels[photo.group])}</h2><button type="button" className="fresh-icon-button" aria-label={ui("Close photo")} onClick={() => setExpanded(false)}><AppIonicons name="close" size={22} color="currentColor"/></button></div><img src={src} alt={photo.filename}/><p className="fresh-muted">{photo.filename}</p></dialog>}
  </figure>;
}
function PhotoSection({ booking, group, canUpload, onSaved }: { booking: Booking; group: PhotoGroup; canUpload: boolean; onSaved: () => Promise<void> }) {
 const ui=useUiText();const locale=useUiLocale();
  const { request, user } = useAuth();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const input = useRef<HTMLInputElement>(null);
  const photos = (booking.photos || []).filter(photo => photo.group === group);
  async function upload(files: File[]) {
    if (!files.length || busy) return;
    setError(''); setSuccess('');
    if (photos.length + files.length > 12) { setError('You can save up to 12 photos for this stage.'); return; }
    setBusy(true);
    let saved = 0;
    try {
      for (const file of files) {
        const payload = await photoUpload(file);
        await request(bookingPath(booking.id) + '/photos', { method: 'POST', body: { group, ...payload } });
        saved += 1;
      }
      setSuccess(saved === 1 ? 'Photo saved.' : `${saved} photos saved.`);
    } catch (problem) { setError((saved ? `${saved} photo${saved === 1 ? '' : 's'} saved. ` : '') + apiMessage(problem)); }
    finally { try { if (saved) await onSaved(); } catch (problem) { setError('Your photo was saved, but the details could not refresh. Reopen this booking to see it. ' + apiMessage(problem)); } setBusy(false); if (input.current) input.current.value = ''; }
  }
  return <section className="booking-photo-section" aria-busy={busy}><div className="booking-section-heading"><h3>{ui(photoLabels[group])} <small>{photos.length}/12</small></h3>{canUpload && <><input ref={input} type="file" accept="image/jpeg,image/png,image/webp" multiple hidden onChange={event => void upload(Array.from(event.target.files || []))}/><button type="button" className="fresh-button fresh-secondary" disabled={busy || photos.length >= 12} onClick={() => input.current?.click()}><AppIonicons name="camera-outline" size={17} color="currentColor"/>{busy ? ui("Uploading…") : ui("Add photos")}</button></>}</div>
    {canUpload && <p className="booking-help">{ui("JPEG, PNG or WebP, up to 5 MB each. Photos are shared with the people handling this booking.")}</p>}
    {error && <p className="fresh-error" role="alert">{ui(error)}</p>}{success && <p className="fresh-success" role="status">{ui(success)}</p>}
    {photos.length ? <div className="booking-photo-grid">{photos.map(photo => <PrivatePhoto key={`${user?.id}:${photo.id}`} bookingId={booking.id} photo={photo}/>)}</div> : <p className="booking-empty-photos">{ui("No photos saved for this stage.")}</p>}
  </section>;
}
function RequestForm({ initialService, onCreated, onCancel }: { initialService?: Service; onCreated: (booking: Booking) => void; onCancel: () => void }) {
 const ui=useUiText();const locale=useUiLocale();
  const { request } = useAuth();
  const [service, setService] = useState<Service>(initialService || 'cleaning');
  const [date, setDate] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  async function submit(event: React.FormEvent) {
    event.preventDefault(); if (busy) return;
    setBusy(true); setError('');
    try {
      const result = await request<BookingDetail>('/api/member/bookings', { method: 'POST', body: { service, requestedDate: date, address: address.trim(), notes: notes.trim() } });
      onCreated(result.row);
    } catch (problem) { setError(apiMessage(problem)); }
    finally { setBusy(false); }
  }
  return <section className="booking-panel"><div className="booking-section-heading"><div><p className="fresh-eyebrow">{ui("PLAN YOUR SERVICE")}</p><h2>{ui("Request a service")}</h2></div><button type="button" className="fresh-text-button" disabled={busy} onClick={onCancel}>{ui("Cancel")}</button></div><p className="fresh-muted">{ui("Tell us what you need. The team will review your request and confirm the quote and availability. No payment is taken here.")}</p>
    <form className="booking-request-form" onSubmit={submit}><div className="booking-form-grid"><label>{ui("Service")}<UniMateSelect value={service} disabled={busy} onChange={event => setService(event.target.value as Service)}>{Object.entries(serviceLabels).map(([value, text]) => <option key={value} value={value}>{ui(text)}</option>)}</UniMateSelect></label><label>{ui("Preferred date")}<input type="date" required value={date} disabled={busy} onChange={event => setDate(event.target.value)}/></label></div><label>{service === 'moving' ? ui("Collection and destination addresses") : service === 'airport_transfer' ? ui("Airport and London address") : ui("Service address")}<textarea required minLength={3} maxLength={500} rows={2} value={address} disabled={busy} onChange={event => setAddress(event.target.value)} placeholder={service === 'moving' ? ui("From… to…") : service === 'airport_transfer' ? ui("Airport, terminal and London address") : ui("Street, building and postcode")}/></label><label>{ui("Details and special instructions")} <span className="booking-help">{ui("Optional")}</span><textarea rows={4} maxLength={4000} value={notes} disabled={busy} onChange={event => setNotes(event.target.value)} placeholder={service === 'cleaning' ? ui("Property size, type of clean and preferred time") : service === 'moving' ? ui("Items to move, access, floors and preferred time") : ui("Flight number, passengers, luggage and preferred time")}/></label><p className="booking-help">{ui("You can add photos once the request has been saved.")}</p>{error && <p className="fresh-error" role="alert">{ui(error)}</p>}<div className="fresh-actions"><button className="fresh-button" type="submit" disabled={busy}>{busy ? ui("Sending request…") : ui("Send request")}<AppIonicons name="arrow-forward" size={17} color="currentColor"/></button></div></form>
  </section>;
}
function BookingView({ booking, onBack, onRefresh, onUpdated }: { booking: Booking; onBack: () => void; onRefresh: () => Promise<void>; onUpdated: (booking: Booking) => void }) {
 const ui=useUiText();const locale=useUiLocale();
  const { user, request } = useAuth();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notes, setNotes] = useState('');
  const [success, setSuccess] = useState('');
  const staff = user?.role === 'staff';
  async function contactTeam(){setBusy(true);try{const d=await request<{conversationId:string}>(bookingPath(booking.id)+'/conversation',{method:'POST',body:{}});window.location.hash='/messages?conversation='+encodeURIComponent(d.conversationId);}catch(e){setError(apiMessage(e));}finally{setBusy(false);}}
  const fields = booking.submission?.intake?.fields || [];
  async function changeStatus(status: 'in_progress' | 'completed') {
    if (busy) return; setBusy(true); setError(''); setSuccess('');
    try {
      const result = await request<BookingDetail>(bookingPath(booking.id) + '/status', { method: 'POST', body: { status, expectedStatus: booking.status, notes: notes.trim() } });
      onUpdated(result.row); setSuccess(status === 'completed' ? 'Service submitted for UniMate review.' : 'Service started.'); setNotes('');
    } catch (problem) { setError(apiMessage(problem)); }
    finally { setBusy(false); }
  }
  return <><button className="fresh-text-button booking-back" type="button" onClick={onBack}><AppIonicons name="arrow-back" size={17} color="currentColor"/>{ui("All")} {staff ? ui("assigned jobs") : ui("bookings")}</button><section className="booking-panel"><div className="booking-detail-heading"><span className="booking-service-icon" style={{ color: serviceColors[booking.service], background: serviceColors[booking.service] + '12' }}><AppIonicons name={serviceIcons[booking.service]} size={27} color="currentColor"/></span><div><p className="fresh-eyebrow">{ui(serviceLabels[booking.service])}</p><h2>{booking.title}</h2><span className={'booking-status booking-status-' + booking.status}>{ui(bookingStatus(booking.status))}</span></div><strong className="booking-price">{ui(bookingPrice(booking))}</strong></div><dl className="booking-facts"><div><dt>{ui("Booking reference")}</dt><dd>{booking.id}</dd></div><div><dt>{ui("Requested by")}</dt><dd>{booking.customer}</dd></div><div><dt>{ui("Request received")}</dt><dd>{formatDate(booking.created_at,locale)}</dd></div><div><dt>{ui("Assigned professional")}</dt><dd>{booking.assignment?.name || ui("Not assigned yet")}</dd></div>{booking.assignment && <div><dt>{ui("Scheduled time · London")}</dt><dd>{formatTime(booking.assignment.starts_at,locale)} – {formatTime(booking.assignment.ends_at,locale)}</dd></div>}{fields.filter(field => typeof field?.label === 'string' && typeof field?.value === 'string').map((field, index) => <div key={index}><dt>{ui(field.label)}</dt><dd>{field.value || '—'}</dd></div>)}</dl>{booking.submissionUnavailable && <p className="fresh-notice">{ui("Some saved request details could not be opened. Contact support if you need help.")}</p>}{booking.pricingStatus === 'unquoted' && <p className="fresh-notice">{ui("Your request is awaiting a quote. The service and price have not been confirmed.")}</p>}
    {!staff&&<section className="booking-progress"><h3>{ui(booking.team?.name||'UniMate Support')}</h3><p>{ui('Your UniMate team manager handles this booking and assigns the professional internally.')}</p><button className="fresh-button" type="button" disabled={busy} onClick={()=>void contactTeam()}>{ui('Message your UniMate team')}</button></section>}
    {!staff&&<BookingPayment bookingId={booking.id} bookingStatus={booking.status} quoted={booking.pricingStatus==='confirmed'}/>}
    {(['request', 'before', 'completion'] as PhotoGroup[]).map(group => <PhotoSection key={group} booking={booking} group={group} canUpload={staff ? group !== 'request' : group === 'request'} onSaved={onRefresh}/>)}
    {staff && ['assigned', 'confirmed', 'in_progress'].includes(booking.status) && <section className="booking-progress"><h3>{ui("Service progress")}</h3><label>{ui("Progress note")} <span className="booking-help">{ui("Optional")}</span><textarea maxLength={2000} rows={2} value={notes} disabled={busy} onChange={event => setNotes(event.target.value)}/></label><button className="fresh-button" disabled={busy} type="button" onClick={() => void changeStatus(booking.status === 'in_progress' ? 'completed' : 'in_progress')}>{busy ? ui("Saving…") : booking.status === 'in_progress' ? ui("Finish & submit for review") : ui("Start service")}</button></section>}{error && <p className="fresh-error" role="alert">{ui(error)}</p>}{success && <p className="fresh-success" role="status">{ui(success)}</p>}
    </section></>;
}
export function SharedBookings({ dashboard = false, initialService }: { dashboard?: boolean; initialService?: Service }) {
 const ui=useUiText();const locale=useUiLocale();
  const { user, request, sessionVersion } = useAuth();
  const [rows, setRows] = useState<Booking[]>([]);
  const [selected, setSelected] = useState<Booking | null>(null);
  const [creating, setCreating] = useState(!!initialService && user?.role === 'student');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [retry, setRetry] = useState(0);
  const account = useRef(user?.id);
  const generation = useRef(0);
  const staff = user?.role === 'staff';
  useEffect(() => {
    account.current = user?.id; const version = ++generation.current;
    const controller = new AbortController();
    setRows([]); setSelected(null); setError(''); setNotice(''); setLoading(true); setCreating(!!initialService && user?.role === 'student');
    if (!user) { setLoading(false); return; }
    void request<{ rows: Booking[] }>('/api/member/bookings', { signal: controller.signal }).then(result => { if (generation.current === version) setRows(result.rows); }).catch(problem => { if (generation.current === version && !controller.signal.aborted) setError(apiMessage(problem)); }).finally(() => { if (generation.current === version) setLoading(false); });
    return () => { generation.current += 1; controller.abort(); };
  }, [user?.id, user?.role, sessionVersion, request, retry, initialService]);
  async function openBooking(id: string) {
    const current = generation.current;
    setLoading(true); setError(''); setNotice('');
    try { const result = await request<BookingDetail>(bookingPath(id)); if (current === generation.current) { setSelected(result.row); setCreating(false); } }
    catch (problem) { if (current === generation.current) setError(apiMessage(problem)); }
    finally { if (current === generation.current) setLoading(false); }
  }
  async function refreshSelected() {
    if (!selected || account.current !== user?.id) return;
    const current = generation.current, id = selected.id;
    const result = await request<BookingDetail>(bookingPath(id));
    if (current === generation.current) { setSelected(result.row); setRows(items => items.map(item => item.id === id ? result.row : item)); }
  }
  function updated(booking: Booking) { if (account.current !== user?.id) return; setSelected(booking); setRows(items => items.map(item => item.id === booking.id ? booking : item)); }
  function created(booking: Booking) { setRows(items => [booking, ...items]); setSelected(booking); setCreating(false); setNotice('Your request has been saved. You can add photos below.'); }
  const active = rows.filter(row => !['completed', 'cancelled'].includes(row.status));
  return <div className="shared-bookings"><div className="fresh-page-heading fresh-heading-row"><div><p className="fresh-eyebrow">{staff ? ui("YOUR WORKSPACE") : ui("YOUR SPACE")}</p><h1>{dashboard ? (user?.name ? `Welcome, ${user.name}` : 'Welcome to UniMate') : staff ? ui("Assigned jobs") : ui("My bookings")}</h1><p className="fresh-muted">{staff ? ui("Your assigned services, details and photos in one place.") : ui("Your service requests, booking details and photos.")}</p></div>{!staff && !creating && !selected && <button className="fresh-button" type="button" onClick={() => { setCreating(true); setNotice(''); }}><AppIonicons name="add" size={19} color="currentColor"/>{ui("Request a service")}</button>}</div>
    {notice && <p className="fresh-success" role="status">{ui(notice)}</p>}{error && <div className="fresh-error" role="alert">{ui(error)} <button className="fresh-text-button" onClick={() => setRetry(value => value + 1)}>{ui("Try again")}</button></div>}
    {loading ? <div className="booking-loading" role="status">{ui("Loading your")} {staff ? ui("jobs") : ui("bookings")}…</div> : creating && !staff ? <RequestForm initialService={initialService} onCreated={created} onCancel={() => setCreating(false)}/> : selected ? <BookingView key={selected.id} booking={selected} onRefresh={refreshSelected} onUpdated={updated} onBack={() => { setSelected(null); setNotice(''); }}/>: <>
      {dashboard && !error && <div className="booking-summary"><div><span>{staff ? ui("Active jobs") : ui("Active requests & bookings")}</span><strong>{active.length}</strong></div><div><span>{ui("Completed services")}</span><strong>{rows.filter(row => row.status === 'completed').length}</strong></div><div><span>{ui("Account")}</span><strong className="booking-account-role">{staff ? ui("Staff") : ui("Student")}</strong></div></div>}
      {!error && (rows.length ? <div className="booking-list">{rows.map(booking => <button key={booking.id} type="button" className="booking-list-item" onClick={() => void openBooking(booking.id)}><span className="booking-service-icon" style={{ color: serviceColors[booking.service], background: serviceColors[booking.service] + '12' }}><AppIonicons name={serviceIcons[booking.service]} size={23} color="currentColor"/></span><span className="booking-list-description"><strong>{booking.title}</strong><span>{staff ? booking.customer + ' · ' : ''}{formatDate(booking.created_at,locale)}</span><span className={'booking-status booking-status-' + booking.status}>{ui(bookingStatus(booking.status))}</span></span><span className="booking-list-price">{ui(bookingPrice(booking))}</span><AppIonicons name="chevron-forward" size={18} color="currentColor"/></button>)}</div> : <div className="fresh-empty"><AppIonicons name="calendar-outline" size={34} color="#1683DF"/><h2>{staff ? ui("No assigned jobs yet") : ui("No bookings yet")}</h2><p className="fresh-muted">{staff ? ui("Bookings will appear here when your team assigns them to you.") : ui("Request a cleaning, moving or airport transfer service to get started.")}</p>{!staff && <button type="button" className="fresh-button fresh-secondary" onClick={() => setCreating(true)}>{ui("Request a service")}</button>}</div>)}
    </>}
  </div>;
}

import React,{useEffect,useRef,useState} from 'react';
import {useAuth} from './auth';
import {useUiText} from './useUiText';
export function ReviewPhoto({photo}:{photo:{url:string;filename:string;group:string;id:string}}){
 const {request,user}=useAuth(),ui=useUiText(),[src,setSrc]=useState(''),[open,setOpen]=useState(false),[zoom,setZoom]=useState(false),dialog=useRef<HTMLDialogElement>(null);
 useEffect(()=>{let active=true,url='';const controller=new AbortController();setSrc('');setOpen(false);if(!/^\/api\/member\/(?:restaurant-review-photos\/[^/]+|restaurants\/[^/]+\/photo|food-reviews\/[^/]+\/photos\/[^/]+)$/.test(photo.url))return;void request<Blob>(photo.url,{binary:true,signal:controller.signal}).then(blob=>{if(!active||!['image/png','image/jpeg','image/webp'].includes(blob.type)||blob.size>(10*1024*1024))return;url=URL.createObjectURL(blob);setSrc(url);}).catch(()=>{});return()=>{active=false;controller.abort();if(url)URL.revokeObjectURL(url);};},[photo.url,request,user?.id]);
 useEffect(()=>{if(open){setZoom(false);dialog.current?.showModal();}},[open]);
 if(!src)return null;
 if(photo.group==='preview'||photo.group==='avatar')return <img src={src} alt={photo.filename} loading="lazy"/>;
 return <><button type="button" className="review-photo-open" aria-label={ui('Expand photo')+': '+photo.filename} onClick={()=>setOpen(true)}><img src={src} alt={photo.filename} loading="lazy"/></button>{open&&<dialog ref={dialog} className="review-photo-viewer" aria-label={ui('Review photo')} onCancel={()=>setOpen(false)} onClose={()=>setOpen(false)}><div className="review-photo-toolbar"><span>{photo.filename}</span><button type="button" aria-pressed={zoom} onClick={()=>setZoom(v=>!v)}>{ui(zoom?'Zoom out':'Zoom in')}</button><button type="button" autoFocus onClick={()=>{dialog.current?.close();setOpen(false);}}>{ui('Close')}</button></div><div className={'review-photo-canvas'+(zoom?' is-zoomed':'')}><img src={src} alt={photo.filename}/></div></dialog>}</>;
}

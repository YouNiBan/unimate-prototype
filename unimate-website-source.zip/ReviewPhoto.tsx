import React,{useEffect,useState} from 'react';
import {useAuth} from './auth';
export function ReviewPhoto({photo}:{photo:{url:string;filename:string;group:string;id:string}}){
 const {request,user}=useAuth(),[src,setSrc]=useState('');
 useEffect(()=>{let active=true,url='';const controller=new AbortController();setSrc('');if(!/^\/api\/member\/(?:restaurants\/[^/]+\/photo|food-reviews\/[^/]+\/photos\/[^/]+)$/.test(photo.url))return;void request<Blob>(photo.url,{binary:true,signal:controller.signal}).then(blob=>{if(!active||!['image/png','image/jpeg','image/webp'].includes(blob.type)||blob.size>(10*1024*1024))return;url=URL.createObjectURL(blob);setSrc(url);}).catch(()=>{});return()=>{active=false;controller.abort();if(url)URL.revokeObjectURL(url);};},[photo.url,request,user?.id]);
 return src?(photo.group==='menu'?<a href={src} target="_blank" rel="noopener noreferrer" aria-label={photo.filename}><img src={src} alt={photo.filename} loading="lazy"/></a>:<img src={src} alt={photo.filename} loading="lazy"/>):null;
}

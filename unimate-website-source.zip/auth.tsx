import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { apiBase, apiMessage, apiRequest, onSessionExpired, type ApiOptions } from './member-api';

export type MemberUser = { id: string; email: string; name: string; role: 'student' | 'staff'; staffTeams: string[]; studentVerified?: boolean; profileComplete?: boolean; badge?: string; permissions?: Record<string,boolean>; requestedAccountType?: string; approvalStatus?: string };
export type AuthResult = { error?: string; needsConfirmation?: boolean };
type MemberSession = { user: MemberUser | null; csrf: string; configured: boolean; registrationEnabled: boolean; mailConfigured: boolean; mailMode?: 'local' | 'smtp' };
type Callback = { action: 'verify' | 'reset'; token: string };
export type AuthContextValue = {
  user: MemberUser | null; loading: boolean; recovery: boolean; verification: boolean; configured: boolean; registrationEnabled: boolean; mailConfigured: boolean; mailMode: 'local' | null; error: string | null; sessionVersion: number;
  signUp: (email: string, password: string, displayName: string, confirmPassword?: string, account?: {accountType: string; service?: string; organisation?: string}) => Promise<AuthResult>;
  signIn: (email: string, password: string) => Promise<AuthResult>;
  requestPasswordReset: (email: string) => Promise<AuthResult>;
  updatePassword: (password: string, confirmPassword?: string) => Promise<AuthResult>;
  verifyEmail: () => Promise<AuthResult>;
  signOut: () => Promise<AuthResult>;
  clearRecovery: () => void;
  refreshSession: (background?: boolean) => Promise<void>;
  request: <T>(path: string, options?: Omit<ApiOptions, 'csrf'>) => Promise<T>;
};
const unavailable = async (): Promise<AuthResult> => ({ error: 'Account services are not connected yet. Please try again later.' });
const AuthContext = createContext<AuthContextValue>({ user: null, loading: false, recovery: false, verification: false, configured: false, registrationEnabled: false, mailConfigured: false, mailMode: null, error: null, sessionVersion: 0, signUp: unavailable, signIn: unavailable, requestPasswordReset: unavailable, updatePassword: unavailable, verifyEmail: unavailable, signOut: unavailable, clearRecovery() {}, async refreshSession() {}, request: apiRequest });
export function readAccountCallback(): Callback | null {
  if (typeof window === 'undefined') return null;
  const params = new URLSearchParams(window.location.search);
  const action = params.get('member_action'), token = params.get('token') || '';
  if ((action === 'verify' || action === 'reset') && /^[A-Za-z0-9_-]{20,512}$/.test(token)) return { action, token };
  return null;
}
export function parseMemberUser(value: unknown): MemberUser | null {
  if (!value || typeof value !== 'object') return null;
  const user = value as Partial<MemberUser>;
  if (typeof user.id !== 'string' || !user.id || typeof user.email !== 'string' || typeof user.name !== 'string' || !['student', 'staff'].includes(user.role || '')) return null;
  return { id: user.id, email: user.email, name: user.name, role: user.role!, studentVerified:user.studentVerified===true,profileComplete:user.profileComplete===true,badge:user.studentVerified===true?'verified_student':'unverified',permissions:user.permissions,requestedAccountType: user.requestedAccountType, approvalStatus: user.approvalStatus, staffTeams: Array.isArray(user.staffTeams) ? user.staffTeams.filter((team): team is string => typeof team === 'string') : [] };
}
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<MemberUser | null>(null);
  const [configured, setConfigured] = useState(false);
  const [registrationEnabled, setRegistrationEnabled] = useState(false);
  const [mailConfigured, setMailConfigured] = useState(false);
  const [mailMode, setMailMode] = useState<'local' | null>(null);
  const verifiedUser = useRef<MemberUser | null>(null);
  const [loading, setLoading] = useState(!!apiBase);
  const [error, setError] = useState<string | null>(null);
  const [callback, setCallback] = useState(readAccountCallback);
  const [sessionVersion, setSessionVersion] = useState(0);
  const csrf = useRef('');
  const alive = useRef(true);
  const generation = useRef(0);
  const sessionIdentity = useRef('');
  const refreshSession = useCallback(async (background = false) => {
    const current = ++generation.current;
    if (!apiBase) { setLoading(false); setConfigured(false); setUser(null); return; }
    if (!background) setLoading(true);
    try {
      const session = await apiRequest<MemberSession>('/api/member/session');
      if (!alive.current || current !== generation.current) return;
      if (typeof session.configured !== 'boolean' || typeof session.csrf !== 'string') throw new Error('Invalid session response');
      const account = parseMemberUser(session.user);
      if (session.user && !account) throw new Error('Invalid account response');
      const identity = JSON.stringify([account?.id, account?.role, account?.staffTeams,account?.studentVerified,account?.profileComplete, session.csrf]);
      if (sessionIdentity.current !== identity) { sessionIdentity.current = identity; setSessionVersion(value => value + 1); }
      csrf.current = session.csrf;
      setConfigured(session.configured && !!session.csrf);
      setRegistrationEnabled(session.registrationEnabled === true);
      setMailConfigured(session.mailConfigured === true);
      setMailMode(session.mailMode === 'local' ? 'local' : null);
      verifiedUser.current = session.configured ? account : null;
      setUser(verifiedUser.current);
      setError(null);
    } catch (problem) {
      if (alive.current && current === generation.current) { csrf.current = ''; verifiedUser.current = null; setConfigured(false); setRegistrationEnabled(false); setMailConfigured(false); setMailMode(null); setUser(null); setError(apiMessage(problem)); setSessionVersion(value => value + 1); }
    } finally { if (alive.current && current === generation.current) setLoading(false); }
  }, []);
  useEffect(() => {
    alive.current = true;
    void refreshSession();
    const remove = onSessionExpired(requestGeneration => { if (requestGeneration !== generation.current) return; generation.current += 1; verifiedUser.current = null; setUser(null); setLoading(false); setSessionVersion(value => value + 1); void refreshSession(true); });
    const focus = () => { if (document.visibilityState === 'visible') void refreshSession(true); };
    if (typeof document !== 'undefined') document.addEventListener('visibilitychange', focus);
    return () => { alive.current = false; generation.current += 1; remove(); if (typeof document !== 'undefined') document.removeEventListener('visibilitychange', focus); };
  }, [refreshSession]);
  const clearRecovery = useCallback(() => {
    setCallback(null);
    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      url.searchParams.delete('member_action'); url.searchParams.delete('token');
      window.history.replaceState(window.history.state, '', url.pathname + url.search + url.hash);
    }
  }, []);
  const request = useCallback(<T,>(path: string, options: Omit<ApiOptions, 'csrf'> = {}) => apiRequest<T>(path, { ...options, csrf: csrf.current, authGeneration: generation.current }), []);
  const mutate = useCallback(async (path: string, body: unknown): Promise<AuthResult> => {
    if (!configured || !csrf.current) return unavailable();
    try { await request(path, { method: 'POST', body }); return {}; }
    catch (problem) { return { error: apiMessage(problem) }; }
  }, [configured, request]);
  const signUp = useCallback(async (email: string, password: string, name: string, confirmPassword = password, account: {accountType: string; service?: string; organisation?: string} = {accountType:'student'}) => {
    if (!registrationEnabled) return { error: 'New accounts are temporarily unavailable.' };
    const result = await mutate('/api/member/signup', { name: name.trim(), email: email.trim(), password, confirmPassword, ...account });
    return result.error ? result : { needsConfirmation: true };
  }, [mutate, registrationEnabled]);
  const signIn = useCallback(async (email: string, password: string) => {
    const result = await mutate('/api/member/login', { email: email.trim(), password });
    if (!result.error) { await refreshSession(); if (!verifiedUser.current) return { error: 'Your session could not be verified. Please sign in again.' }; }
    return result;
  }, [mutate, refreshSession]);
  const requestPasswordReset = useCallback((email: string) => mailConfigured ? mutate('/api/member/forgot-password', { email: email.trim() }) : Promise.resolve({ error: 'Password reset emails are temporarily unavailable.' }), [mutate, mailConfigured]);
  const verifyEmail = useCallback(async () => {
    if (callback?.action !== 'verify') return { error: 'Open the confirmation link from your email to continue.' };
    const result = await mutate('/api/member/verify', { token: callback.token });
    if (!result.error) clearRecovery();
    return result;
  }, [callback, mutate, clearRecovery]);
  const updatePassword = useCallback(async (password: string, confirmPassword = password) => {
    if (callback?.action !== 'reset') return { error: 'Open the password reset link from your email to continue.' };
    const result = await mutate('/api/member/reset-password', { token: callback.token, password, confirmPassword });
    if (!result.error) { clearRecovery(); await refreshSession(); }
    return result;
  }, [callback, mutate, clearRecovery, refreshSession]);
  const signOut = useCallback(async () => {
    const result = await mutate('/api/member/logout', {});
    if (!result.error) { verifiedUser.current = null; setUser(null); setSessionVersion(value => value + 1); await refreshSession(); }
    return result;
  }, [mutate, refreshSession]);
  const value = useMemo(() => ({ user, loading, configured, registrationEnabled, mailConfigured, mailMode, error, sessionVersion, recovery: callback?.action === 'reset', verification: callback?.action === 'verify', signUp, signIn, requestPasswordReset, updatePassword, verifyEmail, signOut, clearRecovery, refreshSession, request }), [user, loading, configured, registrationEnabled, mailConfigured, mailMode, error, sessionVersion, callback, signUp, signIn, requestPasswordReset, updatePassword, verifyEmail, signOut, clearRecovery, refreshSession, request]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export function useAuth(): AuthContextValue { return useContext(AuthContext); }
/** Owner previews reuse app components with a read-only, explicitly scoped data adapter. */
export function ReadOnlyPreviewProvider({user,request,children}:{user:MemberUser;request:AuthContextValue['request'];children:React.ReactNode}){
 const base=useAuth();const deny=async()=>({error:'This is a read-only owner preview.'});
 const value=useMemo(()=>({...base,user,request,loading:false,sessionVersion:0,signUp:deny,signIn:deny,signOut:deny,updatePassword:deny,requestPasswordReset:deny,verifyEmail:deny,refreshSession:async()=>{}}),[base,user,request]);
 return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

import {useUiText} from './useUiText';
import React, { useContext, useEffect, useState } from 'react';
import { AppIonicons, UniMateMomentsIcon } from './AppIcons';
import { useAuth } from './auth';
import { WebsiteLanguageContext, type WebsiteDestination } from './WebsiteShell';
import { translatePublic } from './public-i18n';
import { type Booking, serviceLabels } from './bookings-api';
import './student-dashboard.css';

type Icon = React.ComponentProps<typeof AppIonicons>['name'];
const destinations: { id: WebsiteDestination; title: string; hint: string; icon: Icon; color: string }[] = [
  { id: 'events', title: 'Discover Events', hint: 'Events near you', icon: 'calendar', color: '#ff4657' },
  { id: 'airport', title: 'Airport Transfers', hint: 'Reliable pickups', icon: 'car-sport', color: '#17a957' },
  { id: 'cleaning', title: 'Cleaning Services', hint: 'Approved cleaners', icon: 'home', color: '#f28a18' },
  { id: 'moving', title: 'Student Moves', hint: 'Quotes made simple', icon: 'cube', color: '#00a1a7' },
  { id: 'market', title: 'Student Marketplace', hint: 'Affordable essentials', icon: 'bag-handle', color: '#854ce9' },
  { id: 'food', title: 'Places & Reviews', hint: 'Restaurants & activities', icon: 'restaurant', color: '#e95e32' },
];
const personal: { id: WebsiteDestination; title: string; icon: Icon; color: string }[] = [
  { id: 'bookings', title: 'My bookings', icon: 'receipt', color: '#2487df' },
  { id: 'my-events', title: 'My events', icon: 'calendar', color: '#ff4657' },
  { id: 'listings', title: 'My marketplace', icon: 'bag-handle', color: '#854ce9' },
  { id: 'support', title: 'Support', icon: 'headset', color: '#C98712' },
];

/** The original student home composition, populated only from the member's account. */
export function StudentDashboard({ navigate, layoutPreview = false }: { navigate: (route: WebsiteDestination) => void; layoutPreview?: boolean }) {
 const ui=useUiText();
  const { user, request, sessionVersion } = useAuth();
  const language = useContext(WebsiteLanguageContext);
  const label = (text: string) => translatePublic(language, text);
  const [search, setSearch] = useState('');
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [bookingState, setBookingState] = useState<'loading' | 'ready' | 'error'>('loading');
  useEffect(() => {
    const controller = new AbortController();
    let current = true;
    setBookings([]); setBookingState('loading');
    if (!user) return () => { current = false; controller.abort(); };
    void request<{ rows: Booking[] }>('/api/member/bookings', { signal: controller.signal })
      .then(result => { if (current) { setBookings(result.rows); setBookingState('ready'); } })
      .catch(() => { if (current && !controller.signal.aborted) setBookingState('error'); });
    return () => { current = false; controller.abort(); };
  }, [user?.id, sessionVersion, request]);
  const next = bookings.filter(item => ['assigned', 'confirmed', 'in_progress'].includes(item.status) && item.assignment && Date.parse(item.assignment.starts_at) >= Date.now())
    .sort((a, b) => Date.parse(a.assignment!.starts_at) - Date.parse(b.assignment!.starts_at))[0];
  const pending = bookings.some(item => !['completed', 'cancelled'].includes(item.status));
  const bookingText = bookingState === 'loading' ? 'Checking your bookings…' : bookingState === 'error' ? 'Open your bookings' : next ? serviceLabels[next.service] : pending ? 'View your requests' : 'No upcoming bookings';
  const locale = language === 'EN' ? 'en-GB' : language === '简体' ? 'zh-CN' : 'zh-TW';
  const firstName = user?.name.trim().split(/\s+/)[0];
  const date = new Intl.DateTimeFormat(locale, { timeZone: 'Europe/London', weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date());
  const matches = [...destinations, ...personal.map(item => ({ ...item, hint: 'Your UniMate' }))].filter(item => `${label(item.title)} ${label(item.hint)}`.toLocaleLowerCase().includes(search.trim().toLocaleLowerCase()));
  const tile = (item: typeof destinations[number]) => <button key={item.id} className="student-service" onClick={() => navigate(item.id)}><span className="student-service-icon" style={{ color: item.color, background: item.color + '15' }}><AppIonicons name={item.icon} size={23} color="currentColor"/></span><span><strong>{label(item.title)}</strong><small>{label(item.hint)}</small></span><AppIonicons name="chevron-forward" size={16} color="currentColor"/></button>;
  return <div className="student-dashboard">
    <div className="student-greeting"><p className="student-date">{date} · {label('London')}</p><h1>{firstName ? `${label('Hello')}, ${firstName}` : label('Welcome to UniMate')}</h1><p>{label('Find your people, explore London, feel at home.')}</p></div>
    <label className="fresh-search student-search"><AppIonicons name="search-outline" size={19} color="currentColor"/><input type="search" aria-label={label('Search UniMate')} placeholder={label('Search friends, events, services…')} value={search} onChange={event => setSearch(event.target.value)}/></label>
    {search.trim() ? <section className="student-search-results" aria-label={label('Search results')}><div className="student-section-heading"><h2>{label('Search results')}</h2><button className="fresh-text-button" onClick={() => setSearch('')}>{label('Clear search')}</button></div>{matches.length ? <div className="student-service-grid">{matches.map(tile)}</div> : <p className="fresh-muted">{label('No matches. Try bookings, friends or a service.')}</p>}</section> : <>
      <section className="student-hero"><div><p className="student-hero-kicker">{label('NEW CITY.')}</p><h2>{label('New friends, new adventures.')}</h2><p>{label('Meet people and make the most of your UK journey.')}</p><button onClick={() => navigate('forum')}>{label('Explore the forum')}<AppIonicons name="arrow-forward" size={15} color="currentColor"/></button></div><span className="student-hero-art" aria-hidden="true"><AppIonicons name="business" size={112} color="currentColor"/></span></section>
      <div className="student-shortcuts">
        <section className="student-upcoming"><div className="student-section-heading"><h2>{label('Upcoming Stuff')}</h2></div><button onClick={() => navigate('bookings')}><span className="student-shortcut-icon"><AppIonicons name="ticket-outline" size={21} color="#1683DF"/></span><span><small>{label('Next booking')}</small><strong>{label(bookingText)}</strong>{next && <small>{new Date(next.assignment!.starts_at).toLocaleString(locale, { timeZone: 'Europe/London', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</small>}</span><AppIonicons name="chevron-forward" size={15} color="currentColor"/></button></section>
        <section className="student-moments-section"><div className="student-section-heading"><h2>{label('Moments')}</h2></div><button onClick={() => navigate('friends')}><span className="student-shortcut-icon student-moments"><UniMateMomentsIcon size={25}/></span><span><small>{label('UniMate Moments')}</small><strong>{label('See your friends’ moments')}</strong></span><AppIonicons name="chevron-forward" size={15} color="currentColor"/></button></section>
      </div>
      <section className="student-personal"><div className="student-section-heading"><h2>{label('Your space')}</h2></div><div className="student-personal-links">{personal.map(item => <button key={item.id} onClick={() => navigate(item.id)}><AppIonicons name={item.icon} size={20} color={item.color}/><span>{label(item.title)}</span><AppIonicons name="chevron-forward" size={15} color="currentColor"/></button>)}</div></section>
      <section><div className="student-section-heading"><div><h2>{label('What do you need today?')}</h2><p>{label('Trusted student services in one place')}</p></div></div><div className="student-service-grid">{destinations.map(tile)}</div></section>
      <section className="student-featured"><div className="student-section-heading"><h2>{label('Featured events')}</h2><button className="fresh-text-button" onClick={()=>navigate('events')}>{label('See all')}</button></div>{layoutPreview?<article className="student-event-card"><div className="student-event-cover"><img src="https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=900" alt={ui("London and the River Thames")}/><span className="student-event-tag">{ui("Example event · Layout preview")}</span></div><div className="student-event-body"><div className="student-event-title"><h2>{ui("Thames River Cruise")}</h2><span>{ui("Trips")}</span></div><p className="student-event-example">{ui("Illustrative content from your original app. This is not a live event or ticket offer.")}</p><div className="student-event-details">{([{icon:'calendar-outline',label:'DATE',value:'Sat, 12 Apr'},{icon:'time-outline',label:'TIME',value:'14:00–17:00'},{icon:'log-in-outline',label:'LAST ENTRY',value:'13:45'},{icon:'location-outline',label:'LOCATION',value:'London Eye Pier'}] as const).map(item=><div key={item.label}><AppIonicons name={item.icon} size={22} color="var(--blue)"/><span><small>{ui(item.label)}</small><strong>{ui(item.value)}</strong></span></div>)}</div><div className="student-event-release"><AppIonicons name="calendar-outline" size={23} color="var(--blue)"/><span><strong>{ui("Tickets went on sale")}</strong><small>{ui("18 September · 10:00")}</small></span></div><div className="student-event-footer"><strong>£25 <small>{ui("example")}</small></strong><button className="fresh-button fresh-secondary" onClick={()=>navigate('events')}>{ui("View events")}<AppIonicons name="chevron-forward" size={17} color="currentColor"/></button></div></div></article>:<div className="student-featured-empty"><AppIonicons name="calendar-outline" size={28} color="var(--blue)"/><div><strong>{label('Featured events are coming soon')}</strong><p>{label('The event feed is being connected. Your bookings remain available in Your space.')}</p></div></div>}</section>

    </>}
  </div>;
}

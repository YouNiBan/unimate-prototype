import {useContext} from 'react';
import {WebsiteLanguageContext} from './WebsiteShell';
import {translateUi,languageLocale} from './ui-i18n.mjs';
export function useUiText(){
 const language=useContext(WebsiteLanguageContext);
 return (text:string|number|null|undefined,values:Record<string,string|number>={})=>translateUi(language,text,values);
}
export function useUiLocale(){return languageLocale(useContext(WebsiteLanguageContext));}

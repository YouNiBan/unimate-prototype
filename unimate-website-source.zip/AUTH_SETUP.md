# UniMate accounts and shared bookings — local first

The website now uses the UniMate-owned Node backend in `../unimate-prototype/backend`, rather than Supabase. No Supabase project, browser key or profile migration is required by this frontend. The old migration is retained as historical source only; do not run it for this setup.

The public website connects to the existing Render backend at `https://admin.hellounimate.com`. Production builds embed this origin through `scripts/build-production.mjs`. The backend permits the exact website origin `https://hellounimate.com` and uses secure member cookies. This does not expose or forward the local development service. The original prototype App.tsx remains a separate demo and is not connected by this website implementation.

## Connect the local website

1. Start the backend with its documented local account and mail configuration. Use an isolated local database/media directory for test accounts and photos.
2. Put `EXPO_PUBLIC_API_URL=http://localhost:8090` in the website's ignored `.env.local`. This is a public origin, not a credential. Restart Expo after changing it.
3. Open the website at the exact origin allowed by the backend, normally `http://localhost:8083`. Use the same hostname consistently; do not mix localhost and 127.0.0.1 for cookie-based testing.
4. GET `/api/member/session` must be reachable with credentials and return `configured:true`, an anonymous/user session and a CSRF token. Missing configuration or an unreachable service keeps account forms closed. Registration additionally requires `registrationEnabled:true`; reset email requests require `mailConfigured:true`. Existing sign-in remains available when registration is closed.
5. With the backend's local-only test mailbox enabled, registration and password-reset messages go to the protected admin `/test-mail` page, not an external inbox. The website explicitly states that no email was sent and links to that page. Admin sign-in is required to read it.

## Account contract

The provider owns a validated backend user `{id,email,name,role,staffTeams}`. Roles are `student` or `staff` and come only from the backend. Successful session restoration proves account-email verification; it does not claim student-ID verification. Browser code never selects a staff role or stores a password/session token in local storage.

All requests use `credentials:'include'`. Session cookies are HttpOnly. POST requests send the session CSRF token in `X-CSRF-Token`. The UI refreshes the session after login and clears private records when accounts change, sessions expire or users sign out.

- POST `/api/member/signup`: `{name,email,password,confirmPassword}`
- POST `/api/member/login`: `{email,password}`
- POST `/api/member/logout`: `{}`
- POST `/api/member/forgot-password`: `{email}`
- POST `/api/member/verify`: `{token}`
- POST `/api/member/reset-password`: `{token,password,confirmPassword}`

The backend generates links to its configured website origin with `?member_action=verify&token=...` or `?member_action=reset&token=...`. Opening a link does not consume it: verification requires a button click, and reset requires submitting the new password. Callback tokens stay in the URL/React state only until successful use or dismissal, then are removed with `history.replaceState`. Do not log or copy complete callback URLs into diagnostics.

## Shared booking workspace

Students can submit a cleaning, moving or airport-transfer **request**. The request is awaiting a quote, with no payment or confirmed reservation implied. The server provides the booking ID and stores the customer relationship. Staff see assigned jobs and can add before/completion photos and update progress. Admin views use the same booking records and media.

- GET/POST `/api/member/bookings`: list authorized records / submit `{service,requestedDate,address,notes}`.
- GET `/api/member/bookings/:id`: shared details and private photo metadata.
- POST `/api/member/bookings/:id/photos`: `{group,filename,mime,base64}`; JPEG, PNG or WebP, at most 5 MB per photo and 12 per stage. The backend validates authorization and the file.
- GET `/api/member/bookings/:id/photos/:photoId`: private media, fetched with credentials and displayed through an object URL. Object URLs are revoked when the view closes; arbitrary external URLs and device-only references are not used.
- POST `/api/member/bookings/:id/status`: `{status,expectedStatus,notes}`. The server controls valid transitions and assignment checks.

All three photo groups are visible to authorized booking participants. Photo display does not verify that work was performed. Creation, uploads and progress show success only after the server accepts the operation. An unquoted request displays “Awaiting quote”, never a zero-pound price.

## Shared support inbox

Signed-in students and staff use `messages` or `support` to contact UniMate Support. The admin Message centre uses the same conversations, with a named support responder. Friend/group chats are not implemented. The local test system saves messages in the shared local database; it sends no notification emails.

The member API prefix is `/api/member/support`, and admin is `/api/support`. Both provide a paginated list/detail, new conversations, replies, explicit `/read` acknowledgements and `/status` changes. Members may reopen their own conversation; only the support team can close it. Admin recipient lookup returns active verified accounts without exposing email addresses. Replies use a client UUID so retrying a failed request does not create a duplicate.

The canonical conversation renderer/styles live in `../unimate-prototype/backend/public/shared-chat.mjs` and `shared-chat.css`. The website ships identical copies, checked by `test/support.test.mjs`; update both together. Both interfaces use text-only rendering, visible-tab polling every 15 seconds and a Refresh button. Polling preserves the composer and unsent drafts. Reads are acknowledged only for an opened, visible latest-message page; no simulated delivered/read indicators are displayed.

## Checks and launch boundary

Run `npm run typecheck` and `npm test` with the installed dependencies. Tests mock the network and do not send mail or touch a private database. Local integrated checks should cover two students, staff assignment, private photo access, account switching, confirmation/reset and stale status changes.

Before launch, deploy the backend and private media storage, set the backend's exact website origin/CORS and secure cookie settings, configure real email delivery, and replace the public API URL with the final HTTPS endpoint. Rebuild the website after configuration changes. The public website must remain unconfigured until that deployment is ready; a local passing test does not establish production availability.

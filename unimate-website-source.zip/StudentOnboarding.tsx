import React,{useEffect,useState} from 'react';
import {useAuth} from './auth';
import {useUiText,useUiLocale} from './useUiText';
import {apiMessage} from './member-api';
import {UniMateSelect} from './UniMateSelect';
import './student-onboarding.css';
type Profile={name:string;birthday:string;country:string;province:string;profileComplete:boolean;studentVerified:boolean;verificationSource?:string|null;ownerTester?:boolean;university:string;universityEmail:string;universityVerifiedAt:string|null};
const countryCodes='AF AL DZ AS AD AO AI AQ AG AR AM AW AU AT AZ BS BH BD BB BY BE BZ BJ BM BT BO BA BW BR BN BG BF BI KH CM CA CV KY CF TD CL CN CO KM CG CD CK CR CI HR CU CY CZ DK DJ DM DO EC EG SV GQ ER EE ET FK FO FJ FI FR GF PF GA GM GE DE GH GI GR GL GD GP GU GT GG GN GW GY HT HN HK HU IS IN ID IR IQ IE IM IL IT JM JP JE JO KZ KE KI KW KG LA LV LB LS LR LY LI LT LU MO MK MG MW MY MV ML MT MH MQ MR MU MX FM MD MC MN ME MS MA MZ MM NA NR NP NL NC NZ NI NE NG NU NF KP MP NO OM PK PW PS PA PG PY PE PH PN PL PT PR QA RE RO RU RW SH KN LC PM VC WS SM ST SA SN RS SC SL SG SK SI SB SO ZA KR SS ES LK SD SR SJ SZ SE CH SY TW TJ TZ TH TL TG TK TO TT TN TR TM TC TV UG UA AE GB US UY UZ VU VA VE VN VG VI YE ZM ZW'.split(' ');
const china='北京 天津 河北 山西 内蒙古 辽宁 吉林 黑龙江 上海 江苏 浙江 安徽 福建 江西 山东 河南 湖北 湖南 广东 广西 海南 重庆 四川 贵州 云南 西藏 陕西 甘肃 青海 宁夏 新疆'.split(' ');
const usa='Alabama|Alaska|Arizona|Arkansas|California|Colorado|Connecticut|Delaware|Florida|Georgia|Hawaii|Idaho|Illinois|Indiana|Iowa|Kansas|Kentucky|Louisiana|Maine|Maryland|Massachusetts|Michigan|Minnesota|Mississippi|Missouri|Montana|Nebraska|Nevada|New Hampshire|New Jersey|New Mexico|New York|North Carolina|North Dakota|Ohio|Oklahoma|Oregon|Pennsylvania|Rhode Island|South Carolina|South Dakota|Tennessee|Texas|Utah|Vermont|Virginia|Washington|West Virginia|Wisconsin|Wyoming'.split('|');

type Challenge = {handle:string;email:string;university:string;expires:number};
function readChallenge(id:string):Challenge|null {
 try {const value=JSON.parse(sessionStorage.getItem('unimate-university-code:'+id)||'null');return value&&value.expires>Date.now()?value:null;}catch{return null;}
}
function storeChallenge(id:string,value:Challenge|null) {
 try {if(value)sessionStorage.setItem('unimate-university-code:'+id,JSON.stringify(value));else sessionStorage.removeItem('unimate-university-code:'+id);}catch{}
}
function ProgressSteps({personal,verified,tester=false,onStep}:{personal:boolean;verified:boolean;tester?:boolean;onStep?:(step:1|2)=>void}) {
 const ui=useUiText(); const count=Number(personal)+Number(verified||tester);
 return <div className="student-progress">
   <div className="student-progress-title"><strong>{ui('Steps to completion')}</strong><span>{count} / 2 {ui('complete')}</span></div>
   <div role="progressbar" aria-label={ui('Profile completion')} aria-valuemin={0} aria-valuemax={2} aria-valuenow={count} className="student-progress-track"><span style={{width:(count*50)+'%'}}/></div>
   <ol>{[{step:1 as const,title:'Personal details',done:personal},{step:2 as const,title:tester?'Owner / tester access':'Account verification',done:verified||tester}].map(item=><li key={item.step} className={item.done?'is-complete':''}><button type="button" onClick={()=>onStep?.(item.step)}><span className="student-step-number">{item.done?'✓':item.step}</span><span><strong>{ui(item.title)}</strong><small>{ui(item.done?(tester&&item.step===2?'University verification optional':'Complete'):item.step===2&&!personal?'After personal details':'Continue this step')}</small></span></button></li>)}</ol>
 </div>;
}
export function StudentWelcomeSteps({onOpen}:{onOpen:()=>void}) {
 const {user}=useAuth(),ui=useUiText(); if(!user||user.role!=='student'||(user.studentVerified&&user.profileComplete))return null;
 return <section className="student-welcome-steps"><div><span className={'student-status '+(user.ownerTester||user.studentVerified?'is-verified':'is-unverified')}>{user.ownerTester?'★':user.studentVerified?'✓':'?'} {ui(user.ownerTester?'Owner / tester':user.studentVerified?'Verified student':'Unverified')}</span><h2>{ui('Make UniMate yours')}</h2><p>{ui(user.ownerTester?'Your owner/tester account can explore student features without university verification.':user.studentVerified?'Account verified by UniMate':'Complete your profile, then verify your university email to unlock posting.')}</p><ProgressSteps personal={!!user.profileComplete} verified={!!user.studentVerified} tester={!!user.ownerTester} onStep={onOpen}/></div><button className="fresh-button" onClick={onOpen}>{ui(user.profileComplete?'Continue verification':'Continue my profile')}</button><small>{ui('Your saved progress is kept in your account. You can finish later.')}</small></section>;
}
function BirthdayField({value,onChange}:{value:string;onChange:(value:string)=>void}) {
 const ui=useUiText(),locale=useUiLocale();
 const [parts,setParts]=useState(value?value.split('-'):['','','']);
 useEffect(()=>setParts(value?value.split('-'):['','','']),[value]);
 const [year,month,day]=parts;
 function change(index:number,next:string) {const values=[...parts];values[index]=next;const maximum=values[1]?new Date(Number(values[0]||2000),Number(values[1]),0).getDate():31;if(Number(values[2])>maximum)values[2]='';setParts(values);onChange(values.every(Boolean)?values.join('-'):'');}
 const maxDay=month?new Date(Number(year||2000),Number(month),0).getDate():31;
 return <fieldset className="student-birthday"><legend>{ui('Birthday')}</legend><div>
   <label><span>{ui('Day')}</span><select aria-label={ui('Day')} value={day} onChange={e=>change(2,e.target.value)}><option value="">{ui('Day')}</option>{Array.from({length:maxDay},(_,i)=>String(i+1).padStart(2,'0')).map(d=><option value={d} key={d}>{Number(d)}</option>)}</select></label>
   <label><span>{ui('Month')}</span><select aria-label={ui('Month')} value={month} onChange={e=>change(1,e.target.value)}><option value="">{ui('Month')}</option>{Array.from({length:12},(_,i)=>String(i+1).padStart(2,'0')).map(m=><option value={m} key={m}>{new Intl.DateTimeFormat(locale,{month:'short',timeZone:'UTC'}).format(new Date(Date.UTC(2000,Number(m)-1,1)))}</option>)}</select></label>
   <label><span>{ui('Year')}</span><select aria-label={ui('Year')} value={year} onChange={e=>change(0,e.target.value)}><option value="">{ui('Year')}</option>{Array.from({length:new Date().getFullYear()-1899},(_,i)=>String(new Date().getFullYear()-i)).map(y=><option value={y} key={y}>{y}</option>)}</select></label>
 </div></fieldset>;
}
export function StudentOnboarding({onFinishLater}:{onFinishLater?:()=>void}={}) {
 const {request,refreshSession,user}=useAuth(),ui=useUiText(),locale=useUiLocale();
 const [profile,setProfile]=useState<Profile|null>(null),[name,setName]=useState(''),[birthday,setBirthday]=useState(''),[country,setCountry]=useState(''),[province,setProvince]=useState('');
 const [challenge,setChallenge]=useState<Challenge|null>(()=>readChallenge(user?.id||'')),[email,setEmail]=useState(''),[code,setCode]=useState(''),[step,setStep]=useState<1|2>(1),[error,setError]=useState(''),[codeError,setCodeError]=useState(''),[notice,setNotice]=useState(''),[busy,setBusy]=useState(false),[retry,setRetry]=useState(0);
 useEffect(()=>{const c=new AbortController();setProfile(null);void request<Profile>('/api/member/profile',{signal:c.signal}).then(p=>{if(c.signal.aborted)return;setProfile(p);setName(p.name);setBirthday(p.birthday);setCountry(p.country);setProvince(p.province);setStep(p.profileComplete?2:1);const saved=readChallenge(user?.id||'');setChallenge(saved);setEmail(saved?.email||p.universityEmail||'');}).catch(e=>{if(!c.signal.aborted)setError(apiMessage(e));});return()=>c.abort();},[request,user?.id,retry]);
 const countries=new Intl.DisplayNames([locale],{type:'region'}),regions=country==='CN'?china:country==='US'?usa:null,tester=!!user?.ownerTester;
 async function saveDetails(draft:boolean) {
  setBusy(true);setError('');setNotice('');
  try {const d=await request<{profile:Profile}>('/api/member/profile',{method:'POST',body:{name,birthday,country,province,...(draft?{draft:true}:{})}});setProfile(d.profile);await refreshSession(true);if(draft){setNotice('Your progress is saved. You can finish later.');onFinishLater?.();}else{setStep(2);setNotice(d.profile.studentVerified?'Personal details saved. Your account is verified.':'Personal details saved. Next, verify your university email.');}}
  catch(e){setError(apiMessage(e));}finally{setBusy(false);}
 }
 async function send(e:React.FormEvent) {
  e.preventDefault();setBusy(true);setCodeError('');setNotice('');
  try {const d=await request<{verificationToken:string;university:string;expiresInSeconds:number}>('/api/member/student-verification/request',{method:'POST',body:{email:email.trim()}});const next={handle:d.verificationToken,email:email.trim(),university:d.university,expires:Date.now()+(d.expiresInSeconds||600)*1000};setChallenge(next);storeChallenge(user!.id,next);setCode('');setNotice('A six-digit code was sent to your university email.');}
  catch(e){setCodeError(apiMessage(e));}finally{setBusy(false);}
 }
 async function confirm(e:React.FormEvent) {
  e.preventDefault();if(!challenge)return;setBusy(true);setCodeError('');setNotice('');
  try {const d=await request<{profile:Profile}>('/api/member/student-verification/confirm',{method:'POST',body:{verificationToken:challenge.handle,code}});setProfile(d.profile);setCode('');setChallenge(null);storeChallenge(user!.id,null);setNotice('University email verified. Your personal sign-in email is unchanged.');await refreshSession(true);}
  catch(e){setCodeError(apiMessage(e));}finally{setBusy(false);}
 }
 if(!profile)return <section className="student-onboarding">{error?<><p className="fresh-error" role="alert">{ui(error)}</p><button className="fresh-button" onClick={()=>{setError('');setRetry(v=>v+1);}}>{ui('Try again')}</button></>:<p role="status">{ui('Loading your profile…')}</p>}</section>;
 const exempt=profile.studentVerified||tester;
 return <section className="student-onboarding"><header><span className={'student-status '+(exempt?'is-verified':'is-unverified')}>{exempt?'✓':'?'} {ui(tester?'Owner / tester':profile.studentVerified?'Verified student':'Unverified')}</span><h2>{ui('Your UniMate profile')}</h2><p className="fresh-muted">{ui('Save each step and come back whenever you are ready.')}</p><ProgressSteps personal={profile.profileComplete} verified={profile.studentVerified} tester={tester} onStep={setStep}/></header>
 {notice&&<p className="fresh-notice" role="status">{ui(notice)}</p>}
 {step===1?<section className="student-onboarding-step"><h3>1 · {ui('Personal details')}</h3><p className="fresh-muted">{ui('Your birthday and university email are private. Your university is added after email verification.')}</p><form className="student-details-form" onSubmit={e=>{e.preventDefault();void saveDetails(false);}}>
 <label>{ui('Your name')}<input required minLength={2} maxLength={80} autoComplete="name" value={name} onChange={e=>setName(e.target.value)}/></label>
 <BirthdayField value={birthday} onChange={setBirthday}/>
 <label>{ui('Country / region of origin')}<UniMateSelect required value={country} onChange={e=>{setCountry(e.target.value);setProvince('');}}><option value="">{ui('Choose your country or region')}</option>{countryCodes.map(id=>({id,name:countries.of(id)||id})).sort((a,b)=>a.name.localeCompare(b.name,locale)).map(c=><option value={c.id} key={c.id}>{c.name}</option>)}</UniMateSelect></label>
 <label>{ui('Province / state (optional)')}{regions?<UniMateSelect value={province} onChange={e=>setProvince(e.target.value)}><option value="">{ui('Choose a province or state')}</option>{regions.map(p=><option key={p} value={p}>{p}</option>)}</UniMateSelect>:<input maxLength={100} value={province} onChange={e=>setProvince(e.target.value)} autoComplete="address-level1"/>}</label>
 {error&&<p className="fresh-error student-form-feedback" role="alert">{ui(error)}</p>}
 <div className="student-step-actions"><button className="fresh-button" disabled={busy||!birthday||!country}>{ui('Save and continue')}</button><button type="button" className="fresh-button fresh-secondary" disabled={busy} onClick={()=>void saveDetails(true)}>{ui('Save and finish later')}</button></div>
 </form></section>:<section className="student-onboarding-step"><h3>2 · {ui('Account verification')}</h3>
 {tester?<div className="student-university-confirmed"><strong>{ui('Owner / tester access enabled')}</strong><p>{ui('University verification is optional for this account. Your university is not marked as verified.')}</p></div>:profile.verificationSource==='admin'?<div className="student-university-confirmed"><strong>✓ {ui('Account verified by UniMate')}</strong><p>{ui('An Owner or SuperAdmin approved your account. You can use verified member features without university email confirmation. Your personal email remains your login.')}</p></div>:profile.studentVerified?<div className="student-university-confirmed"><strong>✓ {ui('University email verified')}</strong><dl><div><dt>{ui('University')}</dt><dd>{profile.university}</dd></div><div><dt>{ui('Verification email (private)')}</dt><dd>{profile.universityEmail}</dd></div></dl></div>:<>
 <p className="fresh-muted">{ui('Use the email address issued by your university, not your personal email or a UniMate support address.')}</p>
 <p className="student-verification-explainer">{ui('We check the university domain, then send a code to that mailbox. Entering the code confirms you can access it. Your personal sign-in email stays the same.')}</p>
 {!profile.profileComplete&&<p className="fresh-notice">{ui('Complete step 1 to start university verification.')} <button className="fresh-text-button" onClick={()=>setStep(1)}>{ui('Personal details')}</button></p>}
 <form onSubmit={send} className="student-verification-form"><label>{ui('University email')}<input type="email" required maxLength={254} placeholder="name@university.ac.uk" autoComplete="off" aria-describedby="university-email-help" value={email} onChange={e=>{setEmail(e.target.value);setCodeError('');}} disabled={busy||!profile.profileComplete}/></label><button className="fresh-button" disabled={busy||!profile.profileComplete}>{ui(busy?'Sending…':challenge?'Send a new code':'Send verification code')}</button></form>
 <p id="university-email-help" className="fresh-muted">{ui('For example: name@ucl.ac.uk. If your university is not supported, contact UniMate Support.')}</p>
 {codeError&&<p className="fresh-error" role="alert">{ui(codeError)}</p>}
 {challenge&&<p className="fresh-notice" role="status">{ui('Code sent to')} <strong>{challenge.email}</strong>. {ui('Check your university inbox and junk folder. The code expires in 10 minutes.')}</p>}
 <form onSubmit={confirm} className="student-code-form"><label>{ui('Six-digit verification code')}<input aria-label={ui('Six-digit verification code')} required inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" minLength={6} maxLength={6} placeholder="000000" value={code} disabled={!challenge||busy} onChange={e=>setCode(e.target.value.replace(/\D/g,''))}/></label><p className="fresh-muted">{ui(challenge?'Enter the code from your university email here.':'Send a code first, then enter it here.')}</p><button className="fresh-button" disabled={!challenge||busy||code.length!==6}>{ui('Verify university email')}</button></form>
 </>}
 <div className="student-step-actions"><button className="fresh-button fresh-secondary" onClick={()=>setStep(1)}>{ui('Back to personal details')}</button><button type="button" className="fresh-text-button" onClick={()=>{setNotice('Your progress is saved. You can finish later.');onFinishLater?.();}}>{ui('Finish later')}</button></div>
 </section>}
 <section className="student-permissions-note"><h3>{ui(exempt?'Your student features are unlocked':'Explore while you get verified')}</h3><p>{ui('Browse events, forums, Moments and restaurant reviews. Join events, buy items and book Cleaning, Moving or Airport Transfers.')}</p>{!exempt&&<p>{ui('University verification is required to publish events, sell marketplace items, post in the forum or review restaurants.')}</p>}</section>
 </section>;
}

import React,{useEffect,useState} from 'react';
import {eligibleForClarity,readConsent,saveConsent,startClarity} from './clarity-consent.mjs';
export function AnalyticsConsent({signedIn,loading,route,language}:{signedIn:boolean;loading:boolean;route:string;language:string}){
 const [choice,setChoice]=useState(readConsent),[open,setOpen]=useState(false);
 const currentLocation=typeof window==='undefined'?null:window.location;
 const eligible=!!currentLocation&&eligibleForClarity({hostname:currentLocation.hostname,search:currentLocation.search,hash:currentLocation.hash,signedIn,loading});
 useEffect(()=>{if(eligible&&choice==='accepted')startClarity();},[eligible,choice,route]);
 const text=(en:string,cn:string,tw:string)=>language==='简体'?cn:language==='繁體'?tw:en;
 if(!eligible)return null;
 const choose=(value:'accepted'|'declined')=>{saveConsent(value);setChoice(value);setOpen(false);};
 return <><button type="button" className="fresh-text-button analytics-settings" onClick={()=>setOpen(true)}>{text('Analytics privacy','分析隐私设置','分析隱私設定')}</button>{(!choice||open)&&<section className="analytics-consent" aria-label={text('Optional website analytics','可选网站分析','可選網站分析')} data-clarity-mask="true"><h2>{text('Help us improve UniMate','帮助我们改善优你伴','幫助我們改善優你伴')}</h2><p>{text('With your permission, Microsoft Clarity uses cookies, clicks, scrolling and masked session replays to help us improve this public homepage. It may process device and usage data. We exclude sign-in, accounts, messages, payments and administration. You can decline or change your choice here at any time.','经您同意，Microsoft Clarity 使用 Cookie、点击、滚动及遮蔽内容的会话回放，帮助改善公开首页。可能处理设备和使用数据。登录、账户、消息、付款和管理页面不参与分析。您可随时拒绝或更改选择。','經您同意，Microsoft Clarity 使用 Cookie、點擊、捲動及遮蔽內容的工作階段回放，幫助改善公開首頁。可能處理裝置和使用資料。登入、帳戶、訊息、付款和管理頁面不參與分析。您可隨時拒絕或變更選擇。')}</p><a href="https://privacy.microsoft.com/privacystatement" target="_blank" rel="noopener noreferrer">{text('Microsoft privacy statement','Microsoft 隐私声明','Microsoft 隱私聲明')}</a><div className="fresh-actions"><button type="button" className="fresh-button fresh-secondary" onClick={()=>choose('declined')}>{text('Decline analytics','拒绝分析','拒絕分析')}</button><button type="button" className="fresh-button fresh-secondary" onClick={()=>choose('accepted')}>{text('Accept analytics','同意分析','同意分析')}</button></div></section>}</>;
}

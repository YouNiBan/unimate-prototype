export const CLARITY_PROJECT:string;
export const CONSENT_KEY:string;
export function eligibleForClarity(input:{hostname:string;search:string;hash:string;signedIn:boolean;loading:boolean}):boolean;
export function startClarity():void;
export function readConsent():string|null;
export function saveConsent(value:'accepted'|'declined'):void;
export function leaveRecordedHome(nextHash:string):boolean;

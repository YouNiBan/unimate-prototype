import { ApiError } from './member-api';
export type Service = 'cleaning' | 'moving' | 'airport_transfer';
export type PhotoGroup = 'request' | 'before' | 'completion';
export type BookingPhoto = { id: string; group: PhotoGroup; filename: string; mime: string; bytes: number; createdAt: string; url: string };
export type Booking = {
  id: string; reference?: string; title: string; customer: string; service: Service; status: string; amount_pence: number; created_at: string;
  pricingStatus: 'unquoted' | 'confirmed' | 'legacy';
  submission: { intake?: { fields?: { label: string; value: string }[]; photos?: string[] } } | null;
  team?:{id:string;name:string}|null; assignment: { member_id: string; name: string; team: string; starts_at: string; ends_at: string } | null;
  photos: BookingPhoto[]; submissionUnavailable?: boolean;
};
export type BookingDetail = { row: Booking; photos: BookingPhoto[]; pricingStatus: Booking['pricingStatus']; assignment: Booking['assignment']; submission: Booking['submission'] };
export const serviceLabels: Record<Service, string> = { cleaning: 'Cleaning', moving: 'Moving', airport_transfer: 'Airport transfer' };
export const photoLabels: Record<PhotoGroup, string> = { request: 'Request photos', before: 'Before-service photos', completion: 'Completion photos' };
export function bookingPrice(booking: Pick<Booking, 'pricingStatus' | 'amount_pence'>) {
  return booking.pricingStatus === 'unquoted' ? 'Awaiting quote' : new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP' }).format(booking.amount_pence / 100);
}
export function bookingStatus(status: string) {
  return ({ requested: 'Request received', pending: 'Pending', assigned: 'Assigned', confirmed: 'Confirmed', in_progress: 'In progress', completed: 'Completed', cancelled: 'Cancelled' } as Record<string, string>)[status] || status.replace(/_/g, ' ');
}
export function bookingPath(id: string) { return '/api/member/bookings/' + encodeURIComponent(id); }
export function privatePhotoPath(bookingId: string, photo: Pick<BookingPhoto, 'id' | 'url'>) {
  const expected = bookingPath(bookingId) + '/photos/' + encodeURIComponent(photo.id);
  if (photo.url !== expected) throw new ApiError('This photo is unavailable.');
  return expected;
}
export async function photoUpload(file: File): Promise<{ filename: string; mime: string; base64: string }> {
  if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) throw new ApiError('Choose a JPEG, PNG or WebP photo.');
  if (!file.size || file.size > 10 * 1024 * 1024) throw new ApiError('Each photo must be 10 MB or smaller.');
  const bytes = new Uint8Array(await file.arrayBuffer());
  let binary = '';
  for (let start = 0; start < bytes.length; start += 8192) binary += String.fromCharCode(...bytes.subarray(start, start + 8192));
  return { filename: file.name, mime: file.type, base64: btoa(binary) };
}

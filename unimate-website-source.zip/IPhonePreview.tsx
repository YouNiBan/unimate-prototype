import React, { useId } from 'react';
import paths from './assets/icons/ionicons-paths.json';

type Screen = 'dashboard' | 'moments' | 'forum';
type IconName = keyof typeof paths;
const blue = '#087DF1', ink = '#102D63', muted = '#71839B';
function Icon({ name, x, y, size = 22, color = blue }: { name: IconName; x: number; y: number; size?: number; color?: string }) {
  return <g transform={`translate(${x} ${y}) scale(${size / 512})`}><path d={paths[name]} transform="translate(0 448) scale(1 -1)" fill={color}/></g>;
}
function Copy({ x, y, children, size = 14, color = ink, weight = 400, center = false }: { x: number; y: number; children: React.ReactNode; size?: number; color?: string; weight?: number; center?: boolean }) {
  return <text x={x} y={y} fontSize={size} fill={color} fontWeight={weight} textAnchor={center ? 'middle' : 'start'}>{children}</text>;
}

/** A fixed-proportion, empty app preview: SVG text cannot inherit button line-height. */
export function IPhonePreview({ screen, label }: { screen: Screen; label: (text: string) => string }) {
  const id = useId().replace(/:/g, '');
  const clip = `screen-${id}`, metal = `metal-${id}`;
  const dashboard = screen === 'dashboard';
  const navigation: { icon: IconName; title: string; active: boolean }[] = [
    { icon: 'home-outline', title: 'Home', active: dashboard },
    { icon: 'people-outline', title: 'Friends', active: false },
    { icon: 'images-outline', title: 'Moments', active: !dashboard },
    { icon: 'chatbubbles-outline', title: 'Messages', active: false },
    { icon: 'person-outline', title: 'Profile', active: false },
  ];
  return <svg className="iphone-preview" viewBox="0 0 430 890" fontFamily="Arial, Helvetica, sans-serif" role="img" aria-label={label(screen === 'dashboard' ? 'UniMate dashboard' : screen === 'moments' ? 'Moments' : 'Student Forum')} xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id={metal} x1="0" y1="0" x2="1" y2="1"><stop stopColor="#D5D7DA"/><stop offset=".45" stopColor="#51545A"/><stop offset="1" stopColor="#ADB0B6"/></linearGradient><clipPath id={clip}><rect x="18" y="18" width="394" height="854" rx="49"/></clipPath></defs>
    <rect x="1" y="160" width="6" height="34" rx="3" fill="#62666D"/><rect x="1" y="214" width="6" height="65" rx="3" fill="#62666D"/><rect x="1" y="293" width="6" height="65" rx="3" fill="#62666D"/><rect x="423" y="232" width="6" height="100" rx="3" fill="#62666D"/>
    <rect x="6" y="6" width="418" height="878" rx="62" fill={`url(#${metal})`}/><rect x="9" y="9" width="412" height="872" rx="59" fill="#111318"/>
    <g clipPath={`url(#${clip})`}><rect x="18" y="18" width="394" height="854" fill="#FFF"/>
      <g transform="translate(18 18)">
        <Copy x={30} y={34} size={14} weight={650} color="#151A22">9:41</Copy>
        <rect x="136" y="12" width="122" height="35" rx="18" fill="#101114"/><circle cx="238" cy="29" r="5" fill="#182B42"/>
        <Icon name="cellular" x={300} y={20} size={16} color="#151A22"/><Icon name="wifi" x={320} y={20} size={16} color="#151A22"/><Icon name="battery-full" x={343} y={19} size={21} color="#151A22"/>
        <g transform="translate(22 65)"><circle cx="9" cy="7" r="5" fill={blue}/><circle cx="30" cy="5" r="5" fill="#2DBE78"/><path d="M3 18Q3 40 22 40Q9 34 15 22Z" fill={blue}/><path d="M20 22Q27 25 34 15Q42 38 19 40Q29 33 20 22Z" fill="#2DBE78"/><Copy x={47} y={22} size={24} weight={800}>UniMate</Copy><Copy x={48} y={38} size={10} weight={650}>优你伴</Copy></g>
        <Icon name="notifications-outline" x={302} y={77}/><Icon name="sunny-outline" x={344} y={77}/><path d="M0 119H394" stroke="#E2EAF5"/>
        {dashboard ? <>
          <Copy x={22} y={145} size={11} color={muted}>{label('London')}</Copy><Copy x={22} y={179} size={24} weight={750}>{label('Welcome to UniMate')}</Copy>
          <rect x="22" y="198" width="350" height="38" rx="11" fill="#F3F7FC"/><Icon name="search-outline" x={34} y={208} size={18} color={muted}/><Copy x={62} y={223} size={11} color={muted}>{label('Search UniMate')}</Copy>
          <rect x="22" y="252" width="350" height="130" rx="16" fill="#EAF5FF"/><Copy x={38} y={276} size={9} weight={750} color={blue}>{label('NEW CITY.')}</Copy><Copy x={38} y={305} size={20} weight={750}>{label('New friends,')}</Copy><Copy x={38} y={332} size={20} weight={750}>{label('new adventures.')}</Copy><Icon name="business-outline" x={275} y={283} size={69} color="#A5D1F5"/>
          <Copy x={22} y={411} size={15} weight={750}>{label('Your space')}</Copy>
          <rect x="22" y="426" width="350" height="57" rx="13" fill="#F4F8FD"/><Icon name="calendar-outline" x={37} y={443} size={24}/><Copy x={76} y={449} size={12} weight={650}>{label('My events')}</Copy><Copy x={76} y={467} size={10} color={muted}>{label('No upcoming events')}</Copy><Icon name="chevron-forward" x={340} y={446} size={16} color={muted}/>
          <rect x="22" y="495" width="350" height="57" rx="13" fill="#F4F8FD"/><Icon name="images-outline" x={37} y={512} size={24}/><Copy x={76} y={519} size={12} weight={650}>{label('Moments')}</Copy><Copy x={76} y={537} size={10} color={muted}>{label('A new space, ready to grow')}</Copy><Icon name="chevron-forward" x={340} y={515} size={16} color={muted}/>
          <Copy x={22} y={588} size={15} weight={750}>{label('What do you need today?')}</Copy>
          {([{name:'calendar-outline',text:'Events',color:'#EF5362'},{name:'car-sport-outline',text:'Airport transfers',color:'#1DAA61'},{name:'home-outline',text:'Cleaning',color:'#E79824'},{name:'cube-outline',text:'Moving',color:'#15999E'},{name:'bag-handle-outline',text:'Marketplace',color:'#8654D9'},{name:'restaurant-outline',text:'Places & Reviews',color:'#DC754E'}] as const).map((item,i) => {const x=22+(i%3)*120,y=606+Math.floor(i/3)*78;return <g key={item.text}><rect x={x} y={y} width="110" height="67" rx="12" fill="#FFF" stroke="#E1EAF5"/><Icon name={item.name} x={x+42} y={y+10} size={23} color={item.color}/><Copy x={x+55} y={y+51} size={8.5} weight={600} center>{label(item.text)}</Copy></g>;})}
        </> : <>
          <Copy x={22} y={158} size={25} weight={750}>{label(screen === 'moments' ? 'Moments' : 'Student Forum')}</Copy><Icon name="add-outline" x={344} y={137} size={24}/>
          {['For You','Following','Explore','Forum'].map((title,i)=><g key={title}><Copy x={49+i*98} y={201} size={12} weight={screen === 'forum' ? title==='Forum'?750:500 : title==='For You'?750:500} color={(screen==='forum'?title==='Forum':title==='For You')?blue:muted} center>{label(title)}</Copy>{(screen==='forum'?title==='Forum':title==='For You')&&<rect x={i*98+12} y="213" width="76" height="3" rx="2" fill={blue}/>}</g>)}
          <rect x="22" y="237" width="350" height="40" rx="11" fill="#F3F7FC"/><Icon name="search-outline" x={35} y={248} size={18} color={muted}/><Copy x={62} y={262} size={11} color={muted}>{label('Search UniMate')}</Copy>
          <circle cx="197" cy="423" r="48" fill="#EBF5FF"/><Icon name={screen==='moments'?'images-outline':'chatbox-ellipses-outline'} x={175} y={401} size={44}/><Copy x={197} y={505} size={18} weight={700} center>{label(screen==='moments'?'No posts yet':'No discussions yet')}</Copy><Copy x={197} y={532} size={12} color={muted} center>{label('A new space, ready to grow')}</Copy>
        </>}
        <path d="M0 777H394" stroke="#E2EAF5"/><rect x="0" y="778" width="394" height="76" fill="#FFF"/>
        {navigation.map((item,i)=><g key={item.title}><Icon name={item.icon} x={28+i*78} y={794} size={22} color={item.active?blue:muted}/><Copy x={39+i*78} y={831} size={9} color={item.active?blue:muted} weight={item.active?700:400} center>{label(item.title)}</Copy></g>)}
        <rect x="136" y="844" width="122" height="4" rx="2" fill="#16191F"/>
      </g>
    </g>
  </svg>;
}

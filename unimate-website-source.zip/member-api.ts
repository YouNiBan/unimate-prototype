/** Public API location only. Authentication remains in the server's HttpOnly cookie. */
export function resolveApiBase(value: string | undefined): string {
  if (value === 'same-origin' && typeof window !== 'undefined') return window.location.origin;
  if (!value?.trim()) return '';
  try {
    const url = new URL(value.trim());
    const local = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
    if (url.username || url.password || url.search || url.hash || (url.protocol !== 'https:' && !(local && url.protocol === 'http:'))) return '';
    return url.toString().replace(/\/$/, '');
  } catch { return ''; }
}
export const apiBase = resolveApiBase(process.env.EXPO_PUBLIC_API_URL);
export class ApiError extends Error {
  constructor(message: string, public status = 0) { super(message); this.name = 'ApiError'; }
}
const expiredListeners = new Set<(generation: number | undefined) => void>();
export function onSessionExpired(listener: (generation: number | undefined) => void) { expiredListeners.add(listener); return () => { expiredListeners.delete(listener); }; }
export type ApiOptions = { method?: 'GET' | 'POST'; body?: unknown; csrf?: string; signal?: AbortSignal; binary?: boolean; authGeneration?: number };
export async function apiRequest<T>(path: string, options: ApiOptions = {}): Promise<T> {
  if (!apiBase) throw new ApiError('Account services are not connected yet. Please try again later.');
  if (!path.startsWith('/api/') || path.includes('..') || path.includes('\\')) throw new ApiError('This request is unavailable.');
  const controller = new AbortController();
  const abort = () => controller.abort();
  if (options.signal?.aborted) controller.abort();
  options.signal?.addEventListener('abort', abort, { once: true });
  const timer = setTimeout(abort, 20_000);
  try {
    const response = await fetch(apiBase + path, {
      method: options.method || 'GET', credentials: 'include', cache: 'no-store', redirect: 'error', signal: controller.signal,
      headers: { Accept: options.binary ? 'image/png,image/jpeg,image/webp' : 'application/json', ...(options.method === 'POST' ? { 'Content-Type': 'application/json', 'X-CSRF-Token': options.csrf || '' } : {}) },
      ...(options.method === 'POST' ? { body: JSON.stringify(options.body ?? {}) } : {}),
    });
    if (response.status === 401) expiredListeners.forEach(listener => listener(options.authGeneration));
    if (options.binary && response.ok) return await response.blob() as T;
    const content = await response.json().catch(() => null);
    if (!response.ok) throw new ApiError(typeof content?.error === 'string' ? content.error : 'We could not complete this request. Please try again.', response.status);
    if (!content || typeof content !== 'object') throw new ApiError('The service returned an unreadable response. Please try again.');
    return content as T;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    if (options.signal?.aborted) throw error;
    throw new ApiError('We could not connect. Please check your connection and try again.');
  } finally { clearTimeout(timer); options.signal?.removeEventListener('abort', abort); }
}
export function apiMessage(error: unknown) { return error instanceof ApiError ? error.message : 'We could not complete this request. Please try again.'; }

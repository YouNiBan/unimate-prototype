import {FoodLeaderboard,StudentConnections} from './RestaurantCommunity';
import {StudentOnboarding,StudentWelcomeSteps} from './StudentOnboarding';
import {FoodReviews} from './FoodReviews';
import {AnalyticsConsent} from './AnalyticsConsent';
import {leaveRecordedHome} from './clarity-consent.mjs';
import {UniMateSelect} from './UniMateSelect';
import {AccountBadgeKey} from './AccountBadgeKey';
import {memberPasswordRules, memberPasswordValid} from './member-password-policy.mjs';
import {setUiLanguage} from './ui-i18n.mjs';
import {useUiText} from './useUiText';
import {LanguagePicker} from './LanguagePicker';
import {OwnerViews} from './OwnerViews';
import {Marketplace} from './Marketplace';
import React, { useEffect, useRef, useState } from 'react';
import { Image } from 'react-native';
import { AppIonicons, UniMateMomentsIcon, UniMateLogo } from './AppIcons';
import { AuthProvider, useAuth } from './auth';
import { SharedBookings } from './SharedBookings';
import { StudentDashboard } from './StudentDashboard';
import { SharedSupport } from './SharedSupport';
import { StaffInvoices } from './StaffInvoices';
import { apiBase } from './member-api';
import { WebsiteSidebar, WebsiteLayoutFrame, WebsiteDisplayControl, WebsiteLanguageContext, type WebsiteDestination } from './WebsiteShell';
import { readPublicLanguage, translatePublic, type PublicLanguage } from './public-i18n';
import './public-website.css';

function usePublicText() {
  const language = React.useContext(WebsiteLanguageContext);
  return (text: string, values?: Record<string, string>) => translatePublic(language, text, values);
}

type PreviewScreen = 'dashboard' | 'moments' | 'forum';
const appScreenshots = { dashboard: require('./assets/dashboard-preview.jpg'), moments: require('./assets/moments-preview.jpg'), forum: require('./assets/forum-preview.jpg') };
const screenshotTitles = { dashboard: 'UniMate dashboard', moments: 'Moments', forum: 'Student Forum' };
function AppScreenshot({ screen, onOpen }: { screen: PreviewScreen; onOpen: () => void }) {
  const label = usePublicText();
  const title = label(screenshotTitles[screen]);
  return <button className="public-screen-button" aria-label={label('Enlarge {screen} screenshot', { screen: title })} onClick={onOpen}><Image source={appScreenshots[screen]} accessibilityLabel={label('{screen} app preview', { screen: title })} style={{ width: '100%', height: '100%' }} resizeMode="contain"/></button>;
}

type Language = PublicLanguage;
type Icon = React.ComponentProps<typeof AppIonicons>['name'];
type Route = WebsiteDestination | 'food-leaderboard' | 'owner-views' | 'invoices' | 'dashboard' | 'signin' | 'signup' | 'forgot-password' | 'reset-password' | 'verify-email';
const protectedRoutes = new Set(['dashboard', 'my-events', 'listings', 'bookings', 'messages', 'profile', 'connections','food-leaderboard']);
const authRoutes = new Set(['signin', 'signup', 'forgot-password', 'reset-password', 'verify-email']);
const readRoute = (): Route => {
  const action = new URLSearchParams(window.location.search).get('member_action');
  if (action === 'verify') return 'verify-email';
  if (action === 'reset') return 'reset-password';
  return (window.location.hash.startsWith('#/') ? window.location.hash.slice(2).split('?')[0] : 'home') as Route;
};
const categories = [
  { id: 'events', title: 'Events', cn: '活动', tw: '活動', icon: 'calendar', color: '#ff4657', text: 'Find something to look forward to.', detail: 'Upcoming student events will appear here when they are published.' },
  { id: 'market', title: 'Marketplace', cn: '学生集市', tw: '學生市集', icon: 'bag-handle', color: '#854ce9', text: 'A place for your next great find.', detail: 'Items for sale will appear here when the marketplace opens.' },
  { id: 'food', title: 'Places & Reviews', cn: '好去处与点评', tw: '好去處與評價', icon: 'restaurant', color: '#e95e32', text: 'Discover your next favourite spot.', detail: 'Places to eat and community reviews will appear here when published.' },
  { id: 'friends', title: 'Moments', cn: '朋友圈', tw: '朋友圈', icon: 'images', color: '#8b5cf6', text: 'Everyday moments, shared.', detail: 'Community moments will appear here when sharing opens.' },
  { id: 'forum', title: 'Student Forum', cn: '学生问答', tw: '學生問答', icon: 'chatbox-ellipses', color: '#0799ad', text: 'Questions, ideas and conversations.', detail: 'Student discussions will appear here when the forum opens.' },
  { id: 'connections', title: 'Friends', cn: '好友', tw: '好友', icon: 'people', color: '#8262DB', text: 'Make room for new connections.', detail: 'Your friends will appear here once connections are available.' },
] as const;
const services = [
  { id: 'airport', title: 'Airport transfers', cn: '机场接送', tw: '機場接送', icon: 'car-sport', color: '#17a957', text: 'Start your journey with a plan.', detail: 'Airport transfer booking is being prepared. Service areas, prices and availability will be published before bookings open.' },
  { id: 'moving', title: 'Moving', cn: '搬家服务', tw: '搬家服務', icon: 'cube', color: '#00a1a7', text: 'A little help with your next chapter.', detail: 'Moving services are being prepared. You will be able to review the service details before making a booking.' },
  { id: 'cleaning', title: 'Cleaning', cn: '保洁服务', tw: '清潔服務', icon: 'home', color: '#f28a18', text: 'Make your space feel like home.', detail: 'Cleaning services are being prepared. Service options and prices will appear here when bookings open.' },
] as const;
const messageFilters = ['All', 'Friends', 'Groups', 'Event chats', 'Support', 'Marketplace', 'Airport transfers', 'Cleaning', 'Moving'];
const mobileNavigationColors: Record<string, string> = { home: '#1683DF', connections: '#8262DB', messages: '#C98712', profile: '#2DBE78' };

function IconBadge({ name, color = '#1683df' }: { name: Icon; color?: string }) {
  return <span className="fresh-icon" style={{ color, backgroundColor: color + '12' }} aria-hidden="true"><AppIonicons name={name} size={25} color={color} /></span>;
}
function EmptyState({ icon, title, children }: { icon: Icon; title: string; children: React.ReactNode }) {
  return <div className="fresh-empty"><IconBadge name={icon} /><h2>{title}</h2><div className="fresh-muted">{children}</div></div>;
}
function Modal({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }) {
  const label = usePublicText();
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => { ref.current?.showModal(); }, []);
  return <dialog ref={ref} className="fresh-dialog" aria-label={title} onCancel={onClose} onClick={e => { if (e.target === e.currentTarget) onClose(); }}><div className="fresh-dialog-heading"><h2>{title}</h2><button className="fresh-icon-button" aria-label={label('Close')} onClick={onClose}><AppIonicons name="close" size={22} color="currentColor" /></button></div>{children}</dialog>;
}

function AccountForm({ route, navigate }: { route: Route; navigate: (route: Route) => void }) {
 const ui=useUiText();
  const auth = useAuth();
  const label = usePublicText();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const passwordRules = memberPasswordRules(password);
  const [accountType,setAccountType]=useState('student'),[service,setService]=useState('cleaning'),[organisation,setOrganisation]=useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const signup = route === 'signup', forgot = route === 'forgot-password', reset = route === 'reset-password', verify = route === 'verify-email';
  const title = verify ? 'Confirm your email' : signup ? 'Create your UniMate account' : forgot ? 'Forgot your password?' : reset ? 'Choose a new password' : 'Welcome back';
  const validLink = (!reset || auth.recovery) && (!verify || auth.verification);
  const enabled = auth.configured && validLink && (!signup || auth.registrationEnabled) && (!forgot || auth.mailConfigured);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setError(''); setSuccess('');
    if (!enabled || busy) return;
    if ((signup || reset) && !memberPasswordValid(password)) { setError('Use 10–128 characters, including uppercase and lowercase letters, a number and a special character.'); return; }
    if ((signup || reset) && password !== confirm) { setError('Your passwords do not match.'); return; }
    setBusy(true);
    try {
      const result = verify ? await auth.verifyEmail() : signup ? await auth.signUp(email.trim(), password, name.trim(), confirm, {accountType,service,organisation}) : forgot ? await auth.requestPasswordReset(email.trim()) : reset ? await auth.updatePassword(password, confirm) : await auth.signIn(email.trim(), password);
      if (result.error) setError(result.error);
      else if (verify) setSuccess('Your email has been confirmed. You can now sign in.');
      else if (signup) { setSuccess(auth.mailMode === 'local' ? 'Open the local test mailbox in the admin dashboard to use your confirmation link. No email was sent.' : 'Check your email for a confirmation link. After confirming, sign in to your new account.'); setPassword(''); setConfirm(''); }
      else if (forgot) setSuccess(auth.mailMode === 'local' ? 'Open the local test mailbox in the admin dashboard to use your reset link. No email was sent.' : 'If an account exists for this email address, you will receive a password reset link.');
      else { setPassword(''); setConfirm(''); navigate(reset ? 'signin' : 'dashboard'); }
    } catch { setError('We could not connect. Please try again.'); }
    finally { setBusy(false); }
  }
  return <div className="fresh-auth-wrap"><section className="fresh-auth-card"><IconBadge name={verify ? 'mail-outline' : forgot || reset ? 'key-outline' : 'person-circle-outline'} /><p className="fresh-eyebrow">{label('YOUR UNIMATE')}</p><h1>{label(title)}</h1><p className="fresh-muted">{label(verify ? 'Confirm that this email address belongs to you to finish creating your account.' : signup ? 'Your own space for student life.' : forgot ? 'We’ll email you a link to reset it.' : reset ? 'Set a secure password for your account.' : 'Sign in to your own account and pick up where you left off.')}</p>
    {!auth.configured && <div className="fresh-notice" role="status"><strong>{label('Accounts are temporarily unavailable')}</strong><p>{label('Please try again shortly. You can explore UniMate in the meantime.')}</p><button className="fresh-text-button" type="button" onClick={() => void auth.refreshSession()}>{ui("Try again")}</button></div>}
    {auth.configured && signup && !auth.registrationEnabled && <p className="fresh-notice">{ui("New account registration is currently closed. Existing members can still sign in.")}</p>}
    {auth.configured && forgot && !auth.mailConfigured && <p className="fresh-notice">{ui("Password reset emails are temporarily unavailable. Please try again later.")}</p>}
    {!validLink && !success && auth.configured && <div className="fresh-notice">{label(verify ? 'Open the confirmation link from your email to continue.' : 'Open the password reset link from your email to continue.')} {!verify && <button className="fresh-text-button" onClick={() => navigate('forgot-password')}>{label('Request a new link')}</button>}</div>}
    <form onSubmit={submit}>
      {signup && <><fieldset className="account-type-choices" disabled={!enabled || busy}><legend>{ui("Choose your account")}</legend>{[['student','Student','Explore, connect and book','school'],['staff','Staff','Cleaning, moving or transfers','briefcase'],['seller','Shopkeeper / Seller','Sell on the student marketplace','bag-handle'],['organisation','Organisation','Manage your organisation','business']].map(([value,title,description,icon])=><label key={value} className={accountType===value?'is-selected':''}><input type="radio" name="accountType" value={value} checked={accountType===value} onChange={()=>setAccountType(value)}/><AppIonicons name={icon as Icon} size={23} color={accountType===value?'#1683DF':'#71839B'}/><span><strong>{ui(title)}</strong><small>{ui(description)}</small></span></label>)}</fieldset><AccountBadgeKey/>{accountType==='staff'&&<label>{ui("Service team")}<UniMateSelect value={service} onChange={e=>setService(e.target.value)} disabled={!enabled||busy}><option value="cleaning">{ui("Cleaning")}</option><option value="moving">{ui("Moving")}</option><option value="airport_transfer">{ui("Airport transfers")}</option></UniMateSelect></label>}{accountType==='organisation'&&<label>{ui("Organisation name")}<input required minLength={2} maxLength={120} value={organisation} onChange={e=>setOrganisation(e.target.value)} disabled={!enabled||busy}/></label>}{accountType!=='student'&&<p className="fresh-muted account-approval-note">{ui("Confirm your email. UniMate will then review your application. Approval is needed before you can access these tools.")}</p>}</>}
      {signup&&accountType==='student'&&<p className="fresh-muted">{ui('Use your personal email to join. Complete your profile and university verification after signing up.')}</p>}{signup && <label>{label('Your name')}<input autoComplete="name" required maxLength={80} value={name} onChange={e => setName(e.target.value)} disabled={!enabled || busy} /></label>}
      {!reset && !verify && <label>{label(signup?'Personal email address':'Email address')}<input type="email" autoComplete="email" required value={email} onChange={e => setEmail(e.target.value)} disabled={!enabled || busy} /></label>}
      {!forgot && !verify && <><label>{label('Password')}<span className="account-password-input"><input type={showPassword ? 'text' : 'password'} autoComplete={signup || reset ? 'new-password' : 'current-password'} required minLength={signup || reset ? 10 : 1} maxLength={128} value={password} onChange={e => setPassword(e.target.value)} disabled={!enabled || busy} aria-describedby={signup || reset ? 'account-password-rules' : undefined}/><button type="button" aria-label={ui(showPassword ? 'Hide password' : 'Show password')} aria-pressed={showPassword} onClick={()=>setShowPassword(!showPassword)}><AppIonicons name={showPassword ? 'eye-off-outline' : 'eye-outline'} size={20} color="currentColor"/></button></span></label>
      {(signup || reset) && <ul className="account-password-rules" id="account-password-rules">{passwordRules.map(rule=><li key={rule.label} className={rule.passed?'is-passed':''}><AppIonicons name={rule.passed?'checkmark-circle':'ellipse-outline'} size={16} color="currentColor"/><span>{ui(rule.label)}</span></li>)}</ul>}</>}
      {(signup || reset) && <><label>{label('Confirm password')}<input type={showPassword ? 'text' : 'password'} autoComplete="new-password" required minLength={10} maxLength={128} value={confirm} onChange={e => setConfirm(e.target.value)} disabled={!enabled || busy} aria-describedby={confirm ? 'account-password-match' : undefined}/></label>{confirm && <p id="account-password-match" role="status" className={confirm===password?'account-password-match is-passed':'account-password-match fresh-error'}>{ui(confirm===password?'Passwords match':'Passwords do not match')}</p>}</>}
      {error && <p className="fresh-error" role="alert">{label(error)}</p>}{success && <p className="fresh-success" role="status">{label(success)}{auth.mailMode === 'local' && (signup || forgot) && <> <a href={apiBase + '/test-mail'} target="_blank" rel="noopener noreferrer">{ui("Open local test mailbox")}</a></>}</p>}
      {!(verify && success) && <button className="fresh-button fresh-full" disabled={!enabled || busy} type="submit">{label(busy ? 'Please wait…' : verify ? 'Confirm email address' : signup ? 'Create account' : forgot ? 'Send reset link' : reset ? 'Save password' : 'Sign in')}<AppIonicons name="arrow-forward" size={17} color="currentColor" /></button>}
    </form>
    {verify && success && <button className="fresh-button fresh-full" onClick={() => navigate('signin')}>{ui("Continue to sign in")}</button>}
    {!signup && !forgot && !reset && !verify && <button className="fresh-text-button fresh-auth-link" onClick={() => navigate('forgot-password')}>{label('Forgot password?')}</button>}
    {!verify && <p className="fresh-auth-switch">{label(signup ? 'Already have an account?' : 'New to UniMate?')} <button className="fresh-text-button" onClick={() => { auth.clearRecovery(); navigate(signup ? 'signin' : 'signup'); }}>{label(signup ? 'Sign in' : 'Create account')}</button></p>}
    <button className="fresh-text-button fresh-auth-link" onClick={() => { auth.clearRecovery(); navigate('home'); }}>{label('Back to homepage')}</button>
  </section></div>;
}

function StaffNavigation({ current, navigate, logout }: { current: string; navigate: (route: Route) => void; logout: () => void }) {
 const ui=useUiText();
  return <aside className="website-sidebar booking-staff-nav"><div className="website-sidebar-scroll"><p className="website-nav-group">{ui("STAFF WORKSPACE")}</p><nav aria-label={ui("Staff navigation")}>{[{ id: 'home', title: 'Overview', icon: 'home' }, { id: 'bookings', title: 'Assigned jobs', icon: 'calendar' }, { id: 'invoices', title: 'My invoices', icon: 'receipt' }, { id: 'messages', title: 'Messages', icon: 'chatbubbles' }, { id: 'support', title: 'Support', icon: 'headset' }, { id: 'profile', title: 'My account', icon: 'person' }].map(item => <a key={item.id} href={'#/' + item.id} className={'website-nav-item ' + (current === item.id ? 'is-active' : '')} aria-current={current === item.id ? 'page' : undefined} onClick={event => { event.preventDefault(); navigate(item.id as Route); }}><AppIonicons name={item.icon as Icon} size={21} color={current === item.id ? (mobileNavigationColors[item.id] || '#1683DF') : 'var(--muted, #71839B)'}/>{ui(item.title)}</a>)}</nav><button className="website-signout" onClick={logout}>{ui("Sign out")} <span>↗</span></button></div></aside>;
}

function PublicApp() {
  const auth = useAuth();
  const [route, setRoute] = useState<Route>(readRoute);
  const [language, setLanguage] = useState<Language>(()=>{const params=new URLSearchParams(window.location.search),value=params.get('language');return params.get('owner-embed')==='1'&&['EN','简体','繁體'].includes(value||'')?value as Language:readPublicLanguage();});
  const [dark, setDark] = useState(() => { try { const params=new URLSearchParams(window.location.search);return params.get('owner-embed')==='1'&&params.has('theme')?params.get('theme')==='dark':localStorage.getItem('unimate-theme') === 'dark'; } catch { return false; } });
  const [menu, setMenu] = useState(false);
  const [preview, setPreview] = useState<PreviewScreen | null>(null);
  const [modal, setModal] = useState<'notifications' | 'location' | 'new-message' | null>(null);
  const [filter, setFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [actionError, setActionError] = useState('');
  const [section, setSection] = useState<string | null>(null);
  const main = useRef<HTMLElement>(null);
  const tr = (en: string, cn: string, tw: string) => language === 'EN' ? en : language === '简体' ? cn : tw;
  const label = (en: string, values?: Record<string, string>) => translatePublic(language, en, values);
  const ui=label;
  function navigate(next: Route) { if(leaveRecordedHome('#/'+next))return; main.current?.scrollTo({ top: 0, behavior: 'instant' }); window.location.hash = '/' + next; setRoute(next); setMenu(false); setModal(null); setActionError(''); }
  useEffect(() => { const listener = () => {if(leaveRecordedHome(window.location.hash))return;setRoute(readRoute());}; window.addEventListener('hashchange', listener); return () => window.removeEventListener('hashchange', listener); }, []);
  useEffect(() => { document.documentElement.dataset.unimateTheme = dark ? 'dark' : 'light'; try { localStorage.setItem('unimate-theme', dark ? 'dark' : 'light'); } catch {} }, [dark]);
  useEffect(() => { setUiLanguage(language);document.documentElement.lang = language === 'EN' ? 'en' : language === '简体' ? 'zh-Hans' : 'zh-Hant'; try { localStorage.setItem('unimate-public-language', language); } catch {} }, [language]);
  useEffect(() => {
    if (auth.loading) return;
    if (auth.recovery) { if (route !== 'reset-password') navigate('reset-password'); return; }
    if (auth.verification) { if (route !== 'verify-email') navigate('verify-email'); return; }
    if (auth.user && ['home', 'signin', 'signup'].includes(route)) navigate('dashboard');
    if (!auth.user && !authRoutes.has(route) && !['home', 'support', 'owner-views'].includes(route)) navigate('home');
    if (auth.user?.role === 'staff' && !authRoutes.has(route) && !['home', 'dashboard', 'bookings', 'invoices', 'messages', 'support', 'profile', 'owner-views'].includes(route)) navigate('dashboard');
  }, [auth.loading, auth.user?.id, auth.user?.role, auth.recovery, auth.verification, route]);
  useEffect(() => { main.current?.scrollTo({ top: 0 }); setSearch(''); setFilter('All'); }, [route]);
  const activeRoute = route === 'dashboard' ? 'home' : route;
  const category = [...categories, ...services].find(item => item.id === route);
  const personalTitles: Record<string, string> = { 'my-events': 'My events', listings: 'My marketplace', bookings: 'Bookings & purchases', messages: 'Messages', profile: 'My account', dashboard: 'Your dashboard', 'food-leaderboard':'Food reviewer leaderboard','owner-views':'Owner account views', support: 'Support', signin: 'Sign in', signup: 'Create account', 'forgot-password': 'Reset password', 'reset-password': 'Reset password', 'verify-email': 'Confirm email' };
  const pageTitle = category ? tr(category.title, category.cn, category.tw) : label(personalTitles[route] || 'Overview');
  useEffect(() => { document.title = route === 'home' ? label('UniMate · Your student life, connected') : `${pageTitle} · UniMate`; }, [pageTitle, route, language]);
  useEffect(() => { if (section && route === 'home') { document.getElementById(section)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); setSection(null); } }, [section, route]);
  const signedOutGate = protectedRoutes.has(route) && !auth.user;
  const displayName = auth.user?.name || '';
  const staff = auth.user?.role === 'staff';
  async function logout() { const result = await auth.signOut(); if (result.error) setActionError(result.error); else navigate('home'); }
  function tile(item: typeof categories[number] | typeof services[number]) {
    return <button className="fresh-tile" key={item.id} onClick={() => navigate(item.id)}><IconBadge name={item.icon} color={item.color} /><span><strong>{tr(item.title, item.cn, item.tw)}</strong><small>{label(item.text)}</small></span><AppIonicons name="chevron-forward" size={17} color="#9aaabb" /></button>;
  }
  function home() {
    return <>
      <section className="public-hero"><div className="public-hero-copy"><p className="fresh-eyebrow">{label("STUDENT LIFE, WITH A LITTLE COMPANY")}</p><h1>{label("Your new chapter.")}{' '}<br/><span>{label("All in one place.")}</span></h1><p>{label("Meet your people. Explore your city. Find a little help along the way. UniMate brings the everyday parts of student life together, so a new place can feel more like home.")}</p><div className="fresh-actions"><button className="fresh-button" onClick={() => navigate('signup')}>{label("Sign up")}<AppIonicons name="arrow-forward" size={18} color="currentColor"/></button><button className="fresh-text-button" onClick={() => navigate('signin')}>{label("Already a member? Sign in")}</button></div><p className="public-launch-copy">{label("A new home for your student life. Launching soon.")}</p></div><figure className="public-hero-art public-dashboard-preview"><div className="public-phone-frame"><AppScreenshot screen="dashboard" onOpen={() => setPreview('dashboard')}/></div><figcaption className="public-preview-caption">{label("The UniMate app dashboard")}{' '}<br/>{label("Preview of the app experience")}</figcaption></figure></section>
      <section className="public-intro" id="about"><p className="fresh-eyebrow">{label("MEET UNIMATE · 优你伴")}</p><h2>{label("A companion for life beyond the classroom.")}</h2><p>{label("Starting somewhere new comes with a lot of firsts. UniMate is designed to connect you with a student community, things to do, useful finds and everyday services — together in one app.")}</p></section>
      <section className="public-community public-community-preview" id="community"><div className="public-section-copy"><p className="fresh-eyebrow">{label("FIND YOUR PEOPLE")}</p><h2>{label("New faces.")}{' '}<br/>{label("Shared experiences.")}{' '}<br/><span>{label("A place to belong.")}</span></h2><p>{label("From a small question to a new friendship, make space for the conversations that turn a city into your community.")}</p><div className="public-feature-list">{[
        { icon: 'images', color: '#8b5cf6', title: 'Share your moments', text: 'A space for everyday updates, discoveries and the little highlights of student life.' },
        { icon: 'chatbox-ellipses', color: '#0799ad', title: 'Ask the student community', text: 'Use the Student Forum to ask questions, share experiences and help each other find your feet.' },
        { icon: 'people', color: '#8262DB', title: 'Turn connections into friendships', text: 'Find friends and stay in touch through personal messages and group conversations.' },
      ].map(item => <article key={item.title}><IconBadge name={item.icon as Icon} color={item.color}/><div><h3>{label(item.title)}</h3><p>{label(item.text)}</p></div></article>)}</div></div><div className="public-community-screens"><figure><div className="public-phone-frame"><AppScreenshot screen="moments" onOpen={() => setPreview('moments')}/></div><figcaption>{label("Moments")}<small>{label("App preview · Sample content")}</small></figcaption></figure><figure><div className="public-phone-frame"><AppScreenshot screen="forum" onOpen={() => setPreview('forum')}/></div><figcaption>{label("Student Forum")}<small>{label("App preview · Sample content")}</small></figcaption></figure></div></section>
      <section className="public-section" id="discover"><div className="public-section-heading"><p className="fresh-eyebrow">{label("MORE TO EXPLORE")}</p><h2>{label("Make the most of being here.")}</h2><p>{label("Your next plan, a useful find, or a new favourite place.")}</p></div><div className="public-discover-grid"><article><IconBadge name="calendar" color="#ff4657"/><h3>{label("Events worth getting out for")}</h3><p>{label("Discover student events, make plans and keep your event bookings together. Event chats give you a place to connect before you go.")}</p></article><article><IconBadge name="bag-handle" color="#854ce9"/><h3>{label("A marketplace for student life")}</h3><p>{label("Find useful items, give things a second home and manage your own listings. Message sellers to ask about a find.")}</p></article><article><IconBadge name="restaurant" color="#e95e32"/><h3>{label("Find your next favourite spot")}</h3><p>{label("Explore food recommendations and community reviews, whether you’re after a quick bite or somewhere to meet friends.")}</p></article></div></section>
      <section className="public-section public-services" id="services"><div className="public-section-heading"><p className="fresh-eyebrow">{label("A LITTLE HELP ALONG THE WAY")}</p><h2>{label("From arriving to settling in.")}</h2><p>{label("Practical services for the parts of student life that take a little organising.")}</p></div><div className="public-services-grid">{[
        { icon:'car-sport', color:'#17a957', title:'Airport transfers', text:'Plan the journey from the airport to your next chapter.' },
        { icon:'cube', color:'#00a1a7', title:'Moving', text:'Find help when it’s time to pack up and make your next move.' },
        { icon:'home', color:'#f28a18', title:'Cleaning', text:'A little support to keep your space feeling like home.' },
      ].map(item => <article key={item.title}><IconBadge name={item.icon as Icon} color={item.color}/><h3>{label(item.title)}</h3><p>{label(item.text)}</p></article>)}</div><p className="public-service-note">{label("Services are being prepared. Locations, prices and availability will be shared before bookings open.")}</p></section>
      <section className="public-account"><div><p className="fresh-eyebrow">{label("YOUR OWN UNIMATE")}</p><h2>{label("One account.")}{' '}<br/>{label("Your student life, together.")}</h2><p>{label("Your events, marketplace listings, bookings and conversations each have a place in your personal dashboard. Sign in to pick up where you left off.")}</p></div><div className="public-account-points"><span><AppIonicons name="calendar" size={20} color="#ff4657"/>{label("Your events & plans")}</span><span><AppIonicons name="bag-handle" size={20} color="#854ce9"/>{label("Your marketplace")}</span><span><AppIonicons name="receipt" size={20} color="#2487df"/>{label("Your bookings & purchases")}</span><span><AppIonicons name="chatbubbles" size={20} color="#C98712"/>{label("Your conversations")}</span></div></section>
      <section className="public-join"><p className="fresh-eyebrow">{label("YOUR NEXT CHAPTER STARTS HERE")}</p><h2>{label("Make yourself at home.")}</h2><p>{label("Get to know UniMate, and make it your own.")}</p><div className="fresh-actions"><button className="fresh-button" onClick={() => navigate('signup')}>{label("Sign up")}<AppIonicons name="arrow-forward" size={17} color="currentColor"/></button><button className="fresh-button fresh-secondary" onClick={() => navigate('signin')}>{label("Sign in")}</button></div>{!auth.configured && <small>{label("Account registration is opening soon.")}</small>}</section>
    </>;
  }
  function dashboard() {
    return staff ? <SharedBookings key={auth.user?.id} dashboard/> : <><StudentWelcomeSteps onOpen={()=>navigate('profile')}/><StudentDashboard key={auth.user?.id} navigate={navigate}/></>;
  }
  function messages() {
    return <><div className="fresh-page-heading fresh-heading-row"><h1>{label('Messages')}</h1><button className="fresh-button" onClick={() => setModal('new-message')}><AppIonicons name="create-outline" size={18} color="currentColor"/>{ui("New message")}</button></div><label className="fresh-search"><AppIonicons name="search-outline" size={20} color="#71839b"/><input aria-label={ui("Search messages")} placeholder={ui("Search messages…")} value={search} onChange={e => setSearch(e.target.value)}/></label><div className="fresh-filter-row" role="tablist" aria-label={ui("Message categories")}>{messageFilters.map(item => <button key={item} role="tab" aria-selected={filter === item} className={'fresh-filter ' + (filter === item ? 'selected' : '')} onClick={() => setFilter(item)}>{item}<span>0</span></button>)}</div><EmptyState icon="chatbubbles-outline" title={search ? ui("No matching messages") : filter === 'All' ? ui("No messages yet") : `No ${filter.toLowerCase()} conversations yet`}><p>{search ? ui("Try another name or clear your search.") : ui("Your conversations will appear here when messaging opens.")}</p></EmptyState></>;
  }
  function content() {
    if (auth.loading) return <div className="fresh-loading" role="status">{label("Opening UniMate…")}</div>;
    if(route==='owner-views')return <OwnerViews dark={dark} language={language} onToggleTheme={()=>setDark(value=>!value)} onLanguage={setLanguage}/>;
    if (authRoutes.has(route)) return <AccountForm key={route} route={route} navigate={navigate}/>;
    if (!auth.user && route !== 'support') return home();
    if (signedOutGate) return <div className="fresh-auth-wrap"><section className="fresh-auth-card"><IconBadge name="lock-closed-outline"/><p className="fresh-eyebrow">{label("YOUR UNIMATE")}</p><h1>{tr('A space of your own', '你的专属空间', '你的專屬空間')}</h1><p className="fresh-muted">{`Sign in to access ${pageTitle.toLowerCase()} and keep everything in your own account.`}</p><button className="fresh-button fresh-full" onClick={() => navigate('signin')}>{label('Sign in')}<AppIonicons name="arrow-forward" size={17} color="currentColor"/></button><p className="fresh-auth-switch">{ui("New to UniMate?")} <button className="fresh-text-button" onClick={() => navigate('signup')}>{label("Create account")}</button></p></section></div>;
    if (route === 'home') return home();
    if (route === 'dashboard') return dashboard();
    if (auth.user?.role === 'staff' && route === 'invoices') return <StaffInvoices key={auth.user.id}/>;
    if (route === 'bookings') return <SharedBookings key={auth.user?.id}/>;
    if (['airport', 'cleaning', 'moving'].includes(route)) return <SharedBookings key={`${auth.user?.id}:${route}`} initialService={route === 'airport' ? 'airport_transfer' : route as 'cleaning' | 'moving'}/>;
    if (auth.user && (route === 'messages' || route === 'support')) return <SharedSupport key={auth.user.id+route} startNew={route==='support'}/>;
    if(route==='market'||route==='listings')return <Marketplace/>;
    if(route==='food')return <FoodReviews onLeaderboard={()=>navigate('food-leaderboard')} onVerify={()=>navigate('profile')}/>;
    if(route==='food-leaderboard')return <FoodLeaderboard onBack={()=>navigate('food')} onConnections={()=>navigate('connections')}/>;
    if(route==='connections')return <StudentConnections/>;
    if (route === 'profile') return <><div className="fresh-page-heading"><p className="fresh-eyebrow">{label("PERSONAL")}</p><h1>{label('My account')}</h1><p className="fresh-muted">{ui("Your personal account details.")}</p></div><section className="fresh-account-panel"><div className="fresh-account-identity"><IconBadge name="person" color="#2DBE78"/><div><h2>{displayName || ui("Your account")}</h2><p className="fresh-muted">{staff ? ui("UniMate staff") : ui("UniMate student")}</p>{!staff&&<span className={'student-status '+(auth.user?.studentVerified?'is-verified':'is-unverified')}>{auth.user?.studentVerified?'✓':'?'} {ui(auth.user?.studentVerified?'Verified student':'Unverified')}</span>}</div></div><dl><div><dt>{label("Email address")}</dt><dd>{auth.user?.email}</dd></div><div><dt>{ui("Email status")}</dt><dd>{ui("Confirmed")}</dd></div></dl><div className="fresh-actions"><button className="fresh-button fresh-secondary" onClick={() => navigate('forgot-password')}>{label("Reset password")}</button><button className="fresh-text-button" onClick={logout}>{label("Sign out")}</button></div></section>{!staff&&<StudentOnboarding key={auth.user?.id}/>}</>;
    if (route === 'support') return <><div className="fresh-page-heading"><p className="fresh-eyebrow">{label("PERSONAL")}</p><h1>{label('Support')}</h1><p className="fresh-muted">{label("A little help finding your way.")}</p></div><div className="fresh-faq"><details open><summary>{label("How do I create an account?")}</summary><p>{label(auth.configured ? 'Choose Create account, enter your details and confirm your email. You can then sign in to your own dashboard.' : 'Registration is being prepared. The Create account page will become available when sign-up opens.')}</p><button className="fresh-text-button" onClick={() => navigate('signup')}>{label("Go to Create account →")}</button></details><details><summary>{label("Can I book a service or buy an item yet?")}</summary><p>{label("Signed-in students can request cleaning, moving and airport transfer services. The team will confirm availability and a quote before the service is booked. Marketplace purchases are not open yet.")}</p></details><details><summary>{label("Where are my messages and bookings?")}</summary><p>{label("Sign in to access your personal pages. Only your own activity belongs in your account. Service requests, booking updates and shared photos are saved to your account.")}</p></details><details><summary>{label("How do desktop and mobile views work?")}</summary><p>{label("UniMate automatically fits your screen. You can also choose Automatic, Desktop or Mobile using the display menu at the bottom of the page.")}</p></details><details><summary>{label("Is live support available?")}</summary><p>{label("Sign in and choose UniMate Support to message our team. Replies appear in your Messages inbox.")}</p></details></div></>;
    if (category) return <><div className="fresh-page-heading"><p className="fresh-eyebrow">{services.some(s => s.id === route) ? 'SERVICES' : ['friends', 'forum', 'connections'].includes(route) ? 'SOCIAL' : 'DISCOVER'}</p><h1>{pageTitle}</h1><p className="fresh-muted">{category.text}</p></div><EmptyState icon={category.icon} title={services.some(s => s.id === route) ? ui("Bookings are coming soon") : ui("A new space, ready to grow")}><p>{category.detail}</p></EmptyState></>;
    if (['my-events', 'listings', 'bookings'].includes(route)) return <><div className="fresh-page-heading"><p className="fresh-eyebrow">{ui("YOUR SPACE")}</p><h1>{pageTitle}</h1></div><EmptyState icon={route === 'my-events' ? 'calendar-outline' : 'receipt-outline'} title={route === 'my-events' ? ui("No events yet") : ui("No bookings or purchases yet")}><p>{ui("Your activity will appear here when these features open.")}</p></EmptyState></>;
    return <EmptyState icon="compass-outline" title={ui("Let’s get you back on track")}><p>{ui("This page isn’t available.")}</p><button className="fresh-button" onClick={() => navigate(auth.user ? 'dashboard' : 'home')}>{ui("Go to overview")}</button></EmptyState>;
  }
  const embeddedOwner=route==='owner-views'&&new URLSearchParams(window.location.search).get('owner-embed')==='1';
  useEffect(()=>{if(!embeddedOwner)return;const expected=new URL(apiBase).origin;const adminExpected=expected.replace('://api.', '://admin.');const listener=(event:MessageEvent)=>{if(event.source!==window.parent||![expected,adminExpected].includes(event.origin)||event.data?.type!=='unimate-preview-preferences')return;if(['EN','简体','繁體'].includes(event.data.language))setLanguage(event.data.language);if(['dark','light'].includes(event.data.theme))setDark(event.data.theme==='dark');};window.addEventListener('message',listener);return()=>window.removeEventListener('message',listener);},[embeddedOwner]);
  const publicView = !auth.user || authRoutes.has(route) || route==='owner-views';
  const publicLinks = <>{[['community', 'Community'], ['discover', 'Discover'], ['services', 'Services']].map(([id, title]) => <a key={id} href={'#' + id} onClick={e => { e.preventDefault(); navigate('home'); setSection(id); }}>{label(title)}</a>)}</>;
  return <WebsiteLanguageContext.Provider value={language}><WebsiteLayoutFrame language={language}><div className={'fresh-app' + (publicView ? ' fresh-public' : '')+(embeddedOwner?' embedded-owner':'')}><a className="fresh-skip" href="#fresh-main">{label("Skip to content")}</a>
    <header className="fresh-header">
      <a href="#/home" className="fresh-brand" onClick={e => { e.preventDefault(); navigate(auth.user ? 'dashboard' : 'home'); }}><UniMateLogo darkMode={dark}/></a>
      {publicView ? <>{route!=='owner-views'&&<nav className="public-header-nav" aria-label={label("About UniMate")}>{publicLinks}</nav>}<div className="public-header-controls"><button type="button" className="fresh-icon-button public-theme-button" aria-label={label(dark ? 'Switch to light mode' : 'Switch to dark mode')} onClick={() => setDark(value => !value)}><AppIonicons name={dark ? 'sunny-outline' : 'moon-outline'} size={20} color="currentColor"/></button><LanguagePicker value={language} onChange={setLanguage} label={label("Website language")}/></div><div className="public-header-actions">{route==='owner-views'?<a className="fresh-button owner-admin-link" href={apiBase+'/owner-login'} aria-label={ui("Owner sign-in and security")}><AppIonicons name="shield-checkmark-outline" size={17} color="currentColor"/><span>{ui("Owner")}</span></a>:<><button className="fresh-text-button public-signin" onClick={() => navigate('signin')}>{label("Sign in")}</button><button className="fresh-button" onClick={() => navigate('signup')}>{label("Sign up")}</button></>}</div></> : <div className="fresh-header-actions"><button className="fresh-icon-button" aria-label={label("Notifications")} onClick={() => setModal('notifications')}><AppIonicons name="notifications-outline" size={21} color="currentColor"/></button><button className="fresh-icon-button" aria-label={label(dark ? 'Switch to light mode' : 'Switch to dark mode')} onClick={() => setDark(!dark)}><AppIonicons name={dark ? 'sunny-outline' : 'moon-outline'} size={20} color="currentColor"/></button><LanguagePicker value={language} onChange={setLanguage} label={label("Website language")}/><button className="fresh-icon-button fresh-location" aria-label={label("Location")} onClick={() => setModal('location')}><AppIonicons name="location-outline" size={20} color="currentColor"/></button><button className="fresh-button fresh-header-signin" onClick={() => navigate('profile')}>{label("My account")}</button></div>}
    </header>
    <div className="fresh-body">{!publicView && <div className="fresh-desktop-sidebar">{staff ? <StaffNavigation current={activeRoute} navigate={navigate} logout={() => void logout()}/> : <WebsiteSidebar language={language} current={activeRoute} onNavigate={navigate} onLogout={() => void logout()} liveAccount hasUnread={false}/>}</div>}<main id="fresh-main" className="fresh-main" ref={main} tabIndex={-1}><div className="fresh-content">{(actionError || auth.error) && <p className="fresh-error" role="alert">{ui(actionError || auth.error || "")}</p>}{auth.user?.requestedAccountType&&auth.user.role!=='staff'&&route!=='owner-views'&&<p className="fresh-notice">{auth.user.requestedAccountType==='seller'?ui("Seller"):auth.user.requestedAccountType==='organisation'?ui("Organisation"):ui("Staff")} {ui("Application status")}: <strong>{ui(auth.user.approvalStatus || "")}</strong>. {auth.user.approvalStatus==='approved'?ui("Your request has been approved. Some specialist workspace tools are still being prepared."):ui("UniMate will review your application before specialist tools become available.")}</p>}{!publicView&&<div className="account-support-toolbar"><button type="button" className="account-support-button" aria-label={ui("Contact UniMate Support")} aria-pressed={route==='support'} onClick={()=>navigate('support')}><AppIonicons name="headset" size={18} color="currentColor"/><span>{ui("UniMate Support")}</span></button></div>}{content()}<footer className="fresh-footer"><span>© {new Date().getFullYear()} UniMate 优你伴</span><div className="fresh-footer-tools">{publicView && <button className="fresh-text-button" onClick={() => navigate('support')}>{label("Help")}</button>}<WebsiteDisplayControl language={language}/><AnalyticsConsent signedIn={!!auth.user} loading={auth.loading} route={route} language={language}/></div></footer></div></main></div>
    {!publicView && <nav className="fresh-mobile-nav" aria-label={label("Quick navigation")}>{(staff ? [{id:'home',title:'Overview',icon:'home'},{id:'bookings',title:'Jobs',icon:'calendar'},{id:'invoices',title:'Invoices',icon:'receipt'},{id:'messages',title:'Messages',icon:'chatbubbles'},{id:'profile',title:'Account',icon:'person'}] : [{id:'home',title:'Home',icon:'home'},{id:'connections',title:'Friends',icon:'people'},{id:'friends',title:'Moments',icon:'images'},{id:'messages',title:'Messages',icon:'chatbubbles'},{id:'profile',title:'Profile',icon:'person'}]).map(item => <a key={item.id} href={'#/'+item.id} className={activeRoute === item.id ? 'is-active' : ''} aria-current={activeRoute === item.id ? 'page' : undefined} onClick={e => {e.preventDefault();navigate(item.id as Route);}}><>{item.id === 'friends' ? <UniMateMomentsIcon size={24} active={activeRoute === item.id}/> : <AppIonicons name={item.icon as Icon} size={20} color={activeRoute === item.id ? (mobileNavigationColors[item.id] || '#1683DF') : 'var(--muted, #71839B)'}/>}</><span>{label(item.title)}</span></a>)}</nav>}
    {preview && <Modal title={label(screenshotTitles[preview])} onClose={() => setPreview(null)}><div className="public-preview-expanded"><Image source={appScreenshots[preview]} accessibilityLabel={label('{screen} app preview', { screen: label(screenshotTitles[preview]) })} style={{ width: '100%', height: '100%' }} resizeMode="contain"/></div><p className="public-preview-caption">{label("App preview. Illustrative content shows how UniMate looks.")}</p></Modal>}
    {menu && <Modal title={label("Explore UniMate")} onClose={() => setMenu(false)}>{publicView ? <nav className="public-menu-links" aria-label={label("About UniMate")}>{publicLinks}<button className="fresh-button fresh-secondary" onClick={() => navigate('signin')}>{label("Sign in")}</button><button className="fresh-button" onClick={() => navigate('signup')}>{label("Sign up")}</button></nav> : staff ? <StaffNavigation current={activeRoute} navigate={navigate} logout={() => void logout()}/> : <WebsiteSidebar language={language} current={activeRoute} onNavigate={navigate} onLogout={() => void logout()} liveAccount hasUnread={false}/>}</Modal>}
    {modal && <Modal title={modal === 'notifications' ? ui("Notifications") : modal === 'location' ? ui("Your location") : ui("New message")} onClose={() => setModal(null)}>{modal === 'notifications' ? <EmptyState icon="notifications-outline" title={ui("You’re all caught up")}><p>{ui("You have no notifications yet.")}</p></EmptyState> : modal === 'location' ? <EmptyState icon="location-outline" title={ui("Service locations are coming soon")}><p>{ui("We’ll show available locations here when services launch.")}</p></EmptyState> : <><label className="fresh-search"><AppIonicons name="search-outline" size={20} color="#71839b"/><input aria-label={ui("Find a recipient")} placeholder={ui("Search by name…")} value={search} onChange={e => setSearch(e.target.value)}/></label><EmptyState icon="people-outline" title={ui("No recipients yet")}><p>{ui("Friends and available service contacts will appear here when messaging opens.")}</p></EmptyState></>}</Modal>}
  </div></WebsiteLayoutFrame></WebsiteLanguageContext.Provider>;
}
export default function PublicWebsite() { return <AuthProvider><PublicApp/></AuthProvider>; }

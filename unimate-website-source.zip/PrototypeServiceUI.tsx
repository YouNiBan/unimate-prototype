// Generated from the GitHub prototype App.tsx; do not hand-edit.
// Source SHA-256: eea72df2e692fb83de2dcda830ad7d94abdc363e86d290a18b27d00414ffe86f
export type CanonicalGoingFriend={username:string;color:string;initials:string;fullName:string};
export type CanonicalEvent={title:string;zh:string;date:string;time:string;place:string;price:string;age:string;lastEntry:string;category:string;tag:string;going:number;spotsLeft:number;releaseAt:string;summary:string;image:string};

import React, { useContext, useEffect, useMemo, useRef, useState } from "react";

import {
  Alert,
  Image,
  KeyboardAvoidingView,
  Keyboard,
  Linking,
  Modal,
  Platform,
  Pressable as NativePressable,
  Share,
  ScrollView as NativeScrollView,
  StatusBar,
  StyleSheet,
  Text as NativeText,
  TextInput as NativeTextInput,
  useWindowDimensions,
  View as NativeView,
} from "react-native";

import { Ionicons as NativeIonicons } from "@expo/vector-icons";

import * as ImagePicker from "expo-image-picker";

import { findAddresses, resolveAddress, type AddressSuggestion } from "./address-lookup";


const DarkModeContext = React.createContext(false);


const darkBackgrounds: Record<string, string> = {
  "#FFFFFF": "#162338",
  WHITE: "#162338",
  "#F4F7FB": "#0B1423",
  "#F2F7FC": "#21334B",
  "#F7FAFD": "#121F32",
  "#F8FBFE": "#121F32",
  "#F8FAFC": "#121F32",
  "#FBFDFF": "#121F32",
  "#F7FBFF": "#121F32",
  "#F8FBFF": "#121F32",
  "#F2F6FB": "#21334B",
  "#F3F7FB": "#142237",
  "#F3F6F9": "#172438",
  "#EAF5FF": "#102C47",
  "#E8F4FF": "#102C47",
  "#DCEEFF": "#102C47",
  "#DCEBFF": "#102C47",
  "#EDF3FA": "#17283D",
  "#F2F8FE": "#132A43",
  "#F4FAFF": "#132A43",
  "#ECF9F2": "#123326",
  "#E9F8F0": "#123326",
  "#E8F8EF": "#123326",
  "#FFF0F1": "#351D27",
  "#FFF1F2": "#351D27",
  "#FFF4F5": "#351D27",
  "#FFF7F7": "#351D27",
  "#FFF5D9": "#382D16",
  "#FFF5E8": "#35291B",
  "#F7F2FF": "#281F3B",
  "#EEF2F6": "#1A2739",
  "#F2F5F8": "#1A2739",
  "#E7ECF2": "#1A2739",
  "#F5FAFF": "#132A43",
  "#F2F8FF": "#102C47",
  "#E3F1FF": "#173957",
  "#FFF8E9": "#382E18",
  "#F0FAF4": "#123326",
  "#D9F4E5": "#1B4933",
  "#CAD3DF": "#60718A",
};


const darkText: Record<string, string> = {
  "#08265F": "#F3F7FF",
  "#16213D": "#E9F0FA",
  "#71809B": "#A9B7CC",
  "#0878E6": "#5BB0FF",
  "#23B866": "#63D894",
  "#FF5360": "#FF7D88",
  "#6D3EEB": "#B096FF",
  "#7542C8": "#B89BFF",
  "#F28A18": "#FFC06B",
  "#B97A0D": "#F3C66B",
  "#B67A16": "#F3C66B",
  "#D48B16": "#F3C66B",
  "#A76A12": "#F3C66B",
  "#B97913": "#F3C66B",
  "#00A1A7": "#58D7DB",
  "#713CE0": "#B79DFF",
  "#2CB66D": "#70D99A",
  "#F2B94B": "#F5CA72",
  "#FF5A68": "#FF8792",
  "#397653": "#82D2A4",
  "#2878C8": "#78BFFF",
  "#8B4047": "#F3A1AA",
  "#A0AABB": "#8392A9",
};


const darkBorders: Record<string, string> = {
  "#FFFFFF": "#33445D",
  WHITE: "#33445D",
  "#E2EAF4": "#2D3D55",
  "#DEE6EF": "#304158",
  "#DCE8F3": "#30445E",
  "#D8E5F1": "#30445E",
  "#D9E3ED": "#30445E",
  "#DCE6F0": "#30445E",
  "#E1E6EC": "#304158",
  "#BDD9F5": "#315D83",
  "#BFD7ED": "#355879",
  "#CDE4F8": "#315D83",
  "#CFE3F8": "#315D83",
  "#F3CDD0": "#6A3843",
};


const parseThemeHex = (value: string) => {
  const match = /^#([0-9a-f]{6})$/i.exec(value);
  if (!match) return null;
  const raw = match[1];
  return {
    r: parseInt(raw.slice(0, 2), 16),
    g: parseInt(raw.slice(2, 4), 16),
    b: parseInt(raw.slice(4, 6), 16),
  };
};


const darkFallbackColor = (
  value: string,
  role: "background" | "text" | "border",
) => {
  const rgb = parseThemeHex(value);
  if (!rgb) return value;
  const { r, g, b } = rgb;
  const lightness = (Math.max(r, g, b) + Math.min(r, g, b)) / 510;
  if (role === "background" && lightness > 0.78) {
    if (r > g + 18 && r > b + 18) return "#38202A";
    if (g > r + 15 && g > b + 10) return "#173326";
    if (b > r + 15) return "#142D47";
    if (r > 225 && g > 205 && b < 185) return "#382E18";
    return "#172438";
  }
  if (role === "border" && lightness > 0.58) return "#34465F";
  if (role === "text" && lightness < 0.52) {
    if (b > r * 1.25 && b > g * 1.08) return "#69B8FF";
    if (g > r * 1.18 && g > b * 1.05) return "#6FD79A";
    if (r > 120 && g > 80 && b < 70) return "#F3C66B";
    if (r > g * 1.2 && r > b * 1.15) return "#FF8D98";
    return "#E6EDF7";
  }
  return value;
};


const mapThemeColor = (
  value: unknown,
  map: Record<string, string>,
  role: "background" | "text" | "border",
) => {
  if (typeof value !== "string") return value;
  return map[value.toUpperCase()] || darkFallbackColor(value, role);
};


const themedStyle = (style: any, darkMode: boolean) => {
  if (!darkMode || !style) return style;
  const flat = StyleSheet.flatten(style);
  if (!flat || typeof flat !== "object") return style;
  const next: Record<string, unknown> = { ...flat };
  if (next.backgroundColor)
    next.backgroundColor = mapThemeColor(
      next.backgroundColor,
      darkBackgrounds,
      "background",
    );
  if (next.color)
    next.color = mapThemeColor(next.color, darkText, "text");
  if (next.borderColor)
    next.borderColor = mapThemeColor(next.borderColor, darkBorders, "border");
  if (next.borderTopColor)
    next.borderTopColor = mapThemeColor(
      next.borderTopColor,
      darkBorders,
      "border",
    );
  if (next.borderBottomColor)
    next.borderBottomColor = mapThemeColor(
      next.borderBottomColor,
      darkBorders,
      "border",
    );
  if (next.borderLeftColor)
    next.borderLeftColor = mapThemeColor(
      next.borderLeftColor,
      darkBorders,
      "border",
    );
  if (next.borderRightColor)
    next.borderRightColor = mapThemeColor(
      next.borderRightColor,
      darkBorders,
      "border",
    );
  return next;
};


function Ionicons(props: React.ComponentProps<typeof NativeIonicons>) {
  const darkMode = useContext(DarkModeContext);
  const color = darkMode
    ? mapThemeColor(props.color, darkText, "text")
    : props.color;
  return <NativeIonicons {...props} color={color as any} />;
}


function View(props: React.ComponentProps<typeof NativeView>) {
  const darkMode = useContext(DarkModeContext);
  return <NativeView {...props} style={themedStyle(props.style, darkMode)} />;
}


function SwitchThumb({ on }: { on: boolean }) {
  // Keep the thumb bright in dark mode; the general surface theme darkens white Views.
  return <NativeView style={[styles.toggleKnob, on && styles.toggleKnobOn]} />;
}


function Text(props: React.ComponentProps<typeof NativeText>) {
  const darkMode = useContext(DarkModeContext);
  return <NativeText {...props} style={themedStyle(props.style, darkMode)} />;
}


function TextInput(props: React.ComponentProps<typeof NativeTextInput>) {
  const darkMode = useContext(DarkModeContext);
  return (
    <NativeTextInput
      {...props}
      style={themedStyle(props.style, darkMode)}
      placeholderTextColor={darkMode ? "#B7C8DB" : props.placeholderTextColor}
      selectionColor={darkMode ? "#5BB0FF" : props.selectionColor}
    />
  );
}


const ScrollView = React.forwardRef<
  React.ElementRef<typeof NativeScrollView>,
  React.ComponentProps<typeof NativeScrollView>
>((props, ref) => {
  const darkMode = useContext(DarkModeContext);
  return (
    <NativeScrollView
      keyboardShouldPersistTaps="handled"
      {...props}
      ref={ref}
      style={themedStyle(props.style, darkMode)}
      contentContainerStyle={themedStyle(props.contentContainerStyle, darkMode)}
    />
  );
});


function Pressable(props: React.ComponentProps<typeof NativePressable>) {
  const darkMode = useContext(DarkModeContext);
  const sourceStyle = props.style;
  const style =
    typeof sourceStyle === "function"
      ? (state: any) => themedStyle(sourceStyle(state), darkMode)
      : themedStyle(sourceStyle, darkMode);
  return <NativePressable {...props} style={style as any} />;
}

type Language = "EN" | "简体" | "繁體";


const tr = (
  language: Language,
  en: string,
  simplified: string,
  traditional = simplified,
) => (language === "EN" ? en : language === "简体" ? simplified : traditional);

const dateKey = (date: Date) =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;

const dateFromKey = (value: string) => {
  const [year, month, day] = value.split("-").map(Number);
  return new Date(year, month - 1, day);
};

const bookingDateFromToday = (daysAhead = 7) => {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() + daysAhead);
  return dateKey(date);
};

const formatBookingDate = (value: string, language: Language) =>
  dateFromKey(value).toLocaleDateString(
    language === "EN" ? "en-GB" : language === "简体" ? "zh-CN" : "zh-TW",
    { day: "numeric", month: "long", year: "numeric" },
  );

const formatStaffBookingDate = (value: string) => { const date = dateFromKey(value); return `${date.getDate()} ${["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][date.getMonth()]} ${date.getFullYear()}`; };

const categoryLabel = (language: Language, category: string) =>
  ({
    All: tr(language, "All", "全部", "全部"),
    Sports: tr(language, "Sports", "体育", "體育"),
    Parties: tr(language, "Parties", "派对", "派對"),
    "House parties": tr(language, "House parties", "家庭派对", "家庭派對"),
    Culture: tr(language, "Culture", "文化", "文化"),
    Trips: tr(language, "Trips", "旅行", "旅行"),
    "Club events": tr(language, "Club events", "夜店活动", "夜店活動"),
    Other: tr(language, "Other", "其他", "其他"),
  })[category] || category;


type PhotoSource = "camera" | "library";

type PhotoPickerOptions = {
  multiple?: boolean;
  limit?: number;
  allowsEditing?: boolean;
  aspect?: [number, number];
  quality?: number;
};


async function selectPhotoUris(
  language: Language,
  source: PhotoSource,
  options: PhotoPickerOptions = {},
) {
  const permission =
    source === "camera"
      ? await ImagePicker.requestCameraPermissionsAsync()
      : await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!permission.granted) {
    Alert.alert(
      source === "camera"
        ? tr(
            language,
            "Camera access is required",
            "需要相机权限",
            "需要相機權限",
          )
        : tr(
            language,
            "Photo access is required",
            "需要照片访问权限",
            "需要相片存取權限",
          ),
      tr(
        language,
        "Allow access in your device settings, then try again.",
        "请在设备设置中允许权限后重试。",
        "請在裝置設定中允許權限後重試。",
      ),
    );
    return [];
  }
  const common = {
    mediaTypes: ["images"] as ImagePicker.MediaType[],
    quality: options.quality ?? 0.8,
  };
  const result =
    source === "camera"
      ? await ImagePicker.launchCameraAsync({
          ...common,
          allowsEditing: options.allowsEditing ?? false,
          aspect: options.aspect,
        })
      : await ImagePicker.launchImageLibraryAsync({
          ...common,
          allowsEditing: options.allowsEditing ?? false,
          aspect: options.aspect,
          allowsMultipleSelection: options.multiple ?? false,
          selectionLimit: options.limit,
        });
  return result.canceled ? [] : result.assets.map((asset) => asset.uri);
}


function askPhotoSource(
  language: Language,
  onSelect: (source: PhotoSource) => void,
) {
  Alert.alert(
    tr(language, "Add a photo", "添加照片", "加入相片"),
    tr(
      language,
      "Take a new photo or choose one from your photo library.",
      "拍摄新照片，或从照片库中选择。",
      "拍攝新相片，或從相片庫中選擇。",
    ),
    [
      {
        text: tr(language, "Open camera", "打开相机", "開啟相機"),
        onPress: () => onSelect("camera"),
      },
      {
        text: tr(language, "Photo library", "照片库", "相片庫"),
        onPress: () => onSelect("library"),
      },
      { text: tr(language, "Cancel", "取消", "取消"), style: "cancel" },
    ],
  );
}


const palette = {
  navy: "#08265F",
  blue: "#0878E6",
  sky: "#EAF5FF",
  green: "#23B866",
  coral: "#FF5360",
  ink: "#16213D",
  muted: "#71809B",
  line: "#E2EAF4",
  white: "#FFFFFF",
};


function EventCard({
  event,
  language,
  onOpen,
  favourite = false,
  onToggleFavourite,
  recommendationReason,
  reserved = false,
  cancelPending = false,
  onReserve,
  onCancelReservation,
  goingFriends = [],
}: {
  event: CanonicalEvent;
  language: Language;
  onOpen?: () => void;
  favourite?: boolean;
  onToggleFavourite?: () => void;
  recommendationReason?: string;
  reserved?: boolean;
  cancelPending?: boolean;
  onReserve?: () => void;
  onCancelReservation?: () => void;
  goingFriends?: Array<CanonicalGoingFriend>;
}) {
  const dates=event.date,places=event.place,tags=event.tag,title=language==="EN"?event.title:(event.zh||event.title);
  const price=event.price==="Free"?tr(language,"Free","免费","免費"):event.price;
  const soldOut = event.spotsLeft === 0;
  return (
    <Pressable
      style={styles.eventCard}
      onPress={
        onOpen || (() => Alert.alert(title, `${dates} · ${places}\n${price}`))
      }
    >
      <Image source={{ uri: event.image }} style={styles.eventImage} />
      <View style={styles.eventTag}>
        <Text style={styles.eventTagText}>{tags}</Text>
      </View>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={
          favourite
            ? tr(language, "Remove from favourites", "取消收藏", "取消收藏")
            : tr(language, "Add to favourites", "添加到收藏", "加入收藏")
        }
        style={[styles.heart, favourite && styles.heartFavourite]}
        onPress={(eventPress) => {
          eventPress.stopPropagation?.();
          onToggleFavourite?.();
        }}
      >
        <Ionicons
          name={favourite ? "heart" : "heart-outline"}
          size={22}
          color="white"
        />
      </Pressable>
      <View style={styles.eventBody}>
        {recommendationReason && (
          <View style={styles.eventRecommendation}>
            <Ionicons name="sparkles" size={14} color={palette.blue} />
            <Text style={styles.eventRecommendationText}>{recommendationReason}</Text>
          </View>
        )}
        <View style={styles.eventTitleLine}>
          <Text style={styles.eventTitle}>{title}</Text>
          <Text style={styles.categoryBadge}>
            {categoryLabel(language, event.category)}
          </Text>
        </View>
        <View style={styles.eventFacts}>
          <View style={styles.eventFact}>
            <Ionicons name="calendar-outline" size={15} color={palette.blue} />
            <View>
              <Text style={styles.eventFactLabel}>
                {tr(language, "Date", "日期", "日期")}
              </Text>
              <Text style={styles.eventFactValue}>{dates}</Text>
            </View>
          </View>
          <View style={styles.eventFact}>
            <Ionicons name="time-outline" size={15} color={palette.blue} />
            <View>
              <Text style={styles.eventFactLabel}>
                {tr(language, "Time", "时间", "時間")}
              </Text>
              <Text style={styles.eventFactValue}>{event.time}</Text>
            </View>
          </View>
          <View style={styles.eventFact}>
            <Ionicons name="enter-outline" size={15} color={palette.blue} />
            <View>
              <Text style={styles.eventFactLabel}>
                {tr(language, "Last entry", "最晚入场", "最晚入場")}
              </Text>
              <Text style={styles.eventFactValue}>{event.lastEntry}</Text>
            </View>
          </View>
          <View style={styles.eventFact}>
            <Ionicons name="location-outline" size={15} color={palette.blue} />
            <View style={{ flex: 1 }}>
              <Text style={styles.eventFactLabel}>
                {tr(language, "Location", "地点", "地點")}
              </Text>
              <Text style={styles.eventFactValue} numberOfLines={1}>
                {places}
              </Text>
            </View>
          </View>
        </View>
        {goingFriends.length > 0 && (
          <View style={styles.eventFriendsGoing}>
            <View style={styles.eventFriendAvatars}>
              {goingFriends.slice(0, 3).map((friend) => <View key={friend.username} style={[styles.eventFriendAvatar, { backgroundColor: friend.color }]}><Text style={styles.eventFriendInitials}>{friend.initials}</Text></View>)}
            </View>
            <Text style={styles.eventFriendsText} numberOfLines={1}>{goingFriends.map((friend) => friend.fullName.split(" ")[0]).join(" & ")} {tr(language, "going", "将参加", "將參加")}</Text>
          </View>
        )}
        <View style={styles.eventReleaseCard}>
          <Ionicons
            name={soldOut ? "alarm-outline" : "calendar-clear-outline"}
            size={17}
            color={soldOut ? "#B97A0D" : palette.blue}
          />
          <View style={{ flex: 1 }}>
            <Text style={styles.eventReleaseTitle}>
              {soldOut
                ? tr(language, "Next ticket release", "下一次放票", "下一次放票")
                : event.price === "Free"
                  ? tr(language, "Spot reservations opened", "名额已开放", "名額已開放")
                  : tr(language, "Tickets went on sale", "门票已开售", "門票已開售")}
            </Text>
            <Text style={styles.eventReleaseText}>{event.releaseAt}</Text>
          </View>
          {soldOut && <Text style={styles.eventReleaseReminder}>{tr(language, "Set reminder", "设置提醒", "設定提醒")}</Text>}
        </View>
        <View style={styles.eventAttendance}>
          <View style={styles.eventAttendanceItem}>
            <Ionicons name="people-outline" size={18} color={palette.blue} />
            <View>
              <Text style={styles.eventAttendanceValue}>{event.going + (reserved ? 1 : 0)}</Text>
              <Text style={styles.eventAttendanceLabel}>
                {tr(language, "Going", "人参加", "人參加")}
              </Text>
            </View>
          </View>
          <View style={styles.eventAttendanceDivider} />
          <View style={styles.eventAttendanceItem}>
            <Ionicons
              name={soldOut ? "close-circle" : "ticket-outline"}
              size={18}
              color={soldOut ? palette.coral : palette.blue}
            />
            <View>
              <Text
                style={[
                  styles.eventAttendanceValue,
                  soldOut && { color: palette.coral },
                ]}
              >
                {soldOut
                  ? tr(language, "Sold out", "已售罄", "已售罄")
                  : event.spotsLeft - (reserved ? 1 : 0)}
              </Text>
              {!soldOut && (
                <Text style={styles.eventAttendanceLabel}>
                  {tr(language, "Spots left", "个名额", "個名額")}
                </Text>
              )}
            </View>
          </View>
        </View>
        <View style={styles.eventFooter}>
          <Text style={styles.price}>{price}</Text>
          {event.price === "Free" && (!soldOut || reserved) ? (
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={reserved ? (cancelPending ? tr(language, "Confirm cancellation", "确认取消预订", "確認取消預訂") : tr(language, "Cancel reservation", "取消预订", "取消預訂")) : tr(language, "Reserve my place", "预留名额", "預留名額")}
              style={[styles.confirmGoingButton, reserved && styles.cancelGoingButton]}
              onPress={(eventPress) => {
                eventPress.stopPropagation?.();
                if (reserved) onCancelReservation?.();
                else onReserve?.();
              }}
            >
              <Ionicons name={reserved ? "close-circle-outline" : "checkmark-circle"} size={16} color={reserved ? palette.coral : "white"} />
              <Text style={[styles.confirmGoingText, reserved && styles.cancelGoingText]}>
                {reserved
                  ? cancelPending
                    ? tr(language, "Confirm cancellation", "确认取消预订", "確認取消預訂")
                    : tr(language, "Cancel reservation", "取消预订", "取消預訂")
                  : tr(language, "Reserve my place", "预留名额", "預留名額")}
              </Text>
            </Pressable>
          ) : (
            <View style={styles.viewEventHint}>
              <Text style={styles.viewEventHintText}>
                {tr(language, "View event", "查看活动", "查看活動")}
              </Text>
              <Ionicons name="chevron-forward" size={14} color={palette.blue} />
            </View>
          )}
        </View>
      </View>
    </Pressable>
  );
}


function SelectField({
  label,
  value,
  options,
  onChange,
  hint,
  schedule = false,
  formatOption = (option) => option,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (value: string) => void;
  hint?: string;
  schedule?: boolean;
  formatOption?: (value: string) => string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <View style={[styles.selectWrap, schedule && styles.scheduleSelectWrap]}>
      {!schedule && <Text style={styles.fieldLabel}>{label}</Text>}
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={schedule ? `${label}: ${formatOption(value)}` : undefined}
        accessibilityState={{ expanded: open }}
        style={[styles.selectField, schedule && styles.scheduleSelectField, open && styles.selectFieldOpen]}
        onPress={() => setOpen(!open)}
      >
        {schedule ? <>
          <View style={styles.eventScheduleIcon}><Ionicons name="time-outline" size={19} color={palette.blue} /></View>
          <View style={{ flex: 1 }}><Text style={styles.eventScheduleLabel}>{label}</Text><Text style={styles.eventTimeValue}>{formatOption(value)}</Text></View>
        </> : <Text style={styles.selectValue}>{formatOption(value)}</Text>}
        <Ionicons
          name={open ? "chevron-up" : "chevron-down"}
          size={17}
          color={palette.blue}
        />
      </Pressable>
      {hint && <Text style={styles.fieldHint}>{hint}</Text>}
      {open && (
        <View style={styles.selectMenu}>
          <ScrollView
            style={styles.selectMenuScroll}
            nestedScrollEnabled
            showsVerticalScrollIndicator
          >
            {options.map((option) => (
              <Pressable
                key={option}
                style={[
                  styles.selectOption,
                  option === value && styles.selectOptionActive,
                ]}
                onPress={() => {
                  onChange(option);
                  setOpen(false);
                }}
              >
                <Text
                  style={[
                    styles.selectOptionText,
                    option === value && styles.selectOptionTextActive,
                  ]}
                >
                  {formatOption(option)}
                </Text>
                {option === value && (
                  <Ionicons name="checkmark" size={17} color={palette.blue} />
                )}
              </Pressable>
            ))}
          </ScrollView>
        </View>
      )}
    </View>
  );
}


type ServiceCheckoutOrder = {
  service: "airport" | "cleaning" | "moving";
  title: string;
  details: string;
  when: string;
  total: number;
  dueNow: number;
  note: string;
  bookingDate?: string;
  bookingTime?: string;
  bookingAddress?: string;
  intake?: { fields: { label: string; value: string }[]; photos: string[] };
};


const addressLookupKey = process.env.EXPO_PUBLIC_IDEAL_POSTCODES_API_KEY || "";


function AddressLookupField({ language, label, value, onChange }: {
  language: Language; label: string; value: string; onChange: (value: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [suggestions, setSuggestions] = useState<AddressSuggestion[]>([]);
  const [busy, setBusy] = useState<"search" | "resolve" | null>(null);
  const [error, setError] = useState(false);
  const version = useRef(0);
  const selection = useRef<AbortController | null>(null);
  const t = (en: string, cn: string, tw: string) => tr(language, en, cn, tw);
  const stop = () => {
    version.current += 1;
    selection.current?.abort();
    selection.current = null;
    setEditing(false);
    setSuggestions([]);
    setBusy(null);
    setError(false);
  };
  useEffect(() => () => { version.current += 1; selection.current?.abort(); }, []);
  useEffect(() => {
    if (!editing || !addressLookupKey || value.trim().length < 3) return;
    const requestVersion = ++version.current;
    const controller = new AbortController();
    setBusy("search");
    const timer = setTimeout(async () => {
      try {
        const found = await findAddresses(value, addressLookupKey, controller.signal);
        if (!controller.signal.aborted && version.current === requestVersion) setSuggestions(found);
      } catch {
        if (!controller.signal.aborted && version.current === requestVersion) setError(true);
      } finally {
        if (!controller.signal.aborted && version.current === requestVersion) setBusy(null);
      }
    }, 400);
    return () => { clearTimeout(timer); controller.abort(); };
  }, [value, editing]);
  const choose = async (item: AddressSuggestion) => {
    if (selection.current) return;
    const requestVersion = ++version.current;
    const controller = new AbortController();
    selection.current = controller;
    setEditing(false);
    setBusy("resolve");
    setError(false);
    try {
      const address = await resolveAddress(item.id, addressLookupKey, controller.signal);
      if (!controller.signal.aborted && version.current === requestVersion) {
        onChange(address);
        setSuggestions([]);
        Keyboard.dismiss();
      }
    } catch {
      if (!controller.signal.aborted && version.current === requestVersion) {
        setError(true);
        setEditing(true);
      }
    } finally {
      if (selection.current === controller) selection.current = null;
      if (!controller.signal.aborted && version.current === requestVersion) setBusy(null);
    }
  };
  return <View style={styles.addressSearchWrap}>
    <Text style={styles.fieldLabel}>{label}</Text>
    <View style={styles.addressSearchField}>
      <Ionicons name="search-outline" size={18} color={palette.blue} />
      <TextInput accessibilityLabel={label} style={[styles.addressSearchInput, { minHeight: 48 }]}
        value={value} autoCorrect={false} autoComplete="street-address"
        placeholder={t("Postcode, house number or address", "邮编、门牌号或地址", "郵編、門牌號或地址")}
        placeholderTextColor="#A1ADBE"
        onFocus={() => { if (busy !== "resolve") setEditing(true); }}
        onChangeText={(text) => { stop(); onChange(text); setEditing(true); }} />
      {!!value && <Pressable accessibilityRole="button" hitSlop={8}
        accessibilityLabel={t(`Clear ${label}`, `清除${label}`, `清除${label}`)}
        style={{ minWidth: 36, minHeight: 44, alignItems: "center", justifyContent: "center" }}
        onPress={() => { stop(); onChange(""); setEditing(true); }}>
        <Ionicons name="close-circle" size={20} color={palette.muted} />
      </Pressable>}
    </View>
    <Text style={styles.fieldHint}>{addressLookupKey
      ? t("Start with a postcode or part of your address, then choose your property. Add the flat number if needed.", "输入邮编或部分地址，然后选择房屋；如有需要，请补充房间或公寓号。", "輸入郵編或部分地址，然後選擇房屋；如有需要，請補充房間或公寓號。")
      : t("Enter the full address, including flat or house number and postcode. Address suggestions are not available yet.", "请输入完整地址，包括房间或门牌号及邮编。地址建议暂未启用。", "請輸入完整地址，包括房間或門牌號及郵編。地址建議暫未啟用。")}</Text>
    {busy === "resolve" && <Text accessibilityLiveRegion="polite" style={styles.addressSearchMeta}>{t("Loading full address…", "正在获取完整地址…", "正在取得完整地址…")}</Text>}
    {editing && !!addressLookupKey && value.trim().length >= 3 && <View style={styles.addressSuggestions}>
      {busy === "search" && <Text accessibilityLiveRegion="polite" style={styles.addressSearchMeta}>{t("Finding properties…", "正在查找房屋…", "正在搜尋房屋…")}</Text>}
      {error && <Text accessibilityRole="alert" style={styles.addressSearchMeta}>{t("Address search is unavailable. Please enter your full address manually.", "暂时无法搜索地址，请手动输入完整地址。", "暫時無法搜尋地址，請手動輸入完整地址。")}</Text>}
      {!busy && !error && !suggestions.length && <Text accessibilityLiveRegion="polite" style={styles.addressSearchMeta}>{t("No matching properties. Try a full postcode or add the house or flat number.", "没有匹配房屋，请尝试完整邮编或添加门牌及房间号。", "沒有相符房屋，請嘗試完整郵編或加入門牌及房間號。")}</Text>}
      <ScrollView style={{ maxHeight: 220 }} nestedScrollEnabled keyboardShouldPersistTaps="handled">
        {suggestions.map((item) => <Pressable key={item.id} accessibilityRole="button"
          accessibilityLabel={t(`Select ${item.label}`, `选择${item.label}`, `選擇${item.label}`)}
          style={[styles.airportAddressSuggestion, { paddingVertical: 12 }]} onPress={() => choose(item)}>
          <Ionicons name="home-outline" size={17} color={palette.blue} />
          <Text style={styles.addressSuggestionText}>{item.label}</Text>
        </Pressable>)}
      </ScrollView>
      <Pressable accessibilityRole="button" style={[styles.airportAddressSuggestion, { paddingVertical: 12 }]} onPress={stop}>
        <Ionicons name="create-outline" size={17} color={palette.blue} />
        <Text style={styles.addressSuggestionText}>{t("Use address as typed", "使用输入的地址", "使用輸入的地址")}</Text>
      </Pressable>
      <Text style={styles.addressSearchMeta}>{t("Address search by Ideal Postcodes · Your search text is sent to this service.", "地址搜索由 Ideal Postcodes 提供 · 搜索文字会发送给该服务。", "地址搜尋由 Ideal Postcodes 提供 · 搜尋文字會傳送給該服務。")}</Text>
    </View>}
  </View>;
}


function AirportTransferForm({ language, onCheckout, isUnavailable, isTimeUnavailable }: { language: Language; onCheckout: (order: ServiceCheckoutOrder) => void; isUnavailable?: (dayKey: string) => boolean; isTimeUnavailable?: (dayKey: string, time: string) => boolean }) {
  const isEnglish = language === "EN";
  const { width } = useWindowDimensions();
  const compact = width < 380;
  const [journey, setJourney] = useState<"pickup" | "dropoff">("pickup");
  const [terminal, setTerminal] = useState("Heathrow · Terminal 2");
  const [selectedDay, setSelectedDay] = useState(() => bookingDateFromToday(7));
  const [hour, setHour] = useState("10");
  const [minute, setMinute] = useState("00");
  const [flightNumber, setFlightNumber] = useState("BA 2836");
  const [passportType, setPassportType] = useState("Chinese passport");
  const [customAirportTime, setCustomAirportTime] = useState(false);
  const [passengers, setPassengers] = useState("1 passenger");
  const [smallCases, setSmallCases] = useState("1 small suitcase");
  const [largeCases, setLargeCases] = useState("1 large suitcase");
  const [meeting, setMeeting] = useState<"greet" | "carpark">("greet");
  const [luggageHelp, setLuggageHelp] = useState(true);
  const [locationQuery, setLocationQuery] = useState(
    "",
  );
  const airports = [
    "Heathrow · Terminal 2",
    "Heathrow · Terminal 3",
    "Heathrow · Terminal 4",
    "Heathrow · Terminal 5",
    "Gatwick · North Terminal",
    "Gatwick · South Terminal",
    "London City Airport",
    "Stansted Airport",
    "Luton Airport",
  ];
  const hours = airportTimeHours;
  const minutes = airportTimeMinutes;
  const passengerOptions = [
    "1 passenger",
    "2 passengers",
    "3 passengers",
    "4 passengers",
  ];
  const suitcaseOptions = (size: string) => [
    `0 ${size} suitcases`,
    `1 ${size} suitcase`,
    `2 ${size} suitcases`,
    `3 ${size} suitcases`,
    `4 ${size} suitcases`,
  ];
  const airportOptionLabel = (value: string) =>
    isEnglish
      ? value
      : value
          .replace(
            "Heathrow",
            language === "简体" ? "希思罗机场" : "希斯路機場",
          )
          .replace("Gatwick", language === "简体" ? "盖特威克机场" : "格域機場")
          .replace(
            "London City Airport",
            language === "简体" ? "伦敦城市机场" : "倫敦城市機場",
          )
          .replace(
            "Stansted Airport",
            language === "简体" ? "斯坦斯特德机场" : "史坦斯特機場",
          )
          .replace(
            "Luton Airport",
            language === "简体" ? "卢顿机场" : "盧頓機場",
          )
          .replace(
            "North Terminal",
            language === "简体" ? "北航站楼" : "北航站樓",
          )
          .replace(
            "South Terminal",
            language === "简体" ? "南航站楼" : "南航站樓",
          )
          .replace("Terminal", language === "简体" ? "航站楼" : "航站樓");
  const passengerOptionLabel = (value: string) =>
    isEnglish
      ? value
      : `${value.match(/\d+/)?.[0]}${language === "简体" ? "位乘客" : "位乘客"}`;
  const suitcaseOptionLabel = (value: string) =>
    isEnglish
      ? value
      : `${value.match(/\d+/)?.[0]}${value.includes("small") ? (language === "简体" ? "个小型行李箱" : "個小型行李箱") : language === "简体" ? "个大型行李箱" : "個大型行李箱"}`;
  const labels = isEnglish
    ? {
        pickup: "Airport pickup",
        dropoff: "Airport drop-off",
        airport:
          journey === "pickup"
            ? "Pickup airport & terminal"
            : "Drop-off airport & terminal",
        date:
          journey === "pickup"
            ? "Arrival date (London time)"
            : "Departure date",
        time:
          journey === "pickup"
            ? "Arrival time (London time)"
            : "Airport arrival time",
        hour: "Hour",
        minute: "Minute",
        flight: "Flight number",
        flightHint: "For example: BA317",
        london: journey === "pickup" ? "Drop-off location" : "Pickup location",
        addressHint:
          "Search an address or postcode, then choose a suggestion. You can also type a full address manually.",
        manual: "Full address or postcode",
        passengers: "Passengers",
        small: "Small suitcases",
        large: "Large suitcases",
        meeting: "Where should your driver meet you?",
        greet: "Meet & greet in arrivals",
        carpark: "Meet at the car park",
        help: "Help with luggage",
        helpHint: "Your driver will assist from the meeting point to the car.",
        quote: "Get transfer quote",
        title: "Airport Transfers",
        subtitle: "Safe, reliable and tailored to your journey.",
        capacity:
          "One car carries up to 4 passengers. We will suggest a larger vehicle if your luggage needs more space.",
        received: "Quote request ready",
        receivedBody:
          "Your transfer details have been added. Live pricing and payment will be connected in the production app.",
        manualPlaceholder: "e.g. 22 Bedford Way, London WC1H 0AP",
      }
    : {
        pickup: language === "简体" ? "机场接机" : "機場接機",
        dropoff: language === "简体" ? "机场送机" : "機場送機",
        airport: language === "简体" ? "机场及航站楼" : "機場及航站樓",
        date: language === "简体" ? "日期（伦敦时间）" : "日期（倫敦時間）",
        time: language === "简体" ? "时间（伦敦时间）" : "時間（倫敦時間）",
        hour: language === "简体" ? "小时" : "小時",
        minute: language === "简体" ? "分钟" : "分鐘",
        flight: language === "简体" ? "航班号" : "航班號",
        flightHint: "例如：BA317",
        london:
          journey === "pickup"
            ? language === "简体"
              ? "送达地点"
              : "送達地點"
            : language === "简体"
              ? "上车地点"
              : "上車地點",
        addressHint:
          language === "简体"
            ? "搜索地址或邮编并选择建议，也可以手动输入完整地址。"
            : "搜尋地址或郵編並選擇建議，也可以手動輸入完整地址。",
        manual: language === "简体" ? "完整地址或邮编" : "完整地址或郵編",
        passengers: language === "简体" ? "乘客人数" : "乘客人數",
        small: language === "简体" ? "小型行李箱" : "小型行李箱",
        large: language === "简体" ? "大型行李箱" : "大型行李箱",
        meeting: language === "简体" ? "司机在哪里接您？" : "司機在哪裡接您？",
        greet: language === "简体" ? "到达大厅举牌接机" : "抵達大堂舉牌接機",
        carpark: language === "简体" ? "停车场见面" : "停車場見面",
        help: language === "简体" ? "协助搬运行李" : "協助搬運行李",
        helpHint:
          language === "简体"
            ? "司机会从见面地点协助搬运行李。"
            : "司機會從見面地點協助搬運行李。",
        quote: language === "简体" ? "获取接送报价" : "獲取接送報價",
        title: language === "简体" ? "机场接送" : "機場接送",
        subtitle:
          language === "简体"
            ? "安全可靠，为您的行程量身安排。"
            : "安全可靠，為您的行程量身安排。",
        capacity:
          language === "简体"
            ? "每辆车最多乘坐4人。行李较多时，我们会推荐更大的车型。"
            : "每輛車最多乘坐4人。行李較多時，我們會推薦更大的車型。",
        received: language === "简体" ? "报价信息已准备" : "報價資料已準備",
        receivedBody:
          language === "简体"
            ? "已添加接送详情。正式版本将连接实时价格与付款。"
            : "已加入接送詳情。正式版本將連接即時價格與付款。",
        manualPlaceholder:
          language === "简体" ? "输入完整地址或邮编" : "輸入完整地址或郵編",
      };
  const fareLabels = isEnglish
    ? {
        estimate: "Estimated fare",
        mapEstimate: "Route estimate",
        service: "Base transfer service",
        distance: "Distance charge",
        airportFee: "Airport access fee",
        greetFee: "Meet & greet",
        total: "Estimated total",
        deposit: "50% deposit due now",
        balance: "Balance due before journey",
        eligible: "Within our 2.5-hour airport service area",
        currency: "Pay in",
        payment: "Payment method",
        cardNumber: "Sample card number",
        expiry: "Expiry",
        cvc: "CVC",
        secure:
          "Payment details are not stored in this prototype. Final prices use live routing, traffic and airport charges.",
        payDeposit: "Continue to 50% deposit",
        waitingPolicy: "Waiting time is tracked automatically",
        waitingPolicyText:
          "We track the flight’s actual landing time. A 45-minute grace period is included, then waiting is £0.60/min until the driver confirms “Passenger onboard”. Both sides can see the timestamps.",
        airportAuto:
          "Automatically selected from the airport and journey type.",
      }
    : {
        estimate: language === "简体" ? "预估费用" : "預估費用",
        mapEstimate: language === "简体" ? "路线预估" : "路線預估",
        service: language === "简体" ? "接送基础服务" : "接送基礎服務",
        distance: language === "简体" ? "里程费用" : "里程費用",
        airportFee: language === "简体" ? "机场接送费" : "機場接送費",
        greetFee: language === "简体" ? "举牌接机" : "舉牌接機",
        total: language === "简体" ? "预估总价" : "預估總價",
        deposit: language === "简体" ? "现在支付50%订金" : "現在支付50%訂金",
        balance: language === "简体" ? "行程前支付余款" : "行程前支付餘款",
        eligible:
          language === "简体"
            ? "在机场2.5小时服务范围内"
            : "在機場2.5小時服務範圍內",
        currency: language === "简体" ? "付款货币" : "付款貨幣",
        payment: language === "简体" ? "付款方式" : "付款方式",
        cardNumber: language === "简体" ? "预览卡号" : "預覽卡號",
        expiry: language === "简体" ? "有效期" : "有效期",
        cvc: "CVC",
        secure:
          language === "简体"
            ? "此原型不会储存付款资料。正式价格将使用实时路线、交通与机场费用。"
            : "此原型不會儲存付款資料。正式價格將使用即時路線、交通與機場費用。",
        payDeposit: language === "简体" ? "继续支付50%订金" : "繼續支付50%訂金",
        waitingPolicy:
          language === "简体" ? "等候时间自动记录" : "等候時間自動記錄",
        waitingPolicyText:
          language === "简体"
            ? "系统按航班实际落地时间追踪。包含45分钟免费等候，其后每分钟£0.60，直到司机确认“乘客已上车”。双方均可查看时间记录。"
            : "系統按航班實際落地時間追蹤。包含45分鐘免費等候，其後每分鐘£0.60，直到司機確認「乘客已上車」。雙方均可查看時間記錄。",
        airportAuto:
          language === "简体"
            ? "根据所选机场及接送类型自动计算。"
            : "根據所選機場及接送類型自動計算。",
      };
  const airportName = terminal.startsWith("Heathrow")
    ? "Heathrow"
    : terminal.startsWith("Gatwick")
      ? "Gatwick"
      : terminal.startsWith("Stansted")
        ? "Stansted"
        : terminal.startsWith("Luton")
          ? "Luton"
          : "London City";
  const routeData: Record<
    string,
    { miles: number; minutes: number; pickupFee: number; dropoffFee: number }
  > = {
    Heathrow: { miles: 21, minutes: 55, pickupFee: 8, dropoffFee: 7 },
    Gatwick: { miles: 31, minutes: 75, pickupFee: 10, dropoffFee: 10 },
    Stansted: { miles: 40, minutes: 80, pickupFee: 13, dropoffFee: 10 },
    Luton: { miles: 34, minutes: 70, pickupFee: 9, dropoffFee: 9 },
    "London City": { miles: 10, minutes: 35, pickupFee: 8, dropoffFee: 8 },
  };
  const route = routeData[airportName];
  const fare = useMemo(() => {
    const base = journey === "pickup" ? 48 : 42;
    const mileage = route.miles * 2.15;
    const airportAccess =
      journey === "pickup" ? route.pickupFee : route.dropoffFee;
    const greeting = journey === "pickup" && meeting === "greet" ? 12 : 0;
    return {
      base,
      mileage,
      airportAccess,
      greeting,
      total: base + mileage + airportAccess + greeting,
    };
  }, [journey, meeting, route]);
  const money = (amount: number) => `£${amount.toFixed(2)}`;
  return (
    <View style={styles.formCard}>
      <View style={styles.formHero}>
        <View style={styles.formHeroIcon}>
          <Ionicons name="airplane" size={27} color={palette.blue} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.formTitle}>{labels.title}</Text>
          <Text style={styles.formDesc}>{labels.subtitle}</Text>
        </View>
      </View>
      <View style={styles.transferSegment}>
        <Pressable
          style={[
            styles.transferSegmentItem,
            journey === "pickup" && styles.transferSegmentActive,
          ]}
          onPress={() => setJourney("pickup")}
        >
          <Ionicons
            name="airplane-outline"
            size={17}
            color={journey === "pickup" ? "white" : palette.blue}
          />
          <Text
            style={[
              styles.transferSegmentText,
              journey === "pickup" && styles.transferSegmentTextActive,
            ]}
          >
            {labels.pickup}
          </Text>
        </Pressable>
        <Pressable
          style={[
            styles.transferSegmentItem,
            journey === "dropoff" && styles.transferSegmentActive,
          ]}
          onPress={() => setJourney("dropoff")}
        >
          <Ionicons
            name="car-outline"
            size={18}
            color={journey === "dropoff" ? "white" : palette.blue}
          />
          <Text
            style={[
              styles.transferSegmentText,
              journey === "dropoff" && styles.transferSegmentTextActive,
            ]}
          >
            {labels.dropoff}
          </Text>
        </Pressable>
      </View>
      <SelectField
        label={labels.airport}
        value={terminal}
        options={airports}
        onChange={setTerminal}
        formatOption={airportOptionLabel}
      />
      <Text style={styles.formSectionTitle}>{labels.date}</Text>
      <AvailabilityCalendar
        selected={selectedDay}
        onSelect={setSelectedDay}
        language={language}
        compact
        isUnavailable={isUnavailable}
      />
      <View style={styles.timeTitleRow}>
        <Text style={[styles.formSectionTitle, styles.timeTitleRowLabel]}>{labels.time}</Text>
        <View style={styles.selectedTimePill}>
          <Ionicons name="time-outline" size={14} color={palette.blue} />
          <Text style={styles.selectedTimeText}>
            {hour}:{minute}
          </Text>
        </View>
      </View>
      <View
        style={[styles.formTwoColumns, compact && styles.formColumnsCompact]}
      >
        <View style={styles.formHalf}>
          <SelectField
            label={labels.hour}
            value={hour}
            options={hours}
            onChange={setHour}
          />
        </View>
        <View style={styles.formHalf}>
          <SelectField
            label={labels.minute}
            value={minute}
            options={minutes}
            onChange={setMinute}
          />
        </View>
      </View>
      {isTimeUnavailable?.(selectedDay, `${hour}:${minute}`) && <Text style={[styles.fieldHint, { color: palette.coral }]}>{tr(language, "This time overlaps a booking or blocked hours. Choose another time; the rest of the day may still be available.", "此时间与已有预订或封锁时段冲突。请选择其他时间；当天其余时间仍可能可预约。", "此時間與已有預訂或封鎖時段衝突。請選擇其他時間；當天其餘時間仍可能可預約。")}</Text>}
      <View style={styles.field}>
        <Text style={styles.fieldLabel}>{labels.flight}</Text>
        <TextInput
          value={flightNumber}
          onChangeText={setFlightNumber}
          placeholder={labels.flightHint}
          placeholderTextColor="#A1ADBE"
          autoCapitalize="characters"
        />
      </View>
      <SelectField label={tr(language, "Traveller passport", "旅客护照", "旅客護照")} value={passportType} options={["UK passport", "EU/EEA passport", "Chinese passport", "Other passport"]} onChange={setPassportType} />
      <View style={styles.workspaceCard}>
        <View style={styles.workspaceCardTop}><View style={{ flex: 1 }}><Text style={styles.workspaceCardTitle}>{journey === "pickup" ? tr(language, "Recommended airport pickup", "建议机场接机时间", "建議機場接機時間") : tr(language, "Recommended home pickup", "建议上门接送时间", "建議上門接送時間")}</Text><Text style={styles.workspaceCardText}>{journey === "pickup" ? `${hour}:${minute} ${tr(language, "flight arrival", "航班抵达", "航班抵達")} · ${passportType === "Chinese passport" ? tr(language, "allows extra border time", "已预留较长入境时间", "已預留較長入境時間") : tr(language, "standard border allowance", "标准入境预留时间", "標準入境預留時間")}` : `${tr(language, "Driver arrival", "司机到达", "司機到達")} 06:20 · ${tr(language, "target airport arrival", "预计抵达机场", "預計抵達機場")} 07:35`}</Text></View><Ionicons name="sparkles" size={20} color={palette.blue} /></View>
        <Pressable accessibilityRole="switch" accessibilityState={{ checked: customAirportTime }} style={[styles.toggle, customAirportTime && styles.toggleOn]} onPress={() => setCustomAirportTime(!customAirportTime)}><SwitchThumb on={customAirportTime} /></Pressable>
        <Text style={styles.workspaceHint}>{customAirportTime ? tr(language, "Custom time selected. UniMate will show any timing risk before payment.", "已选择自定义时间。优你伴会在付款前提示时间风险。", "已選擇自訂時間。優你伴會在付款前提示時間風險。") : tr(language, "Recommendation considers flight time, live route allowance, airport guidance and passport processing time.", "建议时间会综合航班时间、路线预留、机场指引和护照入境时间。", "建議時間會綜合航班時間、路線預留、機場指引及護照入境時間。")}</Text>
      </View>
      <AddressLookupField language={language} label={labels.london} value={locationQuery} onChange={setLocationQuery} />
      <View
        style={[styles.formTwoColumns, compact && styles.formColumnsCompact]}
      >
        <View style={styles.formHalf}>
          <SelectField
            label={labels.passengers}
            value={passengers}
            options={passengerOptions}
            onChange={setPassengers}
            formatOption={passengerOptionLabel}
          />
        </View>
        <View style={styles.formHalf}>
          <SelectField
            label={labels.small}
            value={smallCases}
            options={suitcaseOptions("small")}
            onChange={setSmallCases}
            formatOption={suitcaseOptionLabel}
          />
        </View>
      </View>
      <SelectField
        label={labels.large}
        value={largeCases}
        options={suitcaseOptions("large")}
        onChange={setLargeCases}
        formatOption={suitcaseOptionLabel}
      />
      <View style={styles.capacityNote}>
        <Ionicons name="car-sport-outline" size={20} color={palette.blue} />
        <Text style={styles.capacityNoteText}>{labels.capacity}</Text>
      </View>
      <Text style={styles.formSectionTitle}>{labels.meeting}</Text>
      <View style={styles.meetingOptions}>
        {(
          [
            { id: "greet", icon: "person-outline", label: labels.greet },
            { id: "carpark", icon: "car-outline", label: labels.carpark },
          ] as const
        ).map((item) => (
          <Pressable
            key={item.id}
            style={[
              styles.meetingOption,
              meeting === item.id && styles.meetingOptionActive,
            ]}
            onPress={() => setMeeting(item.id)}
          >
            <Ionicons
              name={item.icon}
              size={20}
              color={meeting === item.id ? palette.blue : palette.muted}
            />
            <Text
              style={[
                styles.meetingOptionText,
                meeting === item.id && styles.meetingOptionTextActive,
              ]}
            >
              {item.label}
            </Text>
            {meeting === item.id && (
              <Ionicons
                name="checkmark-circle"
                size={19}
                color={palette.blue}
              />
            )}
          </Pressable>
        ))}
      </View>
      <Pressable
        style={styles.assistanceRow}
        onPress={() => setLuggageHelp(!luggageHelp)}
      >
        <View style={[styles.checkbox, luggageHelp && styles.checkboxActive]}>
          {luggageHelp && <Ionicons name="checkmark" size={16} color="white" />}
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.assistanceTitle}>{labels.help}</Text>
          <Text style={styles.assistanceText}>{labels.helpHint}</Text>
        </View>
      </Pressable>
      <BelongingsNotice language={language} context="car" />
      <View style={styles.waitingPolicy}>
        <View style={styles.waitingPolicyIcon}>
          <Ionicons name="time-outline" size={21} color={palette.blue} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.waitingPolicyTitle}>
            {fareLabels.waitingPolicy}
          </Text>
          <Text style={styles.waitingPolicyText}>
            {fareLabels.waitingPolicyText}
          </Text>
        </View>
      </View>
      <View style={styles.fareCard}>
        <View style={styles.fareHead}>
          <View>
            <Text style={styles.formTitle}>{fareLabels.estimate}</Text>
            <Text style={styles.formDesc}>
              {airportOptionLabel(airportName)} · {route.miles}{" "}
              {tr(language, "mi", "英里", "英里")} · ~{route.minutes}{" "}
              {tr(language, "min", "分钟", "分鐘")}
            </Text>
          </View>
          <View style={styles.eligiblePill}>
            <Ionicons name="checkmark-circle" size={15} color={palette.green} />
            <Text style={styles.eligibleText}>{fareLabels.eligible}</Text>
          </View>
        </View>
        {[
          [fareLabels.service, fare.base],
          [fareLabels.distance, fare.mileage],
          [
            `${airportOptionLabel(airportName)} ${journey === "pickup" ? tr(language, "pickup fee", "接机费", "接機費") : tr(language, "drop-off fee", "送机费", "送機費")}`,
            fare.airportAccess,
          ],
          ...(fare.greeting ? [[fareLabels.greetFee, fare.greeting]] : []),
        ].map(([label, amount]) => (
          <View style={styles.fareLine} key={String(label)}>
            <Text style={styles.fareLineLabel}>{label}</Text>
            <Text style={styles.fareLineValue}>{money(Number(amount))}</Text>
          </View>
        ))}
        <View style={styles.airportAutoNote}>
          <Ionicons
            name="information-circle-outline"
            size={14}
            color={palette.blue}
          />
          <Text style={styles.airportAutoText}>{fareLabels.airportAuto}</Text>
        </View>
        <View style={styles.fareTotal}>
          <Text style={styles.fareTotalLabel}>{fareLabels.total}</Text>
          <Text style={styles.fareTotalValue}>{money(fare.total)}</Text>
        </View>
        <View style={styles.depositRow}>
          <View>
            <Text style={styles.depositLabel}>{tr(language, "25% booking deposit", "25%预订订金", "25%預訂訂金")}</Text>
            <Text style={styles.balanceText}>
              {fareLabels.balance}: {money(fare.total * 0.75)}
            </Text>
          </View>
          <Text style={styles.depositValue}>{money(fare.total * 0.25)}</Text>
        </View>
      </View>
      <Pressable
        disabled={!!isTimeUnavailable?.(selectedDay, `${hour}:${minute}`)}
        style={[styles.primaryButton, isTimeUnavailable?.(selectedDay, `${hour}:${minute}`) && { opacity: 0.5 }]}
        onPress={() => onCheckout({
          service: "airport",
          title: labels.title,
          details: `${terminal} · ${locationQuery.trim() || tr(language, "London address needed", "需填写伦敦地址", "需填寫倫敦地址")}`,
          when: `${formatBookingDate(selectedDay, language)} · ${hour}:${minute}`,
          total: fare.total,
          dueNow: Math.round(fare.total * 25) / 100,
          note: tr(language, "25% booking deposit. Fare is illustrative; confirm the final route and cancellation terms before real payment.", "25%预订订金。车费仅供预览；实际付款前需确认路线和取消条款。", "25%預訂訂金。車費僅供預覽；實際付款前須確認路線及取消條款。"),
          bookingDate: formatStaffBookingDate(selectedDay),
          bookingTime: `${hour}:${minute}`,
          bookingAddress: journey === "pickup" ? `${terminal} → ${locationQuery.trim()}` : `${locationQuery.trim()} → ${terminal}`,
          intake: { fields: [
            { label: "Journey", value: journey === "pickup" ? "Airport pickup" : "Airport drop-off" },
            { label: "Airport / terminal", value: terminal },
            { label: "London address", value: locationQuery.trim() || "Not provided" },
            { label: "Passengers", value: passengers },
            { label: "Small cases", value: smallCases },
            { label: "Large cases", value: largeCases },
            { label: "Meeting point", value: meeting === "greet" ? "Meet and greet" : "Car park" },
            { label: "Luggage help", value: luggageHelp ? "Requested" : "Not requested" },
          ], photos: [] },
        })}
      >
        <Text style={styles.primaryButtonText}>{tr(language, "Review request", "查看服务申请", "查看服務申請")}</Text>
      </Pressable>
    </View>
  );
}


function CounterRow({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
}) {
  return (
    <View style={styles.counterRow}>
      <Text style={styles.counterLabel}>{label}</Text>
      <View style={styles.counterControls}>
        <Pressable
          accessibilityLabel={`Remove ${label}`}
          style={styles.counterButton}
          onPress={() => onChange(Math.max(0, value - 1))}
        >
          <Ionicons name="remove" size={18} color={palette.blue} />
        </Pressable>
        <Text style={styles.counterValue}>{value}</Text>
        <Pressable
          accessibilityLabel={`Add ${label}`}
          style={styles.counterButton}
          onPress={() => onChange(Math.min(10, value + 1))}
        >
          <Ionicons name="add" size={18} color={palette.blue} />
        </Pressable>
      </View>
    </View>
  );
}


function BelongingsNotice({
  language,
  context,
}: {
  language: Language;
  context: "car" | "property" | "move";
}) {
  const place =
    context === "car"
      ? tr(language, "in the vehicle", "在车内", "在車內")
      : context === "property"
        ? tr(language, "at the property", "在房屋内", "在單位內")
        : tr(language, "during the move", "在搬家过程中", "在搬屋過程中");
  return (
    <View style={styles.belongingsNotice}>
      <View style={styles.belongingsIcon}>
        <Ionicons name="briefcase-outline" size={20} color="#8A5B00" />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.belongingsTitle}>
          {tr(
            language,
            "Personal belongings & lost property",
            "个人物品与失物",
            "個人物品及失物",
          )}
        </Text>
        <Text style={styles.belongingsText}>
          {tr(
            language,
            `Keep valuables with you and secure all belongings ${place}. UNIMATE and service providers cannot accept liability for unsecured items. If a team member finds something, they can report it in the app so support can verify the owner and arrange a safe return.`,
            `请随身保管贵重物品，并妥善收好${place}的所有个人物品。UNIMATE及服务人员不对未妥善保管的物品承担责任。如工作人员发现遗失物品，可在应用内上报，由客服核实失主并安排安全归还。`,
            `請隨身保管貴重物品，並妥善收好${place}的所有個人物品。UNIMATE及服務人員不對未妥善保管的物品承擔責任。如工作人員發現遺失物品，可在應用程式內上報，由客服核實物主並安排安全歸還。`,
          )}
        </Text>
      </View>
    </View>
  );
}


function AvailabilityCalendar({
  selected,
  onSelect,
  language,
  compact = false,
  bookingMonths = 0,
  isUnavailable,
}: {
  selected: string;
  onSelect: (day: string) => void;
  language: Language;
  compact?: boolean;
  bookingMonths?: number;
  isUnavailable?: (dayKey: string) => boolean;
}) {
  const unavailable: number[] = [];
  const limited: number[] = [];
  const weekdays =
    language === "EN"
      ? ["M", "T", "W", "T", "F", "S", "S"]
      : ["一", "二", "三", "四", "五", "六", "日"];
  const today = useMemo(() => {
    const date = new Date();
    date.setHours(0, 0, 0, 0);
    return date;
  }, []);
  const lastBookableDay = useMemo(() => {
    if (bookingMonths > 0) {
      const lastDayOfTargetMonth = new Date(today.getFullYear(), today.getMonth() + bookingMonths + 1, 0).getDate();
      return new Date(today.getFullYear(), today.getMonth() + bookingMonths, Math.min(today.getDate(), lastDayOfTargetMonth));
    }
    const date = new Date(today);
    date.setDate(date.getDate() + 28);
    return date;
  }, [today, bookingMonths]);
  const [visibleMonth, setVisibleMonth] = useState(() => {
    const date = dateFromKey(selected);
    return new Date(date.getFullYear(), date.getMonth(), 1);
  });
  const monthStart = (date: Date) =>
    new Date(date.getFullYear(), date.getMonth(), 1);
  const canGoBack = visibleMonth.getTime() > monthStart(today).getTime();
  const canGoForward =
    visibleMonth.getTime() < monthStart(lastBookableDay).getTime();
  const firstWeekday = (visibleMonth.getDay() + 6) % 7;
  const numberOfDays = new Date(
    visibleMonth.getFullYear(),
    visibleMonth.getMonth() + 1,
    0,
  ).getDate();
  const days = [
    ...Array(firstWeekday).fill(null),
    ...Array.from({ length: numberOfDays }, (_, index) => index + 1),
  ];
  const monthLabel = visibleMonth.toLocaleDateString(
    language === "EN" ? "en-GB" : language === "简体" ? "zh-CN" : "zh-TW",
    { month: "long", year: "numeric" },
  );
  const moveMonth = (amount: number) =>
    setVisibleMonth(
      new Date(visibleMonth.getFullYear(), visibleMonth.getMonth() + amount, 1),
    );
  return (
    <View style={[styles.calendarCard, compact && styles.calendarCardCompact]}>
      <View
        style={[styles.calendarHead, compact && styles.calendarHeadCompact]}
      >
        <Pressable
          accessibilityLabel={tr(
            language,
            "Previous month",
            "上个月",
            "上個月",
          )}
          disabled={!canGoBack}
          style={[
            styles.calendarArrow,
            compact && styles.calendarArrowCompact,
            !canGoBack && styles.calendarArrowDisabled,
          ]}
          onPress={() => moveMonth(-1)}
        >
          <Ionicons
            name="chevron-back"
            size={compact ? 15 : 18}
            color={canGoBack ? palette.muted : "#C9D2DF"}
          />
        </Pressable>
        <View>
          <Text style={styles.calendarMonth}>{monthLabel}</Text>
          {!compact && (
            <Text style={styles.calendarSub}>
              {tr(
                language,
                bookingMonths > 0 ? "Book up to 2 months ahead" : "Book from today up to 4 weeks ahead",
                bookingMonths > 0 ? "可预约未来2个月" : "可预约今天起未来4周",
                bookingMonths > 0 ? "可預約未來2個月" : "可預約今天起未來4週",
              )}
            </Text>
          )}
        </View>
        <Pressable
          accessibilityLabel={tr(language, "Next month", "下个月", "下個月")}
          disabled={!canGoForward}
          style={[
            styles.calendarArrow,
            compact && styles.calendarArrowCompact,
            !canGoForward && styles.calendarArrowDisabled,
          ]}
          onPress={() => moveMonth(1)}
        >
          <Ionicons
            name="chevron-forward"
            size={compact ? 15 : 18}
            color={canGoForward ? palette.muted : "#C9D2DF"}
          />
        </Pressable>
      </View>
      <View style={styles.weekRow}>
        {weekdays.map((day, index) => (
          <Text key={`${day}-${index}`} style={styles.weekday}>
            {day}
          </Text>
        ))}
      </View>
      <View style={styles.calendarGrid}>
        {days.map((day, index) => {
          if (day === null)
            return (
              <View
                key={`blank-${index}`}
                style={[
                  styles.calendarDay,
                  compact && styles.calendarDayCompact,
                ]}
              />
            );
          const candidate = new Date(
            visibleMonth.getFullYear(),
            visibleMonth.getMonth(),
            day,
          );
          const key = dateKey(candidate);
          const outsideWindow =
            candidate < today || candidate > lastBookableDay;
          const blocked = outsideWindow || unavailable.includes(day) || !!isUnavailable?.(key);
          const isLimited = !outsideWindow && limited.includes(day);
          const isSelected = selected === key;
          return (
            <Pressable
              key={key}
              disabled={blocked}
              accessibilityState={{ disabled: blocked, selected: isSelected }}
              style={[
                styles.calendarDay,
                compact && styles.calendarDayCompact,
                blocked && styles.calendarDayUnavailable,
                isLimited && styles.calendarDayLimited,
                isSelected && styles.calendarDaySelected,
              ]}
              onPress={() => onSelect(key)}
            >
              <Text
                style={[
                  styles.calendarDayText,
                  blocked && styles.calendarDayTextUnavailable,
                  isSelected && styles.calendarDayTextSelected,
                ]}
              >
                {day}
              </Text>
              {isLimited && !isSelected && <View style={styles.limitedDot} />}
            </Pressable>
          );
        })}
      </View>
      {!compact && (
        <View style={styles.calendarLegend}>
          <View style={styles.legendItem}>
            <View
              style={[styles.legendDot, { backgroundColor: palette.green }]}
            />
            <Text style={styles.legendText}>
              {tr(language, "Available", "可预约", "可預約")}
            </Text>
          </View>
          <View style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: "#F2B94B" }]} />
            <Text style={styles.legendText}>
              {tr(language, "Limited", "少量", "少量")}
            </Text>
          </View>
          <View style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: "#D6DEE8" }]} />
            <Text style={styles.legendText}>
              {tr(
                language,
                "Outside booking window",
                "不在预约范围内",
                "不在預約範圍內",
              )}
            </Text>
          </View>
        </View>
      )}
    </View>
  );
}


function CleaningServiceForm({ language, onCheckout, isUnavailable, isTimeUnavailable }: { language: Language; onCheckout: (order: ServiceCheckoutOrder) => void; isUnavailable?: (dayKey: string) => boolean; isTimeUnavailable?: (dayKey: string, time: string) => boolean }) {
  const isEnglish = language === "EN";
  const [cleanType, setCleanType] = useState<
    "Regular" | "Deep" | "End of tenancy" | "Shared areas"
  >("Regular");
  const [propertyType, setPropertyType] = useState("Student flat / apartment");
  const [propertySize, setPropertySize] = useState("");
  const [bedrooms, setBedrooms] = useState(1);
  const [bathrooms, setBathrooms] = useState(1);
  const [kitchens, setKitchens] = useState(1);
  const [livingRooms, setLivingRooms] = useState(1);
  const [selectedDay, setSelectedDay] = useState(() => bookingDateFromToday(7));
  const [address, setAddress] = useState("");
  const [timeSlot, setTimeSlot] = useState("09:00–12:00");
  const availableTimeSlots = cleaningArrivalWindows.filter((slot) => !isTimeUnavailable?.(selectedDay, slot));
  useEffect(() => { if (!availableTimeSlots.includes(timeSlot)) setTimeSlot(availableTimeSlots[0] || ""); }, [selectedDay, availableTimeSlots.join("|")]);
  const [parking, setParking] = useState("Free parking available");
  const [parkingFee, setParkingFee] = useState("£0");
  const [pets, setPets] = useState("No pets");
  const [cleaningInstructions, setCleaningInstructions] = useState("");
  const [photos, setPhotos] = useState<string[]>([]);
  const cleanTypes = [
    { id: "Regular", icon: "calendar-outline" },
    { id: "Deep", icon: "water-outline" },
    { id: "End of tenancy", icon: "key-outline" },
    { id: "Shared areas", icon: "people-outline" },
  ] as const;
  const labels = isEnglish
    ? {
        title: "Cleaning Services",
        subtitle: "A cleaner space. A brighter student life.",
        service: "Choose your clean",
        sharedScope:
          "Shared kitchens, bathrooms and living areas only. Bedrooms are not included.",
        property: "Property type",
        layout: "Property layout",
        sharedLayout: "Shared areas to clean",
        bedrooms: "Bedrooms",
        bathrooms: "Bathrooms",
        kitchens: "Kitchens",
        livingRooms: "Living rooms",
        date: "Preferred date & availability",
        time: "Arrival window",
        address: "Property address",
        addressHint: "Full address and postcode",
        parking: "Parking details for our cleaners",
        parkingFee: "Expected parking fee",
        parkingNote:
          "Any verified parking charge will be included transparently in your final quote.",
        pets: "Pets at the property",
        instructions: "Special instructions",
        instructionsHint:
          "Tell us about access, priority rooms, fragile items, carpets, personal belongings, or anything else we should know.",
        photos: "Room photos (optional)",
        photoHint:
          "Upload up to 6 photos so we can understand the condition and prepare the right team.",
        upload: "Add room photos",
        quote: "Get a cleaning quote",
        received: "Cleaning quote requested",
        receivedBody:
          "Your property details and preferred availability have been added. Our team will confirm the final price, including any parking fee.",
        regular: "Regular",
        deep: "Deep clean",
        tenancy: "End of tenancy",
        shared: "Shared areas",
      }
    : {
        title: language === "简体" ? "保洁服务" : "清潔服務",
        subtitle:
          language === "简体"
            ? "洁净空间，留学生活更美好。"
            : "潔淨空間，留學生活更美好。",
        service: language === "简体" ? "选择清洁类型" : "選擇清潔類型",
        sharedScope:
          language === "简体"
            ? "仅清洁共用厨房、浴室和客厅，不包括卧室。"
            : "僅清潔共用廚房、浴室和客廳，不包括睡房。",
        property: language === "简体" ? "房屋类型" : "房屋類型",
        layout: language === "简体" ? "房屋布局" : "房屋佈局",
        sharedLayout: language === "简体" ? "需要清洁的共用区域" : "需要清潔的共用區域",
        bedrooms: language === "简体" ? "卧室" : "睡房",
        bathrooms: language === "简体" ? "浴室" : "浴室",
        kitchens: language === "简体" ? "厨房" : "廚房",
        livingRooms: language === "简体" ? "客厅" : "客廳",
        date: language === "简体" ? "首选日期与档期" : "首選日期與檔期",
        time: language === "简体" ? "上门时间段" : "上門時間段",
        address: language === "简体" ? "房屋地址" : "房屋地址",
        addressHint: language === "简体" ? "完整地址及邮编" : "完整地址及郵編",
        parking: language === "简体" ? "清洁人员停车详情" : "清潔人員泊車詳情",
        parkingFee: language === "简体" ? "预计停车费" : "預計泊車費",
        parkingNote:
          language === "简体"
            ? "经核实的停车费将清楚列入最终报价。"
            : "經核實的泊車費將清楚列入最終報價。",
        pets: language === "简体" ? "房屋内是否有宠物" : "房屋內是否有寵物",
        instructions: language === "简体" ? "特别说明" : "特別說明",
        instructionsHint:
          language === "简体"
            ? "请说明门禁、重点房间、易碎品、地毯、个人物品或其他注意事项。"
            : "請說明門禁、重點房間、易碎品、地氈、個人物品或其他注意事項。",
        photos: language === "简体" ? "房间照片（可选）" : "房間照片（可選）",
        photoHint:
          language === "简体"
            ? "最多上传6张照片，方便我们了解房间状况并安排合适人员。"
            : "最多上載6張照片，方便我們了解房間狀況並安排合適人員。",
        upload: language === "简体" ? "添加房间照片" : "加入房間照片",
        quote: language === "简体" ? "获取清洁报价" : "獲取清潔報價",
        received:
          language === "简体" ? "已提交清洁报价请求" : "已提交清潔報價請求",
        receivedBody:
          language === "简体"
            ? "已添加房屋详情与首选时间。团队会确认最终价格，包括停车费。"
            : "已加入房屋詳情與首選時間。團隊會確認最終價格，包括泊車費。",
        regular: language === "简体" ? "日常清洁" : "日常清潔",
        deep: language === "简体" ? "深度清洁" : "深度清潔",
        tenancy: language === "简体" ? "退租清洁" : "退租清潔",
        shared: language === "简体" ? "共用区域" : "共用區域",
      };
  const propertyLabel = (value: string) =>
    ({
      "Student flat / apartment": tr(language, value, "学生公寓", "學生公寓"),
      House: tr(language, value, "独立屋", "獨立屋"),
      Studio: tr(language, value, "单间公寓", "開放式單位"),
      "Bedroom in a flatshare": tr(
        language,
        value,
        "合租房内的卧室",
        "合租單位內的睡房",
      ),
    })[value] || value;
  const parkingLabel = (value: string) =>
    ({
      "Free parking available": tr(language, value, "可免费停车", "可免費泊車"),
      "Resident/visitor permit required": tr(
        language,
        value,
        "需要住户/访客停车证",
        "需要住戶/訪客泊車證",
      ),
      "Paid street parking": tr(
        language,
        value,
        "路边收费停车",
        "路邊收費泊車",
      ),
      "Paid car park nearby": tr(
        language,
        value,
        "附近有收费停车场",
        "附近有收費停車場",
      ),
      "No parking available": tr(language, value, "没有停车位", "沒有泊車位"),
    })[value] || value;
  const petLabel = (value: string) =>
    ({
      "No pets": tr(language, value, "没有宠物", "沒有寵物"),
      "Dog at property": tr(language, value, "房屋内有狗", "房屋內有狗"),
      "Cat at property": tr(language, value, "房屋内有猫", "房屋內有貓"),
      "Other pet": tr(language, value, "其他宠物", "其他寵物"),
    })[value] || value;
  const pickPhotos = async (source?: PhotoSource) => {
    if (!source) {
      askPhotoSource(language, pickPhotos);
      return;
    }
    const uris = await selectPhotoUris(language, source, {
      multiple: source === "library",
      limit: Math.max(1, 6 - photos.length),
      quality: 0.75,
    });
    if (uris.length) setPhotos([...photos, ...uris].slice(0, 6));
  };
  const cleanName =
    cleanType === "Regular"
      ? labels.regular
      : cleanType === "Deep"
        ? labels.deep
        : cleanType === "End of tenancy"
          ? labels.tenancy
          : labels.shared;
  const cleaningEstimate = Math.round((cleanType === "Regular" ? 48 : cleanType === "Deep" ? 85 : cleanType === "End of tenancy" ? 125 : 52) +
    (cleanType === "Shared areas" ? 0 : Math.max(0, bedrooms - 1) * 12) +
    Math.max(0, bathrooms - 1) * 10 + Math.max(0, kitchens - 1) * 9 + Math.max(0, livingRooms - 1) * 8);
  return (
    <View style={styles.formCard}>
      <View style={styles.formHero}>
        <View style={[styles.formHeroIcon, { backgroundColor: "#FFF5E8" }]}>
          <Ionicons name="sparkles" size={27} color="#F28A18" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.formTitle}>{labels.title}</Text>
          <Text style={styles.formDesc}>{labels.subtitle}</Text>
        </View>
      </View>
      <Text style={styles.formSectionTitle}>{labels.service}</Text>
      <View style={styles.cleanTypeGrid}>
        {cleanTypes.map((item) => {
          const label =
            item.id === "Regular"
              ? labels.regular
              : item.id === "Deep"
                ? labels.deep
                : item.id === "End of tenancy"
                  ? labels.tenancy
                : labels.shared;
          return (
            <Pressable
              key={item.id}
              style={[
                styles.cleanType,
                cleanType === item.id && styles.cleanTypeActive,
              ]}
              onPress={() => setCleanType(item.id)}
            >
              <Ionicons
                name={item.icon}
                size={22}
                color={cleanType === item.id ? "white" : palette.blue}
              />
              <Text
                style={[
                  styles.cleanTypeText,
                  cleanType === item.id && styles.cleanTypeTextActive,
                ]}
              >
                {label}
              </Text>
            </Pressable>
          );
        })}
      </View>
      {cleanType === "Shared areas" && (
        <Text style={styles.cleanScopeHint}>{labels.sharedScope}</Text>
      )}
      <SelectField
        label={labels.property}
        value={propertyType}
        options={[
          "Student flat / apartment",
          "House",
          "Studio",
          "Bedroom in a flatshare",
        ]}
        onChange={setPropertyType}
        formatOption={propertyLabel}
      />
      <View style={styles.field}><Text style={styles.fieldLabel}>{tr(language, "Approximate property size (m², optional)", "房屋面积（平方米，可选）", "單位面積（平方米，可選）")}</Text><TextInput value={propertySize} onChangeText={setPropertySize} keyboardType="numeric" placeholder={tr(language, "e.g. 45", "例如：45", "例如：45")} placeholderTextColor="#A1ADBE" /></View>
      <Text style={styles.formSectionTitle}>
        {cleanType === "Shared areas" ? labels.sharedLayout : labels.layout}
      </Text>
      <View style={styles.counterCard}>
        {cleanType !== "Shared areas" && (
          <CounterRow
            label={labels.bedrooms}
            value={bedrooms}
            onChange={setBedrooms}
          />
        )}
        <CounterRow
          label={labels.bathrooms}
          value={bathrooms}
          onChange={setBathrooms}
        />
        <CounterRow
          label={labels.kitchens}
          value={kitchens}
          onChange={setKitchens}
        />
        <CounterRow
          label={labels.livingRooms}
          value={livingRooms}
          onChange={setLivingRooms}
        />
      </View>
      <Text style={styles.formSectionTitle}>{labels.date}</Text>
      <AvailabilityCalendar
        selected={selectedDay}
        onSelect={setSelectedDay}
        language={language}
        bookingMonths={2}
        isUnavailable={isUnavailable}
      />
      <SelectField
        label={labels.time}
        value={timeSlot}
        options={availableTimeSlots}
        onChange={setTimeSlot}
        schedule
        formatOption={(value) => value || tr(language, "No available times", "暂无可预约时段", "暫無可預約時段")}
        hint={tr(language, "Choose your preferred time. The team will confirm availability.", "请选择偏好时段，团队将确认是否可预约。", "請選擇偏好時段，團隊將確認是否可預約。")}
      />
      <AddressLookupField language={language} label={labels.address} value={address} onChange={setAddress} />
      <SelectField
        label={labels.parking}
        value={parking}
        options={[
          "Free parking available",
          "Resident/visitor permit required",
          "Paid street parking",
          "Paid car park nearby",
          "No parking available",
        ]}
        onChange={setParking}
        formatOption={parkingLabel}
      />
      {parking !== "Free parking available" && (
        <SelectField
          label={labels.parkingFee}
          value={parkingFee}
          options={["£0", "£5", "£10", "£15", "£20+"]}
          onChange={setParkingFee}
          hint={labels.parkingNote}
        />
      )}
      <SelectField
        label={labels.pets}
        value={pets}
        options={["No pets", "Dog at property", "Cat at property", "Other pet"]}
        onChange={setPets}
        formatOption={petLabel}
      />
      <BelongingsNotice language={language} context="property" />
      <View style={[styles.field, styles.textAreaField]}>
        <Text style={styles.fieldLabel}>{labels.instructions}</Text>
        <TextInput
          multiline
          numberOfLines={5}
          value={cleaningInstructions}
          onChangeText={setCleaningInstructions}
          placeholder={labels.instructionsHint}
          placeholderTextColor="#A1ADBE"
          style={styles.textAreaInput}
          textAlignVertical="top"
        />
      </View>
      <Text style={styles.formSectionTitle}>{labels.photos}</Text>
      <Text style={styles.photoHelp}>{labels.photoHint}</Text>
      <Pressable style={styles.cleanPhotoPicker} onPress={() => pickPhotos()}>
        <View style={styles.photoIcon}>
          <Ionicons name="images-outline" size={24} color={palette.blue} />
        </View>
        <Text style={styles.photoTitle}>{labels.upload}</Text>
        <Text style={styles.photoHint}>{photos.length}/6</Text>
      </Pressable>
      {photos.length > 0 && (
        <View style={styles.cleanPhotoGrid}>
          {photos.map((uri, index) => (
            <Pressable
              key={uri}
              style={styles.cleanPhotoWrap}
              onPress={() =>
                setPhotos(
                  photos.filter((_, photoIndex) => photoIndex !== index),
                )
              }
            >
              <Image source={{ uri }} style={styles.cleanPhoto} />
              <View style={styles.removePhoto}>
                <Ionicons name="close" size={13} color="white" />
              </View>
            </Pressable>
          ))}
        </View>
      )}
      <View style={styles.cleanSummary}>
        <Ionicons name="document-text-outline" size={20} color={palette.blue} />
        <Text style={styles.cleanSummaryText}>
          {cleanName} · {cleanType !== "Shared areas" && (
            <>{bedrooms} {labels.bedrooms.toLowerCase()} · </>
          )}{bathrooms}{" "}
          {labels.bathrooms.toLowerCase()} · {kitchens}{" "}
          {labels.kitchens.toLowerCase()} · {livingRooms}{" "}
          {labels.livingRooms.toLowerCase()} ·{" "}
          {formatBookingDate(selectedDay, language)} · {timeSlot}
        </Text>
      </View>
      <Pressable
        disabled={!timeSlot}
        style={[styles.primaryButton, !timeSlot && { opacity: 0.5 }]}
        onPress={() => onCheckout({
          service: "cleaning",
          title: labels.title,
          details: `${cleanName} · ${address.trim() || tr(language, "Address to confirm", "地址待确认", "地址待確認")}`,
          when: `${formatBookingDate(selectedDay, language)} · ${timeSlot}`,
          total: cleaningEstimate,
          dueNow: Math.round(cleaningEstimate * 25) / 100,
          note: tr(language, "25% booking deposit. This estimate may change after the property details are confirmed. Cancellation deductions should reflect actual loss.", "25%预订订金。房屋详情确认后估价可能调整。取消扣款应反映实际损失。", "25%預訂訂金。物業詳情確認後估價可能調整。取消扣款應反映實際損失。"),
          bookingDate: formatStaffBookingDate(selectedDay),
          bookingTime: timeSlot,
          bookingAddress: address.trim(),
          intake: { fields: [
            { label: "Cleaning type", value: cleanName },
            { label: "Property type", value: propertyType },
            { label: "Approximate size", value: propertySize.trim() ? `${propertySize.trim()} m²` : "Not provided" },
            { label: "Bedrooms", value: cleanType === "Shared areas" ? "Not included" : String(bedrooms) },
            { label: "Bathrooms", value: String(bathrooms) },
            { label: "Kitchens", value: String(kitchens) },
            { label: "Living rooms", value: String(livingRooms) },
            { label: "Pets", value: pets },
            { label: "Parking", value: parking },
            { label: "Parking fee", value: parking === "Free parking available" ? "£0" : parkingFee },
            { label: "Special instructions", value: cleaningInstructions.trim() || "None provided" },
          ], photos: [...photos] },
        })}
      >
        <Text style={styles.primaryButtonText}>{tr(language, "Review request", "查看服务申请", "查看服務申請")}</Text>
      </Pressable>
    </View>
  );
}


function MovingServiceForm({ language, onCheckout, isUnavailable, isTimeUnavailable }: { language: Language; onCheckout: (order: ServiceCheckoutOrder) => void; isUnavailable?: (dayKey: string) => boolean; isTimeUnavailable?: (dayKey: string, time: string) => boolean }) {
  const [fromFloor, setFromFloor] = useState("Ground floor");
  const [toFloor, setToFloor] = useState("Ground floor");
  const [fromAccess, setFromAccess] = useState("Lift available");
  const [toAccess, setToAccess] = useState("Lift available");
  const [fromParking, setFromParking] = useState("Free parking available");
  const [toParking, setToParking] = useState("Free parking available");
  const [smallBoxes, setSmallBoxes] = useState(2);
  const [largeBoxes, setLargeBoxes] = useState(2);
  const [suitcases, setSuitcases] = useState(1);
  const [sofas, setSofas] = useState(0);
  const [beds, setBeds] = useState(0);
  const [wardrobes, setWardrobes] = useState(0);
  const [tablesChairs, setTablesChairs] = useState(0);
  const [appliances, setAppliances] = useState(0);
  const [customItems, setCustomItems] = useState(0);
  const [crew, setCrew] = useState<"one" | "two">("one");
  const [selectedDay, setSelectedDay] = useState(() => bookingDateFromToday(7));
  const [fromAddress, setFromAddress] = useState("");
  const [toAddress, setToAddress] = useState("");
  const [timeSlot, setTimeSlot] = useState("09:00–12:00");
  const availableTimeSlots = movingPickupWindows.filter((slot) => !isTimeUnavailable?.(selectedDay, slot));
  useEffect(() => { if (!availableTimeSlots.includes(timeSlot)) setTimeSlot(availableTimeSlots[0] || ""); }, [selectedDay, availableTimeSlots.join("|")]);
  const [photos, setPhotos] = useState<string[]>([]);
  const [movingInstructions, setMovingInstructions] = useState("");
  const floors = [
    "Ground floor",
    "1st floor",
    "2nd floor",
    "3rd floor",
    "4th floor",
    "5th floor",
    "6th floor or above",
  ];
  const accessOptions = [
    "Lift available",
    "Stairs only",
    "Lift and stairs",
    "Step-free access",
  ];
  const parkingOptions = [
    "Free parking available",
    "Permit required",
    "Paid street parking",
    "Paid car park nearby",
    "No parking available",
  ];
  const labels = {
    title: tr(
      language,
      "Student Moving Service",
      "学生搬家服务",
      "學生搬屋服務",
    ),
    subtitle: tr(
      language,
      "Reliable help for moving in or moving out.",
      "为入住与退房提供可靠搬运服务。",
      "為入住與退房提供可靠搬運服務。",
    ),
    noPacking: tr(
      language,
      "Moving only — packing and unpacking are not included. Please have all belongings securely packed before the team arrives.",
      "仅提供搬运服务，不包含打包或拆包。请在团队到达前妥善打包所有物品。",
      "只提供搬運服務，不包括打包或拆包。請在團隊到達前妥善打包所有物品。",
    ),
    from: tr(language, "Moving from", "搬出地址", "搬出地址"),
    to: tr(language, "Moving to", "搬入地址", "搬入地址"),
    addressHint: tr(
      language,
      "Full address and postcode",
      "完整地址及邮编",
      "完整地址及郵編",
    ),
    fromAccess: tr(
      language,
      "Collection access",
      "搬出地点通行条件",
      "搬出地點通行條件",
    ),
    toAccess: tr(
      language,
      "Delivery access",
      "搬入地点通行条件",
      "搬入地點通行條件",
    ),
    floor: tr(language, "Floor", "楼层", "樓層"),
    access: tr(language, "Lift or stairs", "电梯或楼梯", "升降機或樓梯"),
    parkingFrom: tr(
      language,
      "Parking at collection",
      "搬出地点停车",
      "搬出地點泊車",
    ),
    parkingTo: tr(
      language,
      "Parking at delivery",
      "搬入地点停车",
      "搬入地點泊車",
    ),
    inventory: tr(
      language,
      "What are you moving?",
      "需要搬运什么？",
      "需要搬運甚麼？",
    ),
    small: tr(language, "Small boxes / bags", "小箱子 / 袋子", "小箱 / 袋"),
    large: tr(language, "Large boxes", "大箱子", "大箱"),
    suitcases: tr(language, "Suitcases", "行李箱", "行李箱"),
    sofas: tr(language, "Sofas", "沙发", "梳化"),
    beds: tr(language, "Beds & mattresses", "床和床垫", "床及床褥"),
    wardrobes: tr(
      language,
      "Wardrobes / drawers",
      "衣柜 / 抽屉柜",
      "衣櫃 / 抽屜櫃",
    ),
    tables: tr(language, "Tables & chairs", "桌子和椅子", "桌及椅"),
    appliances: tr(
      language,
      "Appliances / televisions",
      "家电 / 电视",
      "家電 / 電視",
    ),
    custom: tr(language, "Custom items", "自定义物品", "自訂物品"),
    customName: tr(
      language,
      "Custom item name",
      "自定义物品名称",
      "自訂物品名稱",
    ),
    customNameHint: tr(
      language,
      "For example: keyboard stand",
      "例如：电子琴架",
      "例如：電子琴架",
    ),
    dimensions: tr(
      language,
      "Approximate dimensions or weight",
      "大致尺寸或重量",
      "大約尺寸或重量",
    ),
    dimensionsHint: tr(
      language,
      "For example: 120 × 50 × 70 cm, 20 kg",
      "例如：120 × 50 × 70厘米，20公斤",
      "例如：120 × 50 × 70厘米，20公斤",
    ),
    crew: tr(
      language,
      "Choose your moving team",
      "选择搬运人员",
      "選擇搬運人員",
    ),
    one: tr(language, "1 mover", "1名搬运人员", "1名搬運人員"),
    oneHint: tr(
      language,
      "Best for lighter student moves",
      "适合物品较少的学生搬家",
      "適合物品較少的學生搬屋",
    ),
    two: tr(language, "2 movers", "2名搬运人员", "2名搬運人員"),
    twoHint: tr(
      language,
      "Recommended for stairs or bulky items",
      "楼梯搬运或大型物品时推荐",
      "樓梯搬運或大型物品時建議",
    ),
    date: tr(language, "Moving date", "搬家日期", "搬屋日期"),
    time: tr(language, "Arrival window", "上门时间段", "上門時間段"),
    photos: tr(
      language,
      "Photos of items (optional)",
      "物品照片（可选）",
      "物品相片（可選）",
    ),
    photoHint: tr(
      language,
      "Upload up to 6 photos to help us choose the right van and team.",
      "最多上传6张照片，帮助我们安排合适的车辆和人员。",
      "最多上載6張相片，幫助我們安排合適的車輛和人員。",
    ),
    upload: tr(language, "Add item photos", "添加物品照片", "加入物品相片"),
    details: tr(language, "Extra details", "其他说明", "其他說明"),
    detailsHint: tr(
      language,
      "Tell us about access restrictions, fragile or unusually large items, loading times, or anything else we should know.",
      "请说明门禁限制、易碎或超大物品、装卸时限或其他注意事项。",
      "請說明門禁限制、易碎或超大型物品、裝卸時限或其他注意事項。",
    ),
    quote: tr(language, "Get a moving quote", "获取搬家报价", "獲取搬屋報價"),
    received: tr(
      language,
      "Moving quote requested",
      "已提交搬家报价请求",
      "已提交搬屋報價請求",
    ),
    receivedBody: tr(
      language,
      "Your moving details have been added. We will confirm vehicle size, access, parking costs and final price.",
      "已添加搬家详情。我们会确认车型、通行条件、停车费和最终价格。",
      "已加入搬屋詳情。我們會確認車型、通行條件、泊車費和最終價格。",
    ),
  };
  const floorLabel = (value: string) =>
    ({
      "Ground floor": tr(language, value, "底层", "地下"),
      "1st floor": tr(language, value, "1楼", "1樓"),
      "2nd floor": tr(language, value, "2楼", "2樓"),
      "3rd floor": tr(language, value, "3楼", "3樓"),
      "4th floor": tr(language, value, "4楼", "4樓"),
      "5th floor": tr(language, value, "5楼", "5樓"),
      "6th floor or above": tr(language, value, "6楼或以上", "6樓或以上"),
    })[value] || value;
  const accessLabel = (value: string) =>
    ({
      "Lift available": tr(language, value, "有电梯", "有升降機"),
      "Stairs only": tr(language, value, "仅楼梯", "只有樓梯"),
      "Lift and stairs": tr(language, value, "电梯及楼梯", "升降機及樓梯"),
      "Step-free access": tr(language, value, "无障碍通行", "無障礙通行"),
    })[value] || value;
  const parkingLabel = (value: string) =>
    ({
      "Free parking available": tr(language, value, "可免费停车", "可免費泊車"),
      "Permit required": tr(language, value, "需要停车证", "需要泊車證"),
      "Paid street parking": tr(
        language,
        value,
        "路边收费停车",
        "路邊收費泊車",
      ),
      "Paid car park nearby": tr(
        language,
        value,
        "附近有收费停车场",
        "附近有收費停車場",
      ),
      "No parking available": tr(language, value, "没有停车位", "沒有泊車位"),
    })[value] || value;
  const pickPhotos = async (source?: PhotoSource) => {
    if (!source) {
      askPhotoSource(language, pickPhotos);
      return;
    }
    const uris = await selectPhotoUris(language, source, {
      multiple: source === "library",
      limit: Math.max(1, 6 - photos.length),
      quality: 0.75,
    });
    if (uris.length) setPhotos([...photos, ...uris].slice(0, 6));
  };
  const movingEstimate = Math.round(75 + (crew === "two" ? 45 : 0) + smallBoxes * 4 + largeBoxes * 7 + suitcases * 6 + sofas * 28 + beds * 30 + wardrobes * 26 + tablesChairs * 15 + appliances * 24 + customItems * 12);
  return (
    <View style={styles.formCard}>
      <View style={styles.formHero}>
        <View style={[styles.formHeroIcon, { backgroundColor: "#E7F8F8" }]}>
          <Ionicons name="cube" size={27} color="#00A1A7" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.formTitle}>{labels.title}</Text>
          <Text style={styles.formDesc}>{labels.subtitle}</Text>
        </View>
      </View>
      <View style={styles.movingNotice}>
        <Ionicons name="information-circle" size={21} color="#007E84" />
        <Text style={styles.movingNoticeText}>{labels.noPacking}</Text>
      </View>
      <Text style={styles.formSectionTitle}>{labels.from}</Text>
      <AddressLookupField language={language} label={labels.from} value={fromAddress} onChange={setFromAddress} />
      <View style={styles.formTwoColumns}>
        <View style={styles.formHalf}>
          <SelectField
            label={labels.floor}
            value={fromFloor}
            options={floors}
            onChange={setFromFloor}
            formatOption={floorLabel}
          />
        </View>
        <View style={styles.formHalf}>
          <SelectField
            label={labels.access}
            value={fromAccess}
            options={accessOptions}
            onChange={setFromAccess}
            formatOption={accessLabel}
          />
        </View>
      </View>
      <SelectField
        label={labels.parkingFrom}
        value={fromParking}
        options={parkingOptions}
        onChange={setFromParking}
        formatOption={parkingLabel}
      />
      <Text style={styles.formSectionTitle}>{labels.to}</Text>
      <AddressLookupField language={language} label={labels.to} value={toAddress} onChange={setToAddress} />
      <View style={styles.formTwoColumns}>
        <View style={styles.formHalf}>
          <SelectField
            label={labels.floor}
            value={toFloor}
            options={floors}
            onChange={setToFloor}
            formatOption={floorLabel}
          />
        </View>
        <View style={styles.formHalf}>
          <SelectField
            label={labels.access}
            value={toAccess}
            options={accessOptions}
            onChange={setToAccess}
            formatOption={accessLabel}
          />
        </View>
      </View>
      <SelectField
        label={labels.parkingTo}
        value={toParking}
        options={parkingOptions}
        onChange={setToParking}
        formatOption={parkingLabel}
      />
      <Text style={styles.formSectionTitle}>{labels.inventory}</Text>
      <View style={styles.counterCard}>
        <CounterRow
          label={labels.small}
          value={smallBoxes}
          onChange={setSmallBoxes}
        />
        <CounterRow
          label={labels.large}
          value={largeBoxes}
          onChange={setLargeBoxes}
        />
        <CounterRow
          label={labels.suitcases}
          value={suitcases}
          onChange={setSuitcases}
        />
        <CounterRow label={labels.sofas} value={sofas} onChange={setSofas} />
        <CounterRow label={labels.beds} value={beds} onChange={setBeds} />
        <CounterRow
          label={labels.wardrobes}
          value={wardrobes}
          onChange={setWardrobes}
        />
        <CounterRow
          label={labels.tables}
          value={tablesChairs}
          onChange={setTablesChairs}
        />
        <CounterRow
          label={labels.appliances}
          value={appliances}
          onChange={setAppliances}
        />
        <CounterRow
          label={labels.custom}
          value={customItems}
          onChange={setCustomItems}
        />
      </View>
      {customItems > 0 && (
        <View style={styles.customItemsList}>
          {Array.from({ length: customItems }, (_, index) => (
            <View key={`custom-${index}`} style={styles.customItemCard}>
              <View style={styles.customItemHead}>
                <View style={styles.customItemIcon}>
                  <Ionicons
                    name="cube-outline"
                    size={18}
                    color={palette.blue}
                  />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.customItemTitle}>
                    {tr(
                      language,
                      `Custom item ${index + 1}`,
                      `自定义物品 ${index + 1}`,
                      `自訂物品 ${index + 1}`,
                    )}
                  </Text>
                  <Text style={styles.customItemSubtitle}>
                    {tr(
                      language,
                      "Give us enough detail to choose the right van and handling equipment.",
                      "请提供足够信息，便于我们安排合适车辆和搬运设备。",
                      "請提供足夠資料，方便我們安排合適車輛和搬運設備。",
                    )}
                  </Text>
                </View>
              </View>
              <View style={styles.field}>
                <Text style={styles.fieldLabel}>{labels.customName}</Text>
                <TextInput
                  placeholder={labels.customNameHint}
                  placeholderTextColor="#A1ADBE"
                />
              </View>
              <Text style={styles.customMeasureLabel}>
                {tr(language, "Estimated dimensions", "预估尺寸", "預估尺寸")}
              </Text>
              <View style={styles.customDimensions}>
                <View style={styles.customDimensionField}>
                  <Text style={styles.customDimensionLabel}>
                    {tr(language, "Length", "长", "長")}
                  </Text>
                  <TextInput
                    keyboardType="decimal-pad"
                    placeholder="0"
                    placeholderTextColor="#A1ADBE"
                    style={styles.customDimensionInput}
                  />
                </View>
                <View style={styles.customDimensionField}>
                  <Text style={styles.customDimensionLabel}>
                    {tr(language, "Width", "宽", "寬")}
                  </Text>
                  <TextInput
                    keyboardType="decimal-pad"
                    placeholder="0"
                    placeholderTextColor="#A1ADBE"
                    style={styles.customDimensionInput}
                  />
                </View>
                <View style={styles.customDimensionField}>
                  <Text style={styles.customDimensionLabel}>
                    {tr(language, "Height", "高", "高")}
                  </Text>
                  <TextInput
                    keyboardType="decimal-pad"
                    placeholder="0"
                    placeholderTextColor="#A1ADBE"
                    style={styles.customDimensionInput}
                  />
                </View>
                <View style={styles.customUnit}>
                  <Text style={styles.customUnitText}>CM</Text>
                </View>
              </View>
              <View style={styles.customWeightRow}>
                <View style={[styles.field, styles.customWeightField]}>
                  <Text style={styles.fieldLabel}>
                    {tr(language, "Estimated weight", "预估重量", "預估重量")}
                  </Text>
                  <TextInput
                    keyboardType="decimal-pad"
                    placeholder="0"
                    placeholderTextColor="#A1ADBE"
                  />
                </View>
                <View style={styles.customUnit}>
                  <Text style={styles.customUnitText}>KG</Text>
                </View>
              </View>
              <View style={[styles.field, styles.customNotesField]}>
                <Text style={styles.fieldLabel}>
                  {tr(
                    language,
                    "Handling notes (optional)",
                    "搬运注意事项（可选）",
                    "搬運注意事項（可選）",
                  )}
                </Text>
                <TextInput
                  placeholder={tr(
                    language,
                    "Fragile, awkward shape, needs dismantling…",
                    "易碎、形状不规则、需拆卸…",
                    "易碎、形狀不規則、需拆卸…",
                  )}
                  placeholderTextColor="#A1ADBE"
                />
              </View>
            </View>
          ))}
        </View>
      )}
      <Text style={styles.formSectionTitle}>{labels.crew}</Text>
      <View style={styles.crewGrid}>
        {(
          [
            {
              id: "one",
              icon: "person",
              title: labels.one,
              hint: labels.oneHint,
            },
            {
              id: "two",
              icon: "people",
              title: labels.two,
              hint: labels.twoHint,
            },
          ] as const
        ).map((item) => (
          <Pressable
            key={item.id}
            style={[
              styles.crewOption,
              crew === item.id && styles.crewOptionActive,
            ]}
            onPress={() => setCrew(item.id)}
          >
            <Ionicons
              name={item.icon}
              size={23}
              color={crew === item.id ? palette.blue : palette.muted}
            />
            <View style={{ flex: 1 }}>
              <Text style={styles.crewTitle}>{item.title}</Text>
              <Text style={styles.crewHint}>{item.hint}</Text>
            </View>
            {crew === item.id && (
              <Ionicons
                name="checkmark-circle"
                size={19}
                color={palette.blue}
              />
            )}
          </Pressable>
        ))}
      </View>
      <BelongingsNotice language={language} context="move" />
      <Text style={styles.formSectionTitle}>{labels.date}</Text>
      <AvailabilityCalendar
        selected={selectedDay}
        onSelect={setSelectedDay}
        language={language}
        compact
        bookingMonths={2}
        isUnavailable={isUnavailable}
      />
      <SelectField
        label={labels.time}
        value={timeSlot}
        options={availableTimeSlots}
        onChange={setTimeSlot}
        schedule
        formatOption={(value) => value || tr(language, "No available times", "暂无可预约时段", "暫無可預約時段")}
        hint={tr(language, "Choose your preferred time. The team will confirm availability.", "请选择偏好时段，团队将确认是否可预约。", "請選擇偏好時段，團隊將確認是否可預約。")}
      />
      <Text style={styles.formSectionTitle}>{labels.photos}</Text>
      <Text style={styles.photoHelp}>{labels.photoHint}</Text>
      <Pressable style={styles.cleanPhotoPicker} onPress={() => pickPhotos()}>
        <View style={styles.photoIcon}>
          <Ionicons name="images-outline" size={24} color={palette.blue} />
        </View>
        <Text style={styles.photoTitle}>{labels.upload}</Text>
        <Text style={styles.photoHint}>{photos.length}/6</Text>
      </Pressable>
      {photos.length > 0 && (
        <View style={styles.cleanPhotoGrid}>
          {photos.map((uri, index) => (
            <Pressable
              key={uri}
              style={styles.cleanPhotoWrap}
              onPress={() =>
                setPhotos(
                  photos.filter((_, photoIndex) => photoIndex !== index),
                )
              }
            >
              <Image source={{ uri }} style={styles.cleanPhoto} />
              <View style={styles.removePhoto}>
                <Ionicons name="close" size={13} color="white" />
              </View>
            </Pressable>
          ))}
        </View>
      )}
      <View style={[styles.field, styles.textAreaField]}>
        <Text style={styles.fieldLabel}>{labels.details}</Text>
        <TextInput
          multiline
          numberOfLines={5}
          value={movingInstructions}
          onChangeText={setMovingInstructions}
          placeholder={labels.detailsHint}
          placeholderTextColor="#A1ADBE"
          style={styles.textAreaInput}
          textAlignVertical="top"
        />
      </View>
      <View style={styles.cleanSummary}>
        <Ionicons name="car-sport-outline" size={20} color="#00A1A7" />
        <Text style={styles.cleanSummaryText}>
          {crew === "one" ? labels.one : labels.two} · {smallBoxes}{" "}
          {labels.small.toLowerCase()} · {largeBoxes}{" "}
          {labels.large.toLowerCase()} ·{" "}
          {formatBookingDate(selectedDay, language)} · {timeSlot}
        </Text>
      </View>
      <Pressable
        disabled={!timeSlot}
        style={[styles.primaryButton, !timeSlot && { opacity: 0.5 }]}
        onPress={() => onCheckout({
          service: "moving",
          title: labels.title,
          details: `${fromAddress.trim() || tr(language, "Pickup address to confirm", "搬出地址待确认", "搬出地址待確認")} → ${toAddress.trim() || tr(language, "Drop-off address to confirm", "搬入地址待确认", "搬入地址待確認")} · ${crew === "one" ? labels.one : labels.two}`,
          when: `${formatBookingDate(selectedDay, language)} · ${timeSlot}`,
          total: movingEstimate,
          dueNow: Math.round(movingEstimate * 25) / 100,
          note: tr(language, "25% booking deposit. This estimate may change after route, access and inventory are confirmed. Cancellation deductions should reflect actual loss.", "25%预订订金。路线、通行条件和物品确认后估价可能调整。取消扣款应反映实际损失。", "25%預訂訂金。路線、通行條件及物品確認後估價可能調整。取消扣款應反映實際損失。"),
          bookingDate: formatStaffBookingDate(selectedDay),
          bookingTime: timeSlot,
          bookingAddress: `${fromAddress.trim()} → ${toAddress.trim()}`,
          intake: { fields: [
            { label: "Pickup address", value: fromAddress.trim() || "Not provided" },
            { label: "Drop-off address", value: toAddress.trim() || "Not provided" },
            { label: "Pickup floor & access", value: `${fromFloor} · ${fromAccess}` },
            { label: "Drop-off floor & access", value: `${toFloor} · ${toAccess}` },
            { label: "Pickup parking", value: fromParking },
            { label: "Drop-off parking", value: toParking },
            { label: "Inventory", value: `${smallBoxes} small boxes · ${largeBoxes} large boxes · ${suitcases} suitcases · ${sofas} sofas · ${beds} beds · ${wardrobes} wardrobes · ${tablesChairs} tables/chairs · ${appliances} appliances · ${customItems} other items` },
            { label: "Crew", value: crew === "one" ? "1 mover" : "2 movers" },
            { label: "Special instructions", value: movingInstructions.trim() || "None provided" },
          ], photos: [...photos] },
        })}
      >
        <Text style={styles.primaryButtonText}>{tr(language, "Review request", "查看服务申请", "查看服務申請")}</Text>
      </Pressable>
    </View>
  );
}


function ServiceForm({ type, language, onCheckout, isUnavailable, isTimeUnavailable }: { type: string; language: Language; onCheckout: (order: ServiceCheckoutOrder) => void; isUnavailable?: (dayKey: string) => boolean; isTimeUnavailable?: (dayKey: string, time: string) => boolean }) {
  if (type === "Airport transfer")
    return <AirportTransferForm language={language} onCheckout={onCheckout} isUnavailable={isUnavailable} isTimeUnavailable={isTimeUnavailable} />;
  if (type === "Moving") return <MovingServiceForm language={language} onCheckout={onCheckout} isUnavailable={isUnavailable} isTimeUnavailable={isTimeUnavailable} />;
  return <CleaningServiceForm language={language} onCheckout={onCheckout} isUnavailable={isUnavailable} isTimeUnavailable={isTimeUnavailable} />;
}

const cleaningArrivalWindows = ["09:00–12:00", "12:00–15:00", "15:00–18:00"];

const movingPickupWindows = [...cleaningArrivalWindows, "18:00–21:00"];

const airportTimeHours = Array.from({ length: 24 }, (_, index) => String(index).padStart(2, "0"));

const airportTimeMinutes = Array.from({ length: 60 }, (_, index) => String(index).padStart(2, "0"));


const styles = StyleSheet.create({
  headerPostButton: { height: 34, flexShrink: 0, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, paddingHorizontal: 10, borderRadius: 9, borderWidth: 1, borderColor: "#CFE2F8", backgroundColor: "#F4F9FF" },
  appFrame: { flex: 1, backgroundColor: "#F4F7FB" },
  demoSwitchButton: { position: "absolute", right: 18, bottom: 82, zIndex: 20, flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 11, paddingVertical: 8, borderRadius: 18, backgroundColor: "#184D94", shadowColor: "#092B5B", shadowOpacity: 0.18, shadowRadius: 7, elevation: 4 },
  demoSwitchText: { color: "#FFFFFF", fontSize: 10, fontWeight: "800" },
  darkAppFrame: { backgroundColor: "#0B1423" },
  safe: {
    flex: 1,
    width: "100%",
    maxWidth: 430,
    alignSelf: "center",
    backgroundColor: palette.white,
  },
  content: { flex: 1, minHeight: 0 },
  scroll: { paddingHorizontal: 20, paddingTop: 14, paddingBottom: 24 },
  forumAreaTabs: { flexDirection: "row", marginHorizontal: 18, marginTop: 14, padding: 4, borderRadius: 14, backgroundColor: "#E8F4FF", gap: 4 },
  forumAreaTab: { flex: 1, minHeight: 44, flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 8, borderRadius: 11 },
  forumAreaTabActive: { backgroundColor: "#FFFFFF" },
  momentsCover: { borderRadius: 19, padding: 22, marginBottom: 16 },
  momentProfileCover: { height: 195, borderRadius: 12, overflow: "hidden", marginBottom: 18 },
  momentCoverButton: { position: "absolute", top: 10, right: 10, width: 32, height: 32, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(0,0,0,0.24)", borderRadius: 16 },
  momentCoverIdentity: { position: "absolute", bottom: 14, right: 14, left: 14, flexDirection: "row", justifyContent: "flex-end", alignItems: "center", gap: 14 },
  momentPinnedTile: { width: 116, minHeight: 112, backgroundColor: "#F2F6FB", borderRadius: 8, padding: 10, gap: 7, alignItems: "center", justifyContent: "center" },
  momentSettingsRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 19, borderBottomWidth: 1, borderBottomColor: palette.line },
  momentTimelinePost: { flexDirection: "row", alignItems: "flex-start", gap: 12, paddingVertical: 20, borderBottomWidth: 1, borderBottomColor: palette.line },
  momentEventCard: { flexDirection: "row", alignItems: "center", gap: 10, padding: 12, borderRadius: 8, backgroundColor: "#F2F6FB", marginBottom: 12 },
  momentTimelineMeta: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  momentMoreButton: { minWidth: 44, minHeight: 36, borderRadius: 5, backgroundColor: "#F2F6FB", alignItems: "center", justifyContent: "center" },
  momentQuickActions: { flexDirection: "row", alignSelf: "flex-end", gap: 20, borderRadius: 8, paddingHorizontal: 14, backgroundColor: "#E8F4FF", marginBottom: 8 },
  momentInlineReply: { flexDirection: "row", alignItems: "center", gap: 6 },
  momentCommentLike: { minWidth: 36, minHeight: 36, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4 },
  momentComposer: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: palette.line, padding: 14, borderRadius: 16, marginBottom: 22 },
  momentAvatar: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#E8F4FF", alignItems: "center", justifyContent: "center" },
  momentInitials: { fontSize: 14, fontWeight: "800", color: palette.blue },
  momentFeedHeading: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 14 },
  momentCard: { padding: 16, borderRadius: 16, backgroundColor: "#FFFFFF", borderColor: palette.line, borderWidth: 1, marginBottom: 16 },
  momentAuthorRow: { flexDirection: "row", alignItems: "center", gap: 11, marginBottom: 12 },
  momentCaption: { fontSize: 14, lineHeight: 22, color: palette.ink, marginBottom: 12 },
  momentPhotoGrid: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginBottom: 10 },
  momentPhoto: { width: "100%", aspectRatio: 1, borderRadius: 10, backgroundColor: "#E8F4FF" },
  momentLocation: { flexDirection: "row", alignItems: "center", gap: 5, marginVertical: 10 },
  momentActions: { flexDirection: "row", gap: 16, borderTopWidth: 1, borderTopColor: palette.line },
  momentAction: { minHeight: 44, flexDirection: "row", alignItems: "center", gap: 7 },
  momentReplies: { backgroundColor: "#F2F6FB", borderRadius: 10, padding: 12, gap: 7 },
  momentRemovePhoto: { position: "absolute", right: 2, top: 2, backgroundColor: "#FFFFFF", borderRadius: 14 },
  faqHero: { flexDirection: "row", alignItems: "center", gap: 12, borderRadius: 19, padding: 20, marginBottom: 14, backgroundColor: palette.navy },
  faqEyebrow: { color: "#9FD2FF", fontSize: 10, fontWeight: "900", letterSpacing: 1.4, marginBottom: 7 },
  faqHeroTitle: { color: palette.white, fontSize: 26, fontWeight: "900", marginBottom: 6 },
  faqHeroText: { color: "#DBE9FB", fontSize: 13, lineHeight: 19 },
  faqAskButton: { backgroundColor: palette.blue, borderRadius: 13, paddingHorizontal: 16, paddingVertical: 14, marginBottom: 16, flexDirection: "row", alignItems: "center", gap: 9 },
  faqAskText: { color: palette.white, fontSize: 14, fontWeight: "800", flex: 1 },
  faqChipRow: { flexDirection: "row", gap: 8, paddingBottom: 12 },
  faqChip: { paddingHorizontal: 15, paddingVertical: 9, backgroundColor: "#F2F6FB", borderRadius: 20, borderWidth: 1, borderColor: palette.line },
  faqChipActive: { backgroundColor: palette.navy, borderColor: palette.navy },
  faqChipText: { color: palette.ink, fontSize: 12, fontWeight: "700" },
  faqChipTextActive: { color: palette.white },
  faqTopicChip: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 16, backgroundColor: palette.white, borderWidth: 1, borderColor: palette.line },
  faqTopicChipActive: { backgroundColor: palette.sky, borderColor: palette.blue },
  faqTopicText: { color: palette.muted, fontSize: 11, fontWeight: "700" },
  faqTopicTextActive: { color: palette.blue },
  faqSectionHead: { marginTop: 13, marginBottom: 10, gap: 3 },
  faqCard: { borderWidth: 1, borderColor: palette.line, backgroundColor: palette.white, borderRadius: 16, padding: 16, marginBottom: 11 },
  faqCardTop: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 12 },
  faqOfficialIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: palette.sky, alignItems: "center", justifyContent: "center" },
  faqOfficialBadge: { color: palette.blue, fontSize: 10, fontWeight: "900", letterSpacing: 0.5 },
  faqCategory: { color: palette.muted, fontSize: 11, fontWeight: "700", marginTop: 3 },
  faqCardTitle: { color: palette.ink, fontSize: 16, fontWeight: "800", lineHeight: 22, marginBottom: 6 },
  faqCardSummary: { color: palette.muted, fontSize: 12, lineHeight: 18 },
  forumCardActionRow: { flexDirection: "row", alignItems: "center", paddingHorizontal: 8, paddingTop: 3, paddingBottom: 3 },
  forumCardAction: { flex: 1, minWidth: 0, minHeight: 44, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5 },
  forumCardActionCount: { fontSize: 12, lineHeight: 18, fontWeight: "600", color: palette.muted, fontVariant: ["tabular-nums"] },
  faqCardFooter: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 14, borderTopWidth: 1, borderTopColor: palette.line, paddingTop: 11 },
  faqMeta: { color: palette.muted, fontSize: 11, fontWeight: "700", marginRight: 9 },
  faqCardAuthor: { color: palette.ink, fontSize: 12, fontWeight: "700" },
  faqDisclaimer: { color: palette.muted, fontSize: 11, lineHeight: 17, marginTop: 10 },
  faqDetailHead: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  faqDetailTitle: { color: palette.navy, fontSize: 25, fontWeight: "800", lineHeight: 33, marginBottom: 12 },
  faqDetailParagraph: { color: palette.ink, fontSize: 16, lineHeight: 27, marginTop: 16 },
  faqSourceCard: { borderRadius: 13, padding: 14, backgroundColor: palette.sky, marginTop: 19, gap: 10 },
  faqSourceTitle: { color: palette.navy, fontSize: 12, fontWeight: "800" },
  faqSourceLink: { flexDirection: "row", alignItems: "center", gap: 8 },
  faqSourceText: { color: palette.blue, fontSize: 12, fontWeight: "700", flex: 1 },
  faqDetailActions: { flexDirection: "row", flexWrap: "wrap", alignItems: "center", gap: 14, paddingVertical: 14, borderTopWidth: 1, borderBottomWidth: 1, borderColor: palette.line, marginVertical: 20 },
  faqAction: { flexDirection: "row", alignItems: "center", gap: 6 },
  faqActionText: { color: palette.blue, fontSize: 12, fontWeight: "800" },
  faqCommentsTitle: { color: palette.ink, fontSize: 16, fontWeight: "800", marginBottom: 10 },
  faqComment: { borderTopWidth: 1, borderTopColor: palette.line, paddingVertical: 12 },
  faqCommentTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 6 },
  faqCommentText: { color: palette.ink, fontSize: 13, lineHeight: 19 },
  faqCommentInput: { borderWidth: 1, borderColor: palette.line, borderRadius: 11, minHeight: 72, padding: 11, marginTop: 14, marginBottom: 10, color: palette.ink, textAlignVertical: "top" },
  faqInput: { borderWidth: 1, borderColor: palette.line, borderRadius: 11, padding: 12, marginBottom: 14, color: palette.ink, fontSize: 13 },
  faqBodyInput: { minHeight: 126, textAlignVertical: "top" },
  header: {
    minHeight: 76,
    paddingHorizontal: 18,
    paddingVertical: 8,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
    zIndex: 30,
  },
  brandLogoFrame: { width: 150, height: 56, position: "relative" },
  brandLogo: { width: 150, height: 56 },
  brandLogoMarkClip: {
    position: "absolute",
    left: 0,
    top: 0,
    width: 49,
    height: 56,
    overflow: "hidden",
  },
  brandLogoMark: { width: 150, height: 56 },
  headerControls: { flexDirection: "row", alignItems: "center", gap: 7 },
  headerIconButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#F2F7FC",
    borderWidth: 1,
    borderColor: "#DCE8F3",
  },
  languageIconButton: {
    height: 38,
    minWidth: 72,
    borderRadius: 19,
    paddingHorizontal: 9,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
    backgroundColor: palette.sky,
    borderWidth: 1,
    borderColor: "#CDE4F8",
  },
  languageCompact: { color: palette.blue, fontWeight: "900", fontSize: 10 },
  notificationBadge: {
    position: "absolute",
    right: -3,
    top: -4,
    minWidth: 17,
    height: 17,
    paddingHorizontal: 4,
    borderRadius: 9,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: palette.coral,
    borderWidth: 2,
    borderColor: "white",
  },
  notificationBadgeText: { color: "white", fontSize: 8, fontWeight: "900" },
  languageMenu: {
    position: "absolute",
    top: 67,
    right: 18,
    width: 190,
    backgroundColor: "white",
    borderRadius: 15,
    padding: 6,
    shadowColor: "#102A4C",
    shadowOpacity: 0.18,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 7 },
    elevation: 12,
    borderWidth: 1,
    borderColor: palette.line,
    zIndex: 100,
  },
  languageOption: {
    minHeight: 45,
    paddingHorizontal: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    borderRadius: 11,
  },
  languageOptionActive: { backgroundColor: palette.sky },
  languageCode: {
    color: palette.blue,
    fontSize: 10,
    fontWeight: "900",
    width: 26,
  },
  languageName: {
    color: palette.ink,
    fontSize: 13,
    fontWeight: "700",
    flex: 1,
  },
  languageNameActive: { color: palette.navy, fontWeight: "900" },
  headerCompact: { minHeight: 66, paddingHorizontal: 10 },
  brandLogoFrameCompact: { width: 108, height: 45 },
  brandLogoCompact: { width: 108, height: 45 },
  brandLogoMarkClipCompact: { width: 35, height: 45 },
  brandLogoMarkCompact: { width: 108, height: 45 },
  headerControlsCompact: { gap: 5 },
  headerIconButtonCompact: { width: 34, height: 34, borderRadius: 17 },
  languageIconButtonCompact: {
    minWidth: 62,
    height: 34,
    borderRadius: 17,
    paddingHorizontal: 7,
  },
  homeGreetingRow: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  homeEyebrow: {
    color: palette.blue,
    fontSize: 8,
    fontWeight: "900",
    letterSpacing: 1.2,
    marginTop: 2,
  },
  welcome: {
    fontSize: 24,
    fontWeight: "900",
    color: palette.navy,
    marginTop: 4,
  },
  subtitle: {
    fontSize: 12,
    color: palette.muted,
    marginTop: 3,
    marginBottom: 14,
  },
  studentBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: "#ECF9F2",
    borderRadius: 15,
    paddingVertical: 7,
    paddingHorizontal: 9,
    marginTop: 4,
  },
  studentBadgeText: { color: "#28754C", fontSize: 8, fontWeight: "900" },
  search: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F2F6FB",
    borderRadius: 14,
    paddingHorizontal: 13,
    height: 46,
    marginBottom: 16,
  },
  searchInput: { flex: 1, marginLeft: 8, fontSize: 14, color: palette.ink },
  hero: {
    minHeight: 190,
    borderRadius: 22,
    padding: 20,
    flexDirection: "row",
    alignItems: "center",
    overflow: "hidden",
    marginBottom: 14,
  },
  heroCopy: { flex: 1, zIndex: 2 },
  heroKicker: {
    color: "#BFE7FF",
    fontSize: 11,
    fontWeight: "900",
    letterSpacing: 1.5,
  },
  heroTitle: {
    color: "white",
    fontSize: 24,
    lineHeight: 29,
    fontWeight: "900",
    marginVertical: 6,
  },
  heroText: {
    color: "white",
    fontSize: 11,
    lineHeight: 16,
    opacity: 0.9,
    maxWidth: 265,
  },
  heroButton: {
    alignSelf: "flex-start",
    minHeight: 36,
    borderRadius: 18,
    backgroundColor: "white",
    paddingHorizontal: 13,
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginTop: 13,
  },
  heroButtonText: { color: palette.blue, fontSize: 9, fontWeight: "900" },
  heroArt: { position: "absolute", right: -7, bottom: 0 },
  homeStatusRow: { flexDirection: "row", gap: 8, marginBottom: 20 },
  homeStatusCard: {
    flex: 1,
    minHeight: 84,
    borderWidth: 1,
    borderColor: "#DCE5EF",
    borderRadius: 15,
    padding: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "white",
  },
  homeStatusIcon: {
    width: 35,
    height: 35,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  homeStatusLabel: { color: palette.muted, fontSize: 8, fontWeight: "800" },
  homeStatusValue: {
    color: palette.navy,
    fontSize: 9,
    lineHeight: 13,
    fontWeight: "900",
    marginTop: 3,
  },
  serviceGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginHorizontal: -5,
    marginBottom: 9,
  },
  service: {
    width: "50%",
    padding: 5,
    minHeight: 86,
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    borderWidth: 1,
    borderColor: "#E1E8F0",
    borderRadius: 16,
    backgroundColor: "white",
    transform: [{ scale: 0.97 }],
  },
  serviceNarrow: { width: "100%" },
  serviceIcon: {
    width: 43,
    height: 43,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
  },
  serviceLabel: {
    color: palette.navy,
    fontSize: 10,
    lineHeight: 14,
    fontWeight: "900",
  },
  serviceHint: {
    color: palette.muted,
    fontSize: 8,
    lineHeight: 11,
    marginTop: 3,
  },
  serviceZh: { color: palette.muted, fontSize: 10, marginTop: 1 },
  sectionHead: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 8,
    marginBottom: 12,
  },
  sectionTitle: { fontSize: 19, lineHeight: 25, fontWeight: "800", color: palette.navy },
  seeAll: { color: palette.blue, fontWeight: "700" },
  eventCard: {
    backgroundColor: "white",
    borderRadius: 18,
    overflow: "hidden",
    marginBottom: 16,
    shadowColor: "#30517A",
    shadowOpacity: 0.12,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
    elevation: 3,
  },
  eventImage: { height: 132, width: "100%" },
  eventTag: {
    position: "absolute",
    top: 10,
    left: 10,
    backgroundColor: "#6D3EEB",
    borderRadius: 8,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  eventTagText: { color: "white", fontSize: 10, fontWeight: "800" },
  heart: {
    position: "absolute",
    right: 10,
    top: 8,
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(4,24,57,.28)",
  },
  heartFavourite: { backgroundColor: palette.coral },
  eventBody: { padding: 14 },
  eventRecommendation: {
    alignSelf: "flex-start",
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: palette.sky,
    borderRadius: 11,
    paddingVertical: 6,
    paddingHorizontal: 8,
    marginBottom: 9,
  },
  eventRecommendationText: {
    color: palette.blue,
    fontSize: 8,
    fontWeight: "800",
  },
  eventReleaseCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    borderRadius: 12,
    backgroundColor: "#F7FAFD",
    borderWidth: 1,
    borderColor: "#DEE8F1",
    padding: 10,
    marginTop: 11,
  },
  eventReleaseTitle: { color: palette.navy, fontSize: 9, fontWeight: "900" },
  eventReleaseText: { color: palette.muted, fontSize: 8, marginTop: 2 },
  eventReleaseReminder: { color: "#9A680D", fontSize: 8, fontWeight: "900" },
  eventTitleLine: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  eventTitle: {
    flex: 1,
    fontSize: 17,
    fontWeight: "900",
    color: palette.navy,
    marginBottom: 7,
  },
  categoryBadge: {
    backgroundColor: palette.sky,
    color: palette.blue,
    borderRadius: 10,
    paddingVertical: 4,
    paddingHorizontal: 8,
    fontSize: 9,
    fontWeight: "900",
  },
  meta: { flexDirection: "row", alignItems: "center", marginTop: 3 },
  metaText: { marginLeft: 6, fontSize: 12, color: palette.muted },
  people: {
    marginLeft: "auto",
    color: palette.blue,
    fontSize: 11,
    fontWeight: "800",
  },
  price: { fontWeight: "900", color: palette.ink, fontSize: 15 },
  eventFacts: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginTop: 2,
    marginHorizontal: -4,
  },
  eventFact: {
    width: "50%",
    minHeight: 44,
    paddingHorizontal: 4,
    paddingVertical: 5,
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 6,
  },
  eventFactLabel: {
    color: palette.muted,
    fontSize: 8,
    fontWeight: "800",
    textTransform: "uppercase",
  },
  eventFactValue: {
    color: palette.ink,
    fontSize: 10,
    fontWeight: "700",
    marginTop: 2,
  },
  eventFooter: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderTopWidth: 1,
    borderTopColor: palette.line,
    paddingTop: 11,
    marginTop: 5,
  },
  eventCapacity: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: palette.sky,
    borderRadius: 13,
    paddingVertical: 6,
    paddingHorizontal: 9,
  },
  eventCapacitySoldOut: { backgroundColor: "#FFF0F1" },
  eventCapacityText: { color: palette.blue, fontSize: 10, fontWeight: "900" },
  eventCapacityTextSoldOut: { color: palette.coral },
  categoryScroller: { marginHorizontal: -18, marginBottom: 15 },
  slidableCategories: { flexDirection: "row", alignItems: "center" },
  slidableCategoryScroll: { flex: 1 },
  categoryRow: { gap: 8, paddingHorizontal: 18 },
  categoryChip: {
    borderWidth: 1,
    borderColor: "#D8E2EE",
    borderRadius: 18,
    paddingVertical: 9,
    paddingHorizontal: 14,
    backgroundColor: "white",
  },
  categoryChipActive: {
    backgroundColor: palette.blue,
    borderColor: palette.blue,
  },
  categoryChipText: { color: palette.muted, fontSize: 11, fontWeight: "800" },
  categoryChipTextActive: { color: "white" },
  noEvents: { alignItems: "center", paddingVertical: 55 },
  eventDetail: { padding: 18, paddingBottom: 38 },
  detailImage: {
    width: "100%",
    height: 230,
    borderRadius: 20,
    backgroundColor: "#EEF2F6",
  },
  detailCategory: {
    alignSelf: "flex-start",
    backgroundColor: "#6D3EEB",
    borderRadius: 9,
    paddingVertical: 5,
    paddingHorizontal: 10,
    marginTop: -15,
    marginLeft: 12,
  },
  detailTitleRow: { flexDirection: "row", alignItems: "center", marginTop: 14 },
  detailTitle: {
    flex: 1,
    color: palette.navy,
    fontSize: 27,
    lineHeight: 32,
    fontWeight: "900",
  },
  shareButton: {
    width: 43,
    height: 43,
    borderRadius: 22,
    backgroundColor: palette.sky,
    alignItems: "center",
    justifyContent: "center",
  },
  detailSummary: {
    color: palette.muted,
    fontSize: 14,
    lineHeight: 21,
    marginTop: 10,
  },
  detailGrid: {
    backgroundColor: "#F7F9FC",
    borderRadius: 17,
    padding: 14,
    marginTop: 16,
    gap: 13,
  },
  detailReleaseCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: "#CFE2F5",
    backgroundColor: palette.sky,
    padding: 12,
    marginTop: 12,
  },
  detailReleaseIcon: {
    width: 42,
    height: 42,
    borderRadius: 13,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  detailReleaseTitle: { color: palette.navy, fontSize: 10, fontWeight: "900" },
  detailReleaseText: { color: palette.muted, fontSize: 9, marginTop: 3 },
  detailFriendsCard: { borderWidth: 1, borderColor: palette.line, borderRadius: 16, marginTop: 14, overflow: "hidden" },
  detailFriendsHead: { flexDirection: "row", alignItems: "center", gap: 11, padding: 13 },
  detailFriendsIcon: { width: 42, height: 42, borderRadius: 13, backgroundColor: palette.sky, alignItems: "center", justifyContent: "center" },
  detailFriendsList: { borderTopWidth: 1, borderTopColor: palette.line, paddingHorizontal: 13, paddingVertical: 12, gap: 12 },
  detailFriendRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  detailReminderButton: { minHeight: 34, borderRadius: 10, backgroundColor: palette.blue, alignItems: "center", justifyContent: "center", paddingHorizontal: 10 },
  detailReminderText: { color: "white", fontSize: 8, fontWeight: "900" },
  detailItem: { flexDirection: "row", alignItems: "center", gap: 11 },
  detailLabel: {
    color: palette.muted,
    fontSize: 10,
    fontWeight: "800",
    textTransform: "uppercase",
  },
  detailValue: {
    color: palette.ink,
    fontSize: 13,
    fontWeight: "800",
    marginTop: 2,
  },
  locationCard: {
    flexDirection: "row",
    gap: 10,
    alignItems: "center",
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 16,
    padding: 14,
    marginTop: 14,
  },
  mapButton: {
    backgroundColor: palette.blue,
    borderRadius: 12,
    paddingVertical: 9,
    paddingHorizontal: 10,
    flexDirection: "row",
    gap: 5,
    alignItems: "center",
  },
  mapButtonText: { color: "white", fontWeight: "900", fontSize: 10 },
  verifiedNotice: {
    flexDirection: "row",
    gap: 7,
    alignItems: "center",
    marginTop: 13,
  },
  verifiedText: { color: "#197341", fontWeight: "800", fontSize: 11 },
  organiserCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 16,
    padding: 12,
    marginTop: 15,
  },
  organiserLogo: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: palette.navy,
    alignItems: "center",
    justifyContent: "center",
  },
  organiserInitial: { color: "white", fontWeight: "900", fontSize: 20 },
  organiserRating: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginLeft: 6,
    marginTop: 3,
  },
  organiserRatingText: { color: "#8A5B00", fontSize: 9, fontWeight: "800" },
  followOrganiser: {
    backgroundColor: palette.sky,
    borderRadius: 13,
    paddingVertical: 7,
    paddingHorizontal: 11,
  },
  followOrganiserText: { color: palette.blue, fontWeight: "900", fontSize: 10 },
  segment: {
    width: "100%",
    flexDirection: "row",
    backgroundColor: "#EDF3FA",
    borderRadius: 14,
    padding: 4,
    marginBottom: 16,
  },
  segmentItem: {
    flex: 1,
    minHeight: 39,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 11,
    paddingHorizontal: 3,
  },
  segmentActive: { backgroundColor: palette.blue },
  segmentText: { color: palette.muted, fontWeight: "800", fontSize: 11 },
  segmentTextSmall: {
    color: palette.muted,
    fontWeight: "800",
    fontSize: 10,
    textAlign: "center",
  },
  segmentTextActive: { color: "white" },
  chips: { flexDirection: "row", marginBottom: 6 },
  chip: {
    backgroundColor: "#F2F6FB",
    color: palette.muted,
    paddingVertical: 7,
    paddingHorizontal: 11,
    borderRadius: 14,
    fontSize: 11,
    marginRight: 7,
  },
  chipActive: {
    backgroundColor: "#DCEEFF",
    color: palette.blue,
    paddingVertical: 7,
    paddingHorizontal: 11,
    borderRadius: 14,
    fontSize: 11,
    fontWeight: "800",
    marginRight: 7,
  },
  friend: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 27,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },
  avatarText: { color: palette.navy, fontWeight: "900" },
  friendName: { color: palette.navy, fontWeight: "900", fontSize: 15 },
  friendUni: {
    color: palette.blue,
    fontSize: 11,
    fontWeight: "700",
    marginTop: 2,
  },
  friendInterests: { color: palette.muted, fontSize: 11, marginTop: 3 },
  follow: {
    backgroundColor: palette.blue,
    borderRadius: 16,
    paddingVertical: 7,
    paddingHorizontal: 13,
  },
  followText: { color: "white", fontWeight: "800", fontSize: 12 },
  followSent: {
    backgroundColor: palette.sky,
    borderWidth: 1,
    borderColor: "#B6D8F8",
  },
  messageCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: palette.sky,
    alignItems: "center",
    justifyContent: "center",
  },
  friendsTitleRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 13,
  },
  requestBadge: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: palette.sky,
    alignItems: "center",
    justifyContent: "center",
  },
  requestBadgeText: {
    position: "absolute",
    right: -2,
    top: -4,
    color: "white",
    backgroundColor: palette.coral,
    fontSize: 9,
    fontWeight: "900",
    minWidth: 16,
    height: 16,
    borderRadius: 8,
    textAlign: "center",
    lineHeight: 16,
  },
  requestCard: {
    flexDirection: "row",
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
  },
  requestActions: { flexDirection: "row", gap: 8, marginTop: 10 },
  acceptButton: {
    backgroundColor: palette.blue,
    borderRadius: 14,
    paddingVertical: 7,
    paddingHorizontal: 18,
  },
  acceptText: { color: "white", fontWeight: "900", fontSize: 11 },
  declineButton: {
    backgroundColor: "#F2F5F8",
    borderRadius: 14,
    paddingVertical: 7,
    paddingHorizontal: 18,
  },
  declineText: { color: palette.muted, fontWeight: "900", fontSize: 11 },
  friendProfile: { padding: 18, paddingBottom: 40 },
  backLink: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginBottom: 12,
  },
  backText: { color: palette.blue, fontWeight: "800" },
  friendProfileHero: { alignItems: "center", paddingVertical: 8 },
  friendAvatarBadgeWrap: { width: 96, height: 96, position: "relative" },
  largeAvatar: { width: 96, height: 96, borderRadius: 48, marginRight: 0 },
  largeAvatarText: { color: palette.navy, fontWeight: "900", fontSize: 28 },
  friendProfileName: {
    color: palette.navy,
    fontSize: 24,
    fontWeight: "900",
    marginTop: 11,
  },
  friendProfileStats: { alignSelf: "stretch", flexDirection: "row", marginTop: 17, borderWidth: 1, borderColor: "#DEE7F0", borderRadius: 15, backgroundColor: "#FFFFFF" },
  friendProfileStat: { flex: 1, alignItems: "center", justifyContent: "center", minHeight: 60 },
  privacyPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: "#ECF9F2",
    borderRadius: 12,
    padding: 10,
    marginTop: 12,
    maxWidth: 350,
  },
  privacyText: {
    color: "#197341",
    fontSize: 10,
    lineHeight: 15,
    flex: 1,
    fontWeight: "700",
  },
  friendSectionTitle: {
    color: palette.navy,
    fontSize: 16,
    fontWeight: "900",
    marginTop: 19,
    marginBottom: 9,
  },
  promptCard: { backgroundColor: "#F7F2FF", borderRadius: 16, padding: 16 },
  prompt: {
    color: "#7542C8",
    fontSize: 11,
    fontWeight: "900",
    textTransform: "uppercase",
  },
  answer: {
    color: palette.ink,
    fontSize: 17,
    lineHeight: 24,
    fontWeight: "700",
    marginTop: 7,
  },
  interestWrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 7,
    marginTop: 13,
  },
  interestChip: {
    backgroundColor: palette.sky,
    borderRadius: 15,
    paddingVertical: 7,
    paddingHorizontal: 11,
  },
  interestText: { color: palette.blue, fontWeight: "800", fontSize: 11 },
  socialRow: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  socialLocked: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 12,
    paddingVertical: 8,
    paddingHorizontal: 11,
  },
  socialName: { color: palette.ink, fontSize: 11, fontWeight: "800" },
  privateNote: {
    color: palette.muted,
    fontSize: 10,
    lineHeight: 15,
    marginTop: 8,
  },
  pageTitle: {
    fontSize: 24,
    lineHeight: 30,
    fontWeight: "800",
    color: palette.navy,
    marginBottom: 10,
  },
  actionRow: { marginBottom: 15 },
  createEvent: {
    backgroundColor: palette.coral,
    borderRadius: 14,
    minHeight: 48,
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  createText: { color: "white", fontWeight: "900" },
  formCard: {
    borderRadius: 18,
    backgroundColor: "white",
    padding: 16,
    borderWidth: 1,
    borderColor: palette.line,
  },
  formHero: {
    flexDirection: "row",
    gap: 12,
    alignItems: "center",
    paddingBottom: 14,
    marginBottom: 5,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
  },
  formHeroIcon: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: palette.sky,
    alignItems: "center",
    justifyContent: "center",
  },
  formTitle: { color: palette.navy, fontSize: 20, lineHeight: 26, fontWeight: "800" },
  formDesc: {
    color: palette.muted,
    fontSize: 13,
    marginTop: 3,
    lineHeight: 20,
  },
  field: {
    borderWidth: 1,
    borderColor: "#D7E1ED",
    borderRadius: 11,
    paddingHorizontal: 12,
    paddingVertical: 9,
    marginTop: 12,
    minHeight: 56,
  },
  fieldLabel: {
    color: palette.navy,
    fontWeight: "800",
    fontSize: 11,
    marginBottom: 5,
  },
  authFieldLabel: { color: palette.navy, fontWeight: "800", fontSize: 13, lineHeight: 18, marginBottom: 7 },
  authRoleDetail: { marginBottom: 18 },
  authRoleChoices: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  authRoleChoice: { flexGrow: 1, minHeight: 46, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, borderWidth: 1, borderColor: "#D3E2F3", borderRadius: 11, backgroundColor: "#FFFFFF", paddingHorizontal: 9 },
  authRoleChoiceActive: { borderColor: palette.blue, backgroundColor: "#EAF4FF" },
  authRoleChoiceText: { color: palette.navy, fontSize: 11, fontWeight: "800" },
  authInput: { minHeight: 50, borderWidth: 1, borderColor: "#C7D7E8", borderRadius: 12, paddingHorizontal: 14, color: palette.ink, fontSize: 15, lineHeight: 21 },
  authSupportButton: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 22, padding: 14, borderWidth: 1, borderColor: "#D5E5F5", borderRadius: 13, backgroundColor: "#F4F8FD" },
  authSupportTitle: { color: palette.navy, fontSize: 12, fontWeight: "800" },
  authSupportDetail: { color: palette.blue, fontSize: 11, fontWeight: "700", marginTop: 3 },
  authSupportNote: { color: palette.muted, fontSize: 10, lineHeight: 15, marginTop: 7, textAlign: "center" },
  authSupportHeader: { minHeight: 54, flexDirection: "row", alignItems: "center", paddingHorizontal: 18, borderBottomWidth: 1, borderBottomColor: palette.line },
  authSupportBack: { flexDirection: "row", alignItems: "center", gap: 5, paddingVertical: 10, minWidth: 85 },
  authSupportBackText: { color: palette.blue, fontSize: 12, fontWeight: "800" },
  authSupportHeaderTitle: { color: palette.navy, fontSize: 16, fontWeight: "900" },
  authSupportBody: { padding: 18, flexGrow: 1, gap: 14 },
  authSupportIntro: { flexDirection: "row", gap: 11, alignItems: "flex-start", padding: 15, borderRadius: 14, backgroundColor: "#F4F8FD" },
  authSupportIntroTitle: { color: palette.navy, fontSize: 14, fontWeight: "900" },
  authSupportIntroText: { color: palette.muted, fontSize: 11, lineHeight: 17, marginTop: 4 },
  authSupportDemoNotice: { flexDirection: "row", alignItems: "flex-start", gap: 8, padding: 11, borderRadius: 11, backgroundColor: "#EAF4FF" },
  authSupportDemoText: { flex: 1, color: palette.navy, fontSize: 10, lineHeight: 15 },
  authSupportBubble: { alignSelf: "flex-start", maxWidth: "88%", padding: 13, borderRadius: 14, backgroundColor: "#F1F5FA" },
  authSupportBubbleText: { color: palette.ink, fontSize: 12, lineHeight: 19 },
  authSupportOwnBubble: { alignSelf: "flex-end", maxWidth: "85%", padding: 13, borderRadius: 14, backgroundColor: palette.blue },
  authSupportOwnText: { color: "#FFFFFF", fontSize: 12, lineHeight: 19 },
  authSupportLocalNote: { alignSelf: "flex-end", color: palette.muted, fontSize: 10 },
  authSupportComposer: { flexDirection: "row", alignItems: "center", gap: 9, padding: 12, borderTopWidth: 1, borderTopColor: palette.line },
  authSupportInput: { flex: 1, minHeight: 42, maxHeight: 100, borderWidth: 1, borderColor: "#C7D7E8", borderRadius: 12, paddingHorizontal: 12, paddingVertical: 9, color: palette.ink, fontSize: 12 },
  authSupportSend: { width: 42, height: 42, borderRadius: 12, backgroundColor: palette.blue, alignItems: "center", justifyContent: "center" },
  workspaceHeading: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 18, paddingTop: 19, paddingBottom: 14 },
  workspaceEyebrow: { color: palette.blue, fontSize: 9, fontWeight: "900", letterSpacing: 1.1, marginBottom: 5 },
  workspaceTitle: { color: palette.navy, fontSize: 23, fontWeight: "900" },
  workspaceSubtitle: { color: palette.muted, fontSize: 11, lineHeight: 17, marginTop: 3 },
  workspaceTabs: { flexDirection: "row", gap: 4, marginHorizontal: 8, marginTop: 5, marginBottom: 7, padding: 4, borderRadius: 14, backgroundColor: "#EDF4FB" },
  workspaceTab: { flex: 1, minHeight: 52, borderRadius: 10, alignItems: "center", justifyContent: "center", gap: 3, paddingHorizontal: 2 },
  workspaceTabActive: { backgroundColor: palette.blue },
  workspaceTabText: { color: palette.muted, fontSize: 9, fontWeight: "800", textAlign: "center" },
  workspaceTabTextActive: { color: "#FFFFFF" },
  workspaceContactInitials: { fontSize: 14, fontWeight: "900" },
  restaurantCover: { width: "100%", height: 150, borderRadius: 14, backgroundColor: "#E5EDF7" },
  restaurantPublicCover: { width: "100%", height: 180, borderRadius: 14, backgroundColor: "#E5EDF7" },
  restaurantMenuImage: { width: "100%", height: 260, marginTop: 8, borderRadius: 10, backgroundColor: "#F4F7FB" },
  workspaceBody: { padding: 18, paddingBottom: 40, gap: 11 },
  workspaceMetricRow: { flexDirection: "row", gap: 8 },
  workspaceMetric: { flex: 1, minHeight: 70, alignItems: "center", justifyContent: "center", borderRadius: 13, backgroundColor: "#F2F7FC" },
  workspaceMetricValue: { color: palette.navy, fontSize: 19, fontWeight: "900" },
  workspaceMetricLabel: { color: palette.muted, fontSize: 9, fontWeight: "800", marginTop: 2, textAlign: "center" },
  workspaceSectionTitle: { color: palette.navy, fontSize: 17, fontWeight: "900", marginTop: 6 },
  workspaceSectionHead: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
  workspaceHint: { color: palette.muted, fontSize: 10, lineHeight: 16 },
  workspaceCard: { borderWidth: 1, borderColor: "#D5E2F2", borderRadius: 15, padding: 14, backgroundColor: "#FFFFFF", gap: 5 },
  workspaceCardTop: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", gap: 8 },
  workspaceCardTitle: { color: palette.navy, fontSize: 13, fontWeight: "900", flexShrink: 1 },
  workspaceCardText: { color: palette.muted, fontSize: 11, lineHeight: 17 },
  workspaceCardLink: { color: palette.blue, fontSize: 10, fontWeight: "900", marginTop: 5 },
  workspaceStatus: { color: "#17774A", backgroundColor: "#E8F8EF", borderRadius: 10, overflow: "hidden", paddingHorizontal: 8, paddingVertical: 4, fontSize: 9, fontWeight: "900" },
  workspaceNotice: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 12, backgroundColor: "#EAF4FF", padding: 12 },
  workspaceNoticeText: { color: palette.navy, flex: 1, fontSize: 10, lineHeight: 16 },
  workspaceScheduleRow: { flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderColor: "#D5E2F2", borderRadius: 13, padding: 12, backgroundColor: "#FFFFFF" },
  workspaceScheduleDate: { width: 38, height: 38, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: "#EAF4FF" },
  workspaceBack: { flexDirection: "row", alignItems: "center", gap: 5, alignSelf: "flex-start", paddingVertical: 5 },
  workspaceBackText: { color: palette.blue, fontSize: 11, fontWeight: "800" },
  workspaceComposer: { flexDirection: "row", alignItems: "center", gap: 8 },
  workspaceInput: { minHeight: 44, flexGrow: 1, borderWidth: 1, borderColor: "#C7D7E8", borderRadius: 11, paddingHorizontal: 11, paddingVertical: 9, backgroundColor: "#FFFFFF", color: palette.ink, fontSize: 12 },
  workspaceSend: { width: 42, height: 42, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: palette.blue },
  workspaceLocalMessage: { alignSelf: "flex-end", color: "#FFFFFF", backgroundColor: palette.blue, borderRadius: 10, overflow: "hidden", padding: 9, fontSize: 11, marginTop: 5 },
  workspaceProfileHero: { alignItems: "center", paddingVertical: 11, gap: 5 },
  workspaceAvatarWrap: { width: 90, height: 90, position: "relative" },
  workspaceAvatar: { width: 88, height: 88, borderRadius: 44, alignItems: "center", justifyContent: "center", backgroundColor: "#DCEBFF" },
  workspaceAvatarText: { color: palette.navy, fontSize: 26, fontWeight: "900" },
  workspaceProfileName: { color: palette.navy, fontSize: 22, fontWeight: "900", marginTop: 6 },
  workspaceApprovedPill: { flexDirection: "row", alignItems: "center", gap: 5, borderRadius: 12, paddingVertical: 6, paddingHorizontal: 10, backgroundColor: palette.blue, marginTop: 5 },
  workspaceApprovedText: { color: "#FFFFFF", fontSize: 10, fontWeight: "900" },
  workspaceOfficialPill: { flexDirection: "row", alignItems: "center", gap: 5, borderRadius: 12, paddingVertical: 6, paddingHorizontal: 10, backgroundColor: "#F3C44F", marginTop: 5 },
  workspaceOfficialText: { color: "#17213A", fontSize: 10, fontWeight: "900" },
  workspaceLogout: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, minHeight: 46, borderWidth: 1, borderColor: "#C9DCF2", borderRadius: 12, marginTop: 5 },
  workspaceLogoutText: { color: palette.blue, fontSize: 12, fontWeight: "900" },
  workspaceDetailRow: { borderBottomWidth: 1, borderBottomColor: palette.line, paddingVertical: 11, gap: 3 },
  workspaceDetailLabel: { color: palette.muted, fontSize: 9, fontWeight: "900", textTransform: "uppercase" },
  workspaceDetailValue: { color: palette.navy, fontSize: 12, fontWeight: "700" },
  workspaceSmallAction: { flexDirection: "row", alignItems: "center", gap: 4, borderRadius: 10, backgroundColor: palette.blue, paddingHorizontal: 10, minHeight: 34 },
  workspaceSmallActionText: { color: "#FFFFFF", fontSize: 10, fontWeight: "900" },
  workspaceForm: { borderWidth: 1, borderColor: "#C9DCF2", borderRadius: 14, padding: 13, backgroundColor: "#F6FAFE", gap: 9 },
  workspaceFormRow: { flexDirection: "row", gap: 8 },
  workspaceError: { color: palette.coral, fontSize: 10, lineHeight: 15 },
  workspaceReviewStars: { color: "#E99A18", fontSize: 14, fontWeight: "900" },
  workspaceOwnerReply: { borderLeftWidth: 3, borderLeftColor: palette.blue, backgroundColor: "#F2F7FC", padding: 10, marginTop: 7, borderRadius: 7 },
  workspaceInlineAction: { alignSelf: "flex-start", paddingVertical: 7 },
  fieldHint: {
    color: palette.muted,
    fontSize: 9,
    lineHeight: 14,
    marginTop: 5,
  },
  selectWrap: { marginTop: 12 },
  scheduleSelectWrap: { marginTop: 8 },
  selectField: {
    minHeight: 50,
    borderWidth: 1,
    borderColor: "#D7E1ED",
    borderRadius: 11,
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "white",
  },
  selectFieldOpen: {
    borderColor: palette.blue,
    borderBottomLeftRadius: 5,
    borderBottomRightRadius: 5,
  },
  scheduleSelectField: { minHeight: 62, borderRadius: 13, paddingHorizontal: 11, gap: 10 },
  selectValue: { flex: 1, color: palette.ink, fontSize: 12, fontWeight: "700" },
  selectMenu: {
    borderWidth: 1,
    borderColor: "#C9D8E8",
    borderTopWidth: 0,
    borderBottomLeftRadius: 11,
    borderBottomRightRadius: 11,
    overflow: "hidden",
    backgroundColor: "white",
  },
  selectMenuScroll: { maxHeight: 220 },
  selectOption: {
    minHeight: 43,
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    borderTopWidth: 1,
    borderTopColor: "#EDF1F5",
  },
  selectOptionActive: { backgroundColor: palette.sky },
  selectOptionText: { flex: 1, color: palette.ink, fontSize: 11 },
  selectOptionTextActive: { color: palette.blue, fontWeight: "900" },
  transferSegment: {
    flexDirection: "row",
    gap: 7,
    backgroundColor: "#EDF3FA",
    borderRadius: 14,
    padding: 4,
    marginTop: 13,
  },
  transferSegmentItem: {
    flex: 1,
    minHeight: 45,
    borderRadius: 11,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingHorizontal: 5,
  },
  transferSegmentActive: { backgroundColor: palette.blue },
  transferSegmentText: {
    color: palette.navy,
    fontSize: 11,
    textAlign: "center",
    fontWeight: "800",
  },
  transferSegmentTextActive: { color: "white" },
  formTwoColumns: { flexDirection: "row", gap: 9 },
  formColumnsCompact: { flexDirection: "column", gap: 0 },
  formHalf: { flex: 1, minWidth: 0 },
  capacityNote: {
    flexDirection: "row",
    gap: 9,
    alignItems: "center",
    padding: 11,
    backgroundColor: palette.sky,
    borderRadius: 12,
    marginTop: 13,
  },
  capacityNoteText: {
    flex: 1,
    color: palette.navy,
    fontSize: 10,
    lineHeight: 15,
    fontWeight: "600",
  },
  formSectionTitle: {
    color: palette.navy,
    fontSize: 13,
    fontWeight: "900",
    marginTop: 18,
    marginBottom: 8,
  },
  timeTitleRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 18,
    marginBottom: 8,
  },
  timeTitleRowLabel: { marginTop: 0, marginBottom: 0 },
  selectedTimePill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 9,
    minHeight: 28,
    borderRadius: 14,
    backgroundColor: palette.sky,
  },
  selectedTimeText: { color: palette.blue, fontSize: 11, fontWeight: "900" },
  meetingOptions: { gap: 8 },
  meetingOption: {
    minHeight: 50,
    borderWidth: 1,
    borderColor: "#D7E1ED",
    borderRadius: 12,
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
  },
  meetingOptionActive: {
    borderColor: palette.blue,
    backgroundColor: "#F4FAFF",
  },
  meetingOptionText: {
    flex: 1,
    color: palette.muted,
    fontSize: 11,
    fontWeight: "700",
  },
  meetingOptionTextActive: { color: palette.navy, fontWeight: "900" },
  assistanceRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 12,
    borderRadius: 12,
    backgroundColor: "#F8FAFC",
    marginTop: 10,
  },
  checkbox: {
    width: 23,
    height: 23,
    borderRadius: 7,
    borderWidth: 1.5,
    borderColor: "#B8C6D6",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "white",
  },
  checkboxActive: {
    backgroundColor: palette.green,
    borderColor: palette.green,
  },
  assistanceTitle: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  assistanceText: {
    color: palette.muted,
    fontSize: 9,
    lineHeight: 14,
    marginTop: 2,
  },
  fareCard: {
    marginTop: 18,
    borderWidth: 1,
    borderColor: "#CFE2F5",
    borderRadius: 17,
    overflow: "hidden",
    backgroundColor: "#FBFDFF",
  },
  fareHead: {
    padding: 14,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
  },
  eligiblePill: {
    alignSelf: "flex-start",
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: "#E9F8F0",
    borderRadius: 12,
    paddingVertical: 6,
    paddingHorizontal: 9,
    marginTop: 8,
  },
  eligibleText: { color: "#197341", fontSize: 9, fontWeight: "800" },
  fareLine: {
    minHeight: 39,
    paddingHorizontal: 14,
    flexDirection: "row",
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: "#EEF2F6",
  },
  fareLineLabel: { flex: 1, color: palette.muted, fontSize: 11 },
  fareLineValue: { color: palette.ink, fontWeight: "800", fontSize: 11 },
  fareTotal: {
    minHeight: 54,
    paddingHorizontal: 14,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: palette.sky,
  },
  fareTotalLabel: {
    flex: 1,
    color: palette.navy,
    fontWeight: "900",
    fontSize: 13,
  },
  fareTotalValue: { color: palette.blue, fontWeight: "900", fontSize: 20 },
  depositRow: {
    minHeight: 67,
    paddingHorizontal: 14,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: palette.navy,
  },
  depositLabel: { color: "white", fontWeight: "900", fontSize: 12 },
  balanceText: { color: "#B9D3EF", fontSize: 9, marginTop: 4 },
  depositValue: {
    marginLeft: "auto",
    color: "white",
    fontWeight: "900",
    fontSize: 20,
  },
  currencyRow: { flexDirection: "row", gap: 8 },
  currencyButton: {
    flex: 1,
    minHeight: 42,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 11,
    borderWidth: 1,
    borderColor: "#D5E0EB",
  },
  currencyButtonActive: {
    backgroundColor: palette.blue,
    borderColor: palette.blue,
  },
  currencyButtonText: { color: palette.muted, fontWeight: "900", fontSize: 11 },
  currencyButtonTextActive: { color: "white" },
  paymentGrid: { flexDirection: "row", flexWrap: "wrap", marginHorizontal: -4 },
  paymentMethod: {
    width: "50%",
    minHeight: 52,
    borderWidth: 1,
    borderColor: "#D5E0EB",
    borderRadius: 12,
    margin: 0,
    paddingHorizontal: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    transform: [{ scale: 0.97 }],
  },
  paymentMethodActive: {
    borderColor: palette.blue,
    backgroundColor: "#F2F8FE",
  },
  paymentMethodText: { color: palette.muted, fontSize: 11, fontWeight: "800" },
  paymentMethodTextActive: { color: palette.navy },
  cardFields: { marginTop: 2 },
  addressSearchWrap: { marginTop: 12 },
  addressSearchField: { minHeight: 50, borderWidth: 1, borderColor: "#D5E0EB", borderRadius: 12, paddingHorizontal: 12, flexDirection: "row", alignItems: "center", gap: 9, backgroundColor: "white" },
  addressSearchInput: { flex: 1, minWidth: 0, color: palette.ink, fontSize: 12, fontWeight: "700", outlineStyle: "none" } as any,
  addressSuggestions: { borderWidth: 1, borderColor: "#D5E0EB", borderRadius: 12, marginTop: 6, overflow: "hidden", backgroundColor: "white" },
  airportAddressSuggestion: { minHeight: 44, flexDirection: "row", alignItems: "center", gap: 9, paddingHorizontal: 12, borderBottomWidth: 1, borderBottomColor: palette.line },
  addressSuggestionText: { flex: 1, color: palette.ink, fontSize: 11, fontWeight: "700" },
  addressSearchMeta: { color: palette.muted, fontSize: 9, lineHeight: 14, paddingHorizontal: 12, paddingVertical: 8 },
  secureNote: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "#F3F7FB",
    borderRadius: 12,
    padding: 11,
    marginTop: 13,
  },
  secureNoteText: {
    flex: 1,
    color: palette.muted,
    fontSize: 9,
    lineHeight: 14,
  },
  primaryButton: {
    backgroundColor: palette.blue,
    minHeight: 51,
    borderRadius: 13,
    flexDirection: "row",
    gap: 7,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 18,
    paddingHorizontal: 24,
  },
  primaryButtonText: { color: "white", fontWeight: "900", fontSize: 15 },
  empty: {
    padding: 24,
    justifyContent: "flex-start",
    alignItems: "center",
  },
  emptyIcon: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: palette.sky,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 20,
  },
  emptyTitle: {
    color: palette.navy,
    fontSize: 22,
    fontWeight: "900",
    textAlign: "center",
  },
  emptyText: {
    color: palette.muted,
    lineHeight: 21,
    textAlign: "center",
    marginTop: 9,
    maxWidth: 320,
  },
  profileTop: { alignItems: "center", paddingVertical: 18 },
  profileAvatar: {
    width: 82,
    height: 82,
    borderRadius: 41,
    backgroundColor: "#DCEEFF",
    marginRight: 0,
  },
  profileInitial: { color: palette.blue, fontSize: 31, fontWeight: "900" },
  profileName: {
    color: palette.muted,
    fontSize: 13,
    fontWeight: "700",
    marginTop: 3,
  },
  profileUni: { color: palette.muted, marginTop: 4 },
  linkedIcons: { flexDirection: "row", gap: 5, marginTop: 10 },
  linkedIcon: {
    width: 27,
    height: 27,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  profileTags: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
    marginTop: 12,
  },
  profileTag: {
    backgroundColor: palette.sky,
    color: palette.blue,
    marginHorizontal: 3,
    marginBottom: 6,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 13,
    fontSize: 11,
    fontWeight: "700",
  },
  profileMenuCard: {
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 17,
    paddingHorizontal: 14,
    overflow: "hidden",
  },
  paymentSettingsBody: { padding: 18, paddingBottom: 42 },
  paymentEmptyCard: { alignItems: "center", justifyContent: "center", gap: 5, borderWidth: 1, borderColor: palette.line, borderRadius: 14, padding: 22, backgroundColor: "#F8FBFE" },
  savedMethodCard: { flexDirection: "row", alignItems: "center", flexWrap: "wrap", gap: 9, borderWidth: 1, borderColor: palette.line, borderRadius: 14, padding: 12, marginBottom: 9 },
  savedMethodIcon: { width: 39, height: 39, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: palette.sky },
  savedMethodTitle: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  savedMethodDefaultBadge: { backgroundColor: "#EAF8F0", borderRadius: 10, paddingHorizontal: 8, paddingVertical: 5 },
  savedMethodDefaultText: { color: palette.green, fontSize: 9, fontWeight: "900" },
  savedMethodActions: { width: "100%", flexDirection: "row", justifyContent: "flex-end", gap: 18, borderTopWidth: 1, borderTopColor: palette.line, paddingTop: 8 },
  savedMethodActionText: { color: palette.blue, fontSize: 10, fontWeight: "800" },
  savedMethodRemoveText: { color: palette.coral, fontSize: 10, fontWeight: "800" },
  paymentAddButton: { minHeight: 49, borderRadius: 12, borderWidth: 1, borderColor: "#BCD8F4", backgroundColor: palette.sky, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 13 },
  paymentAddButtonText: { color: palette.blue, fontSize: 11, fontWeight: "900" },
  paymentAddCard: { borderWidth: 1, borderColor: palette.line, borderRadius: 14, padding: 13, marginTop: 13 },
  paymentDefaultToggle: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 14 },
  privacySheetBody: { padding: 18, paddingBottom: 44 },
  privacyIntro: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 9,
    backgroundColor: "#ECF9F2",
    borderRadius: 14,
    padding: 12,
    marginBottom: 13,
  },
  privacyIntroText: { flex: 1, color: "#397653", fontSize: 9, lineHeight: 14 },
  profilePrivacyCard: {
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 17,
    padding: 14,
    marginBottom: 12,
    backgroundColor: "white",
  },
  profilePrivacyHead: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginBottom: 8,
  },
  socialSetting: {
    minHeight: 43,
    flexDirection: "row",
    alignItems: "center",
    borderTopWidth: 1,
    borderTopColor: palette.line,
  },
  socialEditor: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderTopWidth: 1,
    borderTopColor: palette.line,
    paddingVertical: 11,
  },
  socialLogo: {
    width: 36,
    height: 36,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
  },
  socialEditorName: { color: palette.ink, fontWeight: "900", fontSize: 12 },
  socialInput: {
    color: palette.ink,
    paddingVertical: 4,
    fontSize: 11,
    borderBottomWidth: 1,
    borderBottomColor: "#D9E1EB",
  },
  visibilityButton: {
    width: 38,
    height: 30,
    borderRadius: 15,
    backgroundColor: "#E7ECF2",
    alignItems: "center",
    justifyContent: "center",
  },
  visibilityOn: { backgroundColor: palette.blue },
  privateModeText: {
    color: palette.muted,
    fontSize: 11,
    lineHeight: 17,
    marginTop: 3,
  },
  toggle: {
    width: 39,
    height: 23,
    borderRadius: 12,
    padding: 2,
    backgroundColor: "#CAD3DF",
  },
  toggleOn: { backgroundColor: palette.green },
  toggleKnob: {
    width: 19,
    height: 19,
    borderRadius: 10,
    backgroundColor: "white",
  },
  toggleKnobOn: { marginLeft: 16 },
  menuItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    minHeight: 57,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
  },
  menuText: { color: palette.ink, fontWeight: "700", flex: 1 },
  tabBar: {
    minHeight: 66,
    borderTopWidth: 1,
    borderTopColor: palette.line,
    flexDirection: "row",
    backgroundColor: "white",
    paddingBottom: Platform.OS === "android" ? 4 : 5,
  },
  tab: {
    flex: 1,
    minWidth: 0,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 2,
  },
  tabText: {
    color: palette.muted,
    fontSize: 9,
    lineHeight: 12,
    marginTop: 3,
    textAlign: "center",
  },
  tabTextActive: { color: palette.blue, fontWeight: "800" },
  modal: {
    flex: 1,
    width: "100%",
    maxWidth: 430,
    alignSelf: "center",
    backgroundColor: "white",
  },
  modalHead: {
    height: 62,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 18,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
  },
  modalTitle: { color: palette.navy, fontSize: 18, lineHeight: 24, fontWeight: "800", flex: 1, textAlign: "center", paddingHorizontal: 12 },
  modalBody: { padding: 20, paddingBottom: 24 },
  notice: {
    backgroundColor: palette.sky,
    borderRadius: 14,
    padding: 14,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  noticeText: {
    color: palette.navy,
    fontSize: 12,
    lineHeight: 17,
    flex: 1,
    fontWeight: "600",
  },
  formSectionLabel: {
    color: palette.muted,
    fontWeight: "900",
    fontSize: 10,
    letterSpacing: 1,
    marginTop: 18,
    marginBottom: 10,
  },
  photoPicker: {
    minHeight: 178,
    borderWidth: 1.5,
    borderStyle: "dashed",
    borderColor: "#AFCDEB",
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 16,
    padding: 20,
    overflow: "hidden",
    backgroundColor: "#F7FBFF",
  },
  photoIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: palette.sky,
    alignItems: "center",
    justifyContent: "center",
  },
  photoTitle: { color: palette.navy, fontWeight: "900", marginTop: 8 },
  photoHint: { color: palette.muted, fontSize: 10, marginTop: 3 },
  photoPreview: { width: "100%", height: 180 },
  eventCategoryRail: {
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    marginBottom: 2,
  },
  eventCategoryScroller: { flex: 1 },
  eventCategoryArrow: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: palette.sky,
    borderWidth: 1,
    borderColor: "#CFE3F8",
  },
  photoSourceActions: {
    width: "100%",
    flexDirection: "row",
    gap: 9,
    marginTop: 10,
  },
  photoSourceActionsCompact: {
    flexDirection: "column",
    gap: 6,
    paddingHorizontal: 8,
  },
  photoSourceButton: {
    flex: 1,
    minHeight: 46,
    borderRadius: 13,
    borderWidth: 1,
    borderColor: "#BFD8F0",
    backgroundColor: "white",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
  },
  photoSourceButtonCompact: {
    flex: 0,
    width: "100%",
    minHeight: 34,
    borderRadius: 10,
  },
  photoSourceText: { color: palette.blue, fontSize: 10, fontWeight: "900" },
  currencyInputRow: { flexDirection: "row", alignItems: "center", gap: 4, minHeight: 27 },
  currencyPrefix: { color: palette.ink, fontSize: 15, lineHeight: 20, fontWeight: "800" },
  currencyInput: { flex: 1, height: 27, color: palette.ink, fontSize: 15, lineHeight: 20, paddingVertical: 0, textAlignVertical: "center" },
  eventPaymentPage: { padding: 20, paddingBottom: 44 },
  paymentBack: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 18 },
  paymentBackText: { color: palette.blue, fontSize: 11, fontWeight: "900" },
  eventPaymentHero: { alignItems: "center", marginBottom: 18 },
  eventPaymentLock: { width: 48, height: 48, borderRadius: 24, backgroundColor: palette.sky, alignItems: "center", justifyContent: "center" },
  eventPaymentTitle: { color: palette.navy, fontSize: 22, fontWeight: "900", marginTop: 11 },
  eventPaymentSubtitle: { maxWidth: 390, color: palette.muted, fontSize: 11, lineHeight: 17, textAlign: "center", marginTop: 6 },
  eventPaymentSummary: { borderRadius: 15, borderWidth: 1, borderColor: "#D8E5F1", backgroundColor: "#F8FBFF", padding: 15, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  servicePaymentSummary: { borderRadius: 15, borderWidth: 1, borderColor: "#D8E5F1", backgroundColor: "#F8FBFF", padding: 15, gap: 8, marginBottom: 17 },
  servicePaymentDetail: { color: palette.muted, fontSize: 11, lineHeight: 17 },
  servicePaymentLine: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10, paddingTop: 8 },
  eventPaymentSummaryLabel: { color: palette.navy, fontSize: 13, fontWeight: "900" },
  eventPaymentSummaryMeta: { color: palette.muted, fontSize: 9, marginTop: 3 },
  eventPaymentAmount: { color: palette.navy, fontSize: 20, fontWeight: "900" },
  eventPaymentMethods: { gap: 8, marginTop: 9 },
  eventPaymentMethod: { minHeight: 56, borderWidth: 1, borderColor: "#D6E1ED", borderRadius: 14, paddingHorizontal: 12, flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: "white" },
  eventPaymentMethodActive: { borderColor: palette.blue, backgroundColor: "#F3F9FF" },
  eventPaymentMethodIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: palette.sky, alignItems: "center", justifyContent: "center" },
  eventPaymentMethodText: { flex: 1, color: palette.muted, fontSize: 12, fontWeight: "800" },
  eventPaymentMethodTextActive: { color: palette.navy, fontWeight: "900" },
  eventCardPaymentForm: { marginTop: 13, borderRadius: 15, borderWidth: 1, borderColor: "#D8E5F1", padding: 13, gap: 7 },
  eventPaymentInput: { minHeight: 46, borderWidth: 1, borderColor: "#D6E1ED", borderRadius: 11, paddingHorizontal: 12, color: palette.ink, marginTop: 5 },
  eventPaymentInputRow: { flexDirection: "row", gap: 10 },
  eventPaymentSecure: { flexDirection: "row", alignItems: "flex-start", gap: 8, padding: 12, borderRadius: 13, backgroundColor: "#ECF9F2", marginTop: 14 },
  eventPaymentSecureText: { flex: 1, color: "#347253", fontSize: 9, lineHeight: 14 },
  organiserIdentity: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderWidth: 1,
    borderColor: "#CFE3F8",
    borderRadius: 15,
    padding: 12,
    marginTop: 13,
    backgroundColor: "#F8FBFF",
  },
  organiserAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: palette.navy,
    alignItems: "center",
    justifyContent: "center",
  },
  organiserLabel: {
    color: palette.muted,
    fontSize: 8,
    fontWeight: "900",
    letterSpacing: 0.5,
  },
  organiserName: {
    color: palette.navy,
    fontSize: 13,
    fontWeight: "900",
    marginTop: 2,
  },
  organiserPrivacy: {
    color: palette.muted,
    fontSize: 9,
    lineHeight: 13,
    marginTop: 3,
  },
  staffEventNote: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    borderRadius: 12,
    backgroundColor: palette.sky,
    padding: 11,
    marginTop: 10,
  },
  staffEventNoteText: {
    flex: 1,
    color: palette.navy,
    fontSize: 9,
    lineHeight: 14,
  },
  mapHint: {
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
    backgroundColor: "#F2F7FC",
    borderRadius: 12,
    padding: 12,
    marginTop: 13,
  },
  approvalSteps: {
    alignSelf: "stretch",
    backgroundColor: "#F6F9FC",
    borderRadius: 14,
    padding: 14,
    marginTop: 18,
    gap: 9,
  },
  approvalStep: { color: palette.ink, fontWeight: "700", fontSize: 12 },
  ticketBody: { padding: 18, paddingBottom: 120, backgroundColor: "#F4F6F8" },
  ticketEvent: {
    flexDirection: "row",
    gap: 12,
    alignItems: "center",
    padding: 12,
    backgroundColor: "white",
    borderRadius: 15,
    marginBottom: 14,
  },
  ticketThumb: { width: 105, height: 68, borderRadius: 10 },
  ticketTier: {
    backgroundColor: "white",
    borderRadius: 15,
    marginBottom: 13,
    overflow: "hidden",
  },
  ticketTierTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 16,
  },
  ticketTierName: { color: palette.ink, fontWeight: "900", fontSize: 16 },
  ticketTierPrice: {
    color: palette.ink,
    fontWeight: "900",
    fontSize: 16,
    textAlign: "right",
  },
  ticketFee: { color: palette.muted, fontSize: 10, marginTop: 3 },
  quantityRow: {
    flexDirection: "row",
    gap: 8,
    borderTopWidth: 1,
    borderTopColor: palette.line,
    padding: 13,
    justifyContent: "flex-end",
  },
  quantityButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    borderWidth: 1,
    borderColor: "#D7DEE7",
    alignItems: "center",
    justifyContent: "center",
  },
  quantityActive: { backgroundColor: palette.navy, borderColor: palette.navy },
  quantityText: { color: palette.muted, fontWeight: "800" },
  quantityTextActive: { color: "white" },
  checkoutBar: {
    borderTopWidth: 1,
    borderTopColor: palette.line,
    padding: 15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "white",
  },
  checkoutTotal: {
    color: palette.navy,
    fontSize: 22,
    fontWeight: "900",
    marginTop: 2,
  },
  checkoutButton: {
    backgroundColor: palette.navy,
    borderRadius: 13,
    paddingVertical: 14,
    paddingHorizontal: 30,
  },
  checkoutButtonText: { color: "white", fontWeight: "900" },
  reviewButton: {
    backgroundColor: palette.coral,
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
    paddingVertical: 9,
    paddingHorizontal: 11,
    borderRadius: 14,
  },
  reviewButtonText: { color: "white", fontSize: 11, fontWeight: "900" },
  foodModeRow: { gap: 7, paddingVertical: 13 },
  foodMode: {
    minHeight: 38,
    borderRadius: 19,
    borderWidth: 1,
    borderColor: "#CFE0F1",
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: "white",
  },
  foodModeActive: { backgroundColor: palette.blue, borderColor: palette.blue },
  foodModeText: { color: palette.blue, fontSize: 10, fontWeight: "900" },
  foodModeTextActive: { color: "white" },
  foodFilterRow: { gap: 7, paddingRight: 12 },
  foodSectionHint: { color: palette.muted, fontSize: 9, marginTop: 3 },
  featuredListRow: { gap: 11, paddingBottom: 18 },
  featuredListExpanded: { flexDirection: "row", flexWrap: "wrap", gap: 11, paddingBottom: 18 },
  featuredListCardExpanded: { width: "48%", flexGrow: 1 },
  featuredListCard: {
    width: 214,
    height: 145,
    borderRadius: 17,
    overflow: "hidden",
    backgroundColor: "#EAF0F6",
  },
  featuredListImage: { width: "100%", height: "100%" },
  featuredListShade: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    padding: 13,
    paddingTop: 45,
  },
  featuredListTitle: { color: "white", fontSize: 15, fontWeight: "900" },
  featuredListMeta: { color: "#DCE9F7", fontSize: 9, marginTop: 4 },
  foodCard: {
    backgroundColor: "white",
    borderRadius: 18,
    overflow: "hidden",
    marginBottom: 17,
    borderWidth: 1,
    borderColor: palette.line,
  },
  foodImage: { width: "100%", height: 160 },
  rating: {
    position: "absolute",
    top: 12,
    left: 12,
    minWidth: 52,
    height: 32,
    borderRadius: 16,
    backgroundColor: palette.green,
    flexDirection: "row",
    gap: 4,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "white",
    paddingHorizontal: 8,
  },
  ratingText: { color: "white", fontWeight: "900", fontSize: 13 },
  foodBookmark: {
    position: "absolute",
    top: 12,
    right: 12,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "rgba(255,255,255,.94)",
    alignItems: "center",
    justifyContent: "center",
  },
  foodBody: { padding: 14 },
  foodTitleRow: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  reviewCount: { color: palette.blue, fontSize: 10, fontWeight: "800" },
  dish: { color: palette.ink, fontWeight: "800", marginTop: 10 },
  quote: { color: palette.muted, fontSize: 12, lineHeight: 18, marginTop: 7 },
  friendPickLine: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    borderTopWidth: 1,
    borderTopColor: palette.line,
    marginTop: 12,
    paddingTop: 11,
  },
  friendFaceStack: { flexDirection: "row", width: 42 },
  miniFace: {
    width: 25,
    height: 25,
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "white",
  },
  miniFaceOverlap: { marginLeft: -8 },
  miniFaceText: { color: palette.navy, fontSize: 7, fontWeight: "900" },
  friendPickText: {
    flex: 1,
    color: palette.blue,
    fontSize: 9,
    fontWeight: "800",
  },
  foodDetailBody: { padding: 18, paddingBottom: 46 },
  foodDetailHero: {
    width: "100%",
    height: 215,
    borderRadius: 20,
    backgroundColor: "#EEF2F6",
  },
  foodDetailBookmark: {
    position: "absolute",
    right: 13,
    bottom: 13,
    width: 43,
    height: 43,
    borderRadius: 22,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#173A65",
    shadowOpacity: 0.16,
    shadowRadius: 8,
  },
  foodDetailTitle: {
    color: palette.navy,
    fontSize: 26,
    fontWeight: "900",
    marginTop: 15,
  },
  foodDetailMeta: { color: palette.muted, fontSize: 11, marginTop: 5 },
  placeActions: { flexDirection: "row", gap: 7, marginTop: 15 },
  placeAction: {
    flex: 1,
    minHeight: 43,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: "#BFD7ED",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 5,
  },
  placeActionText: { color: palette.blue, fontSize: 9, fontWeight: "900" },
  scoreGrid: { flexDirection: "row", gap: 8, marginTop: 16 },
  reviewCountAction: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", minHeight: 43, paddingHorizontal: 13, marginTop: 12, borderRadius: 12, backgroundColor: palette.sky },
  reviewCountActionText: { color: palette.blue, fontSize: 11, fontWeight: "900" },
  reviewPageSummary: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 16 },
  reviewPageRating: { color: palette.navy, fontSize: 26, fontWeight: "900" },
  reviewPageMeta: { color: palette.muted, fontSize: 11, flexShrink: 1 },
  reviewPageDemoNote: { color: palette.muted, fontSize: 10, lineHeight: 15, marginTop: 12 },
  reviewPageVisibleAverage: { color: palette.navy, fontSize: 11, fontWeight: "800", marginTop: 10 },
  scoreCard: {
    flex: 1,
    minHeight: 92,
    borderRadius: 14,
    backgroundColor: "#F4F8FC",
    alignItems: "center",
    justifyContent: "center",
    padding: 8,
  },
  scoreValue: {
    color: palette.navy,
    fontSize: 18,
    fontWeight: "900",
    marginTop: 3,
  },
  scoreLabel: {
    color: palette.muted,
    fontSize: 8,
    textAlign: "center",
    marginTop: 2,
  },
  foodPhotoRow: { gap: 8, paddingBottom: 4 },
  foodDetailPhoto: {
    width: 142,
    height: 112,
    borderRadius: 13,
    backgroundColor: "#EEF2F6",
  },
  menuPhotoCard: {
    width: 142,
    height: 112,
    borderRadius: 13,
    borderWidth: 1.5,
    borderStyle: "dashed",
    borderColor: "#AFCDEB",
    backgroundColor: "#F7FBFF",
    alignItems: "center",
    justifyContent: "center",
    padding: 10,
  },
  menuPhotoText: {
    color: palette.blue,
    fontSize: 9,
    fontWeight: "900",
    textAlign: "center",
    marginTop: 6,
  },
  studentReviewCard: {
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 16,
    padding: 13,
    marginTop: 17,
  },
  studentReviewHead: { flexDirection: "row", alignItems: "center", gap: 9 },
  reviewStars: { color: "#F2A91B", fontSize: 11, letterSpacing: 1 },
  translateButton: {
    alignSelf: "flex-start",
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: palette.sky,
    borderRadius: 14,
    paddingVertical: 7,
    paddingHorizontal: 10,
    marginTop: 10,
  },
  translateText: { color: palette.blue, fontSize: 9, fontWeight: "900" },
  reviewTranslationError: { color: palette.coral, fontSize: 10, marginTop: 7 },
  friendOpinion: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    backgroundColor: "#F6F9FC",
    borderRadius: 14,
    padding: 12,
  },
  foodReviewBody: { padding: 18, paddingBottom: 48 },
  reviewPlaceHead: {
    flexDirection: "row",
    alignItems: "center",
    gap: 11,
    backgroundColor: "#F4F8FC",
    borderRadius: 15,
    padding: 10,
  },
  reviewPlaceImage: { width: 62, height: 62, borderRadius: 12 },
  sentimentRow: { flexDirection: "row", gap: 7 },
  sentimentOption: {
    flex: 1,
    minHeight: 84,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    padding: 7,
    borderWidth: 2,
    borderColor: "transparent",
  },
  sentimentActive: { borderColor: palette.navy },
  sentimentText: {
    color: palette.navy,
    fontSize: 9,
    fontWeight: "900",
    textAlign: "center",
  },
  foodStarRow: { flexDirection: "row", gap: 9, marginBottom: 14 },
  reviewCriterionRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: palette.line },
  reviewCriterionLabel: { flex: 1, color: palette.navy, fontSize: 11, fontWeight: "800" },
  reviewCriterionStars: { flexDirection: "row", gap: 6 },
  reviewAverageCard: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: palette.sky, borderRadius: 12, padding: 12, marginTop: 12 },
  reviewAverageLabel: { color: palette.navy, fontSize: 11, fontWeight: "800" },
  reviewAverageValue: { color: palette.blue, fontSize: 17, fontWeight: "900" },
  reviewUploadGrid: { flexDirection: "row", gap: 9 },
  reviewUpload: {
    flex: 1,
    minHeight: 93,
    borderRadius: 14,
    borderWidth: 1.5,
    borderStyle: "dashed",
    borderColor: "#AFCDEB",
    backgroundColor: "#F7FBFF",
    alignItems: "center",
    justifyContent: "center",
  },
  reviewUploadTitle: {
    color: palette.navy,
    fontSize: 10,
    fontWeight: "900",
    marginTop: 6,
  },
  reviewUploadMeta: { color: palette.muted, fontSize: 8, marginTop: 2 },
  reviewPrivacy: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    backgroundColor: "#ECF9F2",
    borderRadius: 14,
    padding: 12,
    marginTop: 14,
  },
  marketHero: {
    alignItems: "flex-start",
    gap: 10,
    marginBottom: 12,
  },
  sellButton: {
    backgroundColor: palette.green,
    flexDirection: "row",
    gap: 5,
    alignItems: "center",
    paddingVertical: 11,
    paddingHorizontal: 16,
    borderRadius: 12,
  },
  sellButtonText: { color: "white", fontWeight: "800", fontSize: 12 },
  commission: {
    backgroundColor: palette.sky,
    borderRadius: 13,
    padding: 12,
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
    marginBottom: 15,
  },
  marketFilterTitle: { color: palette.navy, fontSize: 13, fontWeight: "900", marginBottom: 10 },
  marketSellerFilters: { gap: 8, paddingRight: 16, paddingBottom: 2 },
  marketSellerFilter: { flexDirection: "row", gap: 6, minHeight: 42, borderRadius: 12, paddingHorizontal: 14 },
  marketSellerFilterText: { fontSize: 11 },
  marketFilterHint: { color: palette.muted, fontSize: 10, lineHeight: 15, marginTop: 9, marginBottom: 21 },
  marketCategoryNav: { marginBottom: 10 },
  marketCategoryRow: { gap: 8, paddingRight: 12 },
  marketResultsHead: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 13 },
  marketResultsTitle: { color: palette.navy, fontSize: 15, fontWeight: "900" },
  marketResultsCount: { color: palette.muted, fontSize: 11, fontWeight: "700" },
  marketCategory: {
    minHeight: 36,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: "#D7E1ED",
    paddingHorizontal: 13,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "white",
  },
  marketCategoryActive: {
    backgroundColor: palette.blue,
    borderColor: palette.blue,
  },
  marketCategoryText: { color: palette.muted, fontSize: 10, fontWeight: "800" },
  marketCategoryTextActive: { color: "white" },
  marketAffordability: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 9,
    padding: 12,
    borderRadius: 13,
    backgroundColor: "#ECF9F2",
    marginBottom: 8,
  },
  marketAffordabilityText: {
    flex: 1,
    color: "#397653",
    fontSize: 9,
    lineHeight: 14,
  },
  productGrid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", rowGap: 12 },
  productCard: { width: "48.5%", borderWidth: 1, borderColor: palette.line, borderRadius: 16, backgroundColor: "#FFFFFF", overflow: "hidden" },
  productImage: {
    height: 148,
    width: "100%",
    backgroundColor: "#EEF2F6",
  },
  productBody: { padding: 11 },
  productName: { color: palette.navy, fontWeight: "900", fontSize: 13, minHeight: 34 },
  productConditionPill: {
    alignSelf: "flex-start",
    backgroundColor: "#F0F4F8",
    borderRadius: 10,
    paddingHorizontal: 7,
    paddingVertical: 3,
    marginTop: 5,
  },
  productCondition: { color: palette.muted, fontSize: 9, fontWeight: "700" },
  productPrice: {
    color: palette.blue,
    fontWeight: "900",
    fontSize: 16,
    marginTop: 5,
  },
  marketProductSeller: { flexDirection: "row", alignItems: "center", gap: 6, borderTopWidth: 1, borderTopColor: palette.line, marginTop: 10, paddingTop: 9 },
  marketEmpty: {
    alignItems: "center",
    justifyContent: "center",
    minHeight: 220,
    paddingHorizontal: 28,
  },
  marketEmptyTitle: {
    color: palette.navy,
    fontSize: 15,
    fontWeight: "900",
    marginTop: 10,
    marginBottom: 4,
  },
  productDetailBody: { padding: 18, paddingBottom: 45 },
  productDetailImage: {
    width: "100%",
    aspectRatio: 1.35,
    borderRadius: 20,
    backgroundColor: "#EEF2F6",
  },
  productDetailHeadline: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 12,
    marginTop: 15,
  },
  productDetailName: {
    color: palette.navy,
    fontSize: 23,
    lineHeight: 28,
    fontWeight: "900",
  },
  productDetailPrice: { color: palette.blue, fontSize: 24, fontWeight: "900" },
  productFacts: { flexDirection: "row", gap: 7, marginTop: 14 },
  productFact: {
    flex: 1,
    minHeight: 66,
    borderRadius: 13,
    backgroundColor: "#F3F7FB",
    padding: 10,
  },
  productFactLabel: { color: palette.muted, fontSize: 8, fontWeight: "900" },
  productFactValue: {
    color: palette.navy,
    fontSize: 10,
    lineHeight: 14,
    fontWeight: "800",
    marginTop: 4,
  },
  productDescription: { color: palette.ink, fontSize: 12, lineHeight: 19 },
  handoverCard: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    borderWidth: 1,
    borderColor: "#CFE3F8",
    borderRadius: 15,
    padding: 13,
    backgroundColor: "#F7FBFF",
    marginTop: 15,
  },
  handoverIcon: {
    width: 39,
    height: 39,
    borderRadius: 13,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  handoverTitle: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  handoverText: {
    color: palette.muted,
    fontSize: 9,
    lineHeight: 14,
    marginTop: 4,
  },
  productSeller: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 15,
    padding: 12,
    marginTop: 13,
  },
  productSellerAvatar: {
    width: 43,
    height: 43,
    borderRadius: 22,
    backgroundColor: "#E9E0FF",
    alignItems: "center",
    justifyContent: "center",
  },
  productSellerInitial: { color: "#6D3EEB", fontSize: 17, fontWeight: "900" },
  productSellerName: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  sellerPublicHero: { borderWidth: 1, borderColor: palette.line, borderRadius: 18, backgroundColor: "#FFFFFF", overflow: "hidden", paddingBottom: 20 },
  sellerPublicCover: { width: "100%", height: 145, backgroundColor: "#EAF4FF" },
  sellerPublicAvatar: { width: 70, height: 70, borderRadius: 35, backgroundColor: "#E9E0FF", borderWidth: 4, borderColor: "#FFFFFF", alignItems: "center", justifyContent: "center", alignSelf: "center", marginTop: -34, marginBottom: 7 },
  sellerPublicAvatarText: { color: "#6D3EEB", fontWeight: "900", fontSize: 23 },
  sellerPublicName: { color: palette.navy, fontWeight: "900", fontSize: 19, textAlign: "center" },
  sellerPublicListings: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", rowGap: 10 },
  sellerPublicListing: { width: "48.5%", borderWidth: 1, borderColor: palette.line, borderRadius: 14, overflow: "hidden", backgroundColor: "#FFFFFF" },
  sellerPublicListingImage: { width: "100%", height: 112, backgroundColor: "#EEF2F6" },
  productDetailActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    marginTop: 16,
  },
  productMessageButton: {
    minHeight: 50,
    borderWidth: 1,
    borderColor: palette.blue,
    borderRadius: 14,
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
  productMessageText: { color: palette.blue, fontSize: 11, fontWeight: "900" },
  productBuyButton: { flex: 1, marginTop: 0 },
  marketRules: {
    backgroundColor: "#ECF9F2",
    borderRadius: 13,
    padding: 12,
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    marginBottom: 15,
  },
  marketRulesText: { flex: 1, color: "#397653", fontSize: 9, lineHeight: 14 },
  fairPriceCard: {
    borderWidth: 1,
    borderColor: "#A8DDC0",
    backgroundColor: "#F1FBF5",
    borderRadius: 14,
    padding: 13,
    marginBottom: 8,
  },
  fairPriceHigh: { borderColor: "#F3C5C8", backgroundColor: "#FFF3F4" },
  fairPriceHead: { flexDirection: "row", alignItems: "center", gap: 7 },
  fairPriceTitle: { color: "#28754C", fontSize: 12, fontWeight: "900" },
  fairPriceRange: {
    color: palette.navy,
    fontSize: 12,
    fontWeight: "800",
    marginTop: 8,
  },
  fairPriceHint: {
    color: palette.muted,
    fontSize: 9,
    lineHeight: 14,
    marginTop: 4,
  },
  deliveryOptions: { flexDirection: "row", gap: 8 },
  deliveryOption: {
    flex: 1,
    minHeight: 86,
    borderWidth: 1,
    borderColor: "#D7E1ED",
    borderRadius: 14,
    padding: 11,
    justifyContent: "center",
  },
  deliveryOptionActive: {
    borderColor: palette.blue,
    backgroundColor: "#F2F8FE",
  },
  deliveryTitle: {
    color: palette.navy,
    fontSize: 11,
    fontWeight: "900",
    marginTop: 6,
  },
  deliveryHint: { color: palette.muted, fontSize: 9, marginTop: 3 },
  addressPrivacy: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    backgroundColor: palette.sky,
    borderRadius: 12,
    padding: 11,
  },
  addressPrivacyText: {
    flex: 1,
    color: palette.navy,
    fontSize: 9,
    lineHeight: 14,
  },
  friendFilterShell: {
    position: "relative",
    marginHorizontal: -18,
    marginBottom: 10,
  },
  friendFilterScroller: { flexGrow: 0 },
  friendFilterRow: { paddingLeft: 18, paddingRight: 18, alignItems: "center" },
  friendFilterArrow: {
    position: "absolute",
    top: 0,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "white",
    borderWidth: 1,
    borderColor: "#D9E6F4",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#0B2E67",
    shadowOpacity: 0.14,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 3,
  },
  friendFilterArrowLeft: { left: 7 },
  friendFilterArrowRight: { right: 7 },
  matchSourceCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 11,
    backgroundColor: "#F1F7FD",
    borderWidth: 1,
    borderColor: "#D7E8F7",
    borderRadius: 15,
    padding: 13,
    marginBottom: 8,
  },
  matchSourceTitle: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  matchSourceText: {
    color: palette.muted,
    fontSize: 10,
    lineHeight: 15,
    marginTop: 3,
  },
  notificationBody: { padding: 20, paddingBottom: 24 },
  notificationIntro: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    backgroundColor: palette.sky,
    borderRadius: 17,
    padding: 14,
  },
  notificationIntroIcon: {
    width: 43,
    height: 43,
    borderRadius: 22,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  notificationFilters: {
    flexDirection: "row",
    gap: 6,
    marginTop: 16,
    backgroundColor: "#F1F4F8",
    borderRadius: 15,
    padding: 4,
  },
  notificationFilter: {
    flex: 1,
    minHeight: 38,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 11,
    paddingHorizontal: 3,
  },
  notificationFilterActive: {
    backgroundColor: "white",
    shadowColor: "#29486F",
    shadowOpacity: 0.1,
    shadowRadius: 7,
    shadowOffset: { width: 0, height: 2 },
  },
  notificationFilterText: {
    color: palette.muted,
    fontWeight: "800",
    fontSize: 10,
  },
  notificationFilterTextActive: { color: palette.navy },
  notificationDate: {
    color: palette.muted,
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.2,
    marginTop: 22,
    marginBottom: 7,
  },
  notificationCard: {
    position: "relative",
    flexDirection: "row",
    gap: 11,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
    paddingVertical: 16,
  },
  notificationIconWrap: { width: 43, height: 43, position: "relative" },
  notificationIcon: {
    width: 43,
    height: 43,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  notificationTitleRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  notificationTitle: {
    flex: 1,
    color: palette.navy,
    fontWeight: "900",
    fontSize: 14,
  },
  notificationTime: {
    minWidth: 48,
    color: palette.muted,
    fontSize: 9,
    textAlign: "right",
  },
  notificationText: {
    color: palette.muted,
    fontSize: 11,
    lineHeight: 17,
    marginTop: 4,
    paddingRight: 5,
  },
  ticketAction: {
    alignSelf: "flex-start",
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
    backgroundColor: palette.blue,
    borderRadius: 12,
    paddingVertical: 8,
    paddingHorizontal: 12,
    marginTop: 10,
  },
  ticketActionText: { color: "white", fontSize: 10, fontWeight: "900" },
  unreadDot: {
    position: "absolute",
    top: -4,
    right: -4,
    width: 10,
    height: 10,
    borderRadius: 5,
    borderWidth: 2,
    borderColor: "white",
    backgroundColor: palette.coral,
  },
  ticketPassScreen: { flex: 1, backgroundColor: "#061A3F" },
  ticketPassHead: {
    height: 62,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 18,
  },
  ticketPassHeadTitle: { color: "white", fontSize: 18, fontWeight: "900" },
  ticketPassClose: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,.1)",
  },
  ticketPassBody: { padding: 18, paddingBottom: 45 },
  ticketPassHero: {
    minHeight: 182,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 21,
    justifyContent: "space-between",
  },
  ticketPassBrand: { flexDirection: "row", alignItems: "center", gap: 8 },
  ticketPassMark: {
    width: 31,
    height: 31,
    borderRadius: 16,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  ticketPassMarkText: { color: palette.blue, fontWeight: "900", fontSize: 17 },
  ticketPassBrandText: {
    color: "white",
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.3,
  },
  ticketPassEvent: {
    color: "white",
    fontSize: 27,
    lineHeight: 32,
    fontWeight: "900",
    marginTop: 20,
  },
  ticketPassAdmit: {
    color: "#BBDCF9",
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.1,
    marginTop: 8,
  },
  ticketPassCard: {
    backgroundColor: "white",
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    padding: 20,
    alignItems: "center",
  },
  qrFrame: {
    backgroundColor: "white",
    padding: 10,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: palette.line,
  },
  ticketCode: {
    color: palette.navy,
    fontSize: 13,
    fontWeight: "900",
    letterSpacing: 1.6,
    marginTop: 13,
  },
  ticketDemo: {
    color: palette.coral,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 0.8,
    marginTop: 5,
  },
  ticketDivider: {
    alignSelf: "stretch",
    borderTopWidth: 1,
    borderStyle: "dashed",
    borderColor: "#CBD5E1",
    marginVertical: 18,
  },
  ticketInfoGrid: {
    alignSelf: "stretch",
    flexDirection: "row",
    flexWrap: "wrap",
  },
  ticketInfo: { width: "50%", paddingVertical: 8 },
  ticketInfoLabel: {
    color: palette.muted,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 0.8,
  },
  ticketInfoValue: {
    color: palette.ink,
    fontSize: 12,
    fontWeight: "800",
    marginTop: 4,
  },
  ticketSecurity: {
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    padding: 14,
    borderRadius: 14,
    backgroundColor: "rgba(255,255,255,.08)",
    marginTop: 14,
  },
  ticketSecurityText: {
    flex: 1,
    color: "#D0E5F8",
    fontSize: 10,
    lineHeight: 15,
  },
  walletButton: {
    minHeight: 50,
    borderRadius: 14,
    marginTop: 13,
    backgroundColor: "white",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  walletButtonText: { color: palette.navy, fontWeight: "900" },
  waitingPolicy: {
    flexDirection: "row",
    gap: 10,
    alignItems: "flex-start",
    backgroundColor: "#F3F8FD",
    borderRadius: 13,
    padding: 12,
    marginTop: 14,
  },
  waitingPolicyIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  waitingPolicyTitle: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  waitingPolicyText: {
    color: palette.muted,
    fontSize: 9,
    lineHeight: 15,
    marginTop: 3,
  },
  airportAutoNote: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 14,
    paddingVertical: 8,
    backgroundColor: "#F7FAFD",
  },
  airportAutoText: { color: palette.muted, fontSize: 9, flex: 1 },
  cleanTypeGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginHorizontal: -4,
  },
  cleanType: {
    width: "50%",
    minHeight: 72,
    borderWidth: 1,
    borderColor: "#D5E0EB",
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
    gap: 5,
    transform: [{ scale: 0.97 }],
  },
  cleanTypeActive: { backgroundColor: palette.blue, borderColor: palette.blue },
  cleanTypeText: {
    color: palette.navy,
    fontSize: 10,
    fontWeight: "900",
    textAlign: "center",
    paddingHorizontal: 4,
  },
  cleanTypeTextActive: { color: "white" },
  cleanScopeHint: {
    color: palette.muted,
    fontSize: 11,
    lineHeight: 16,
    marginTop: 8,
    marginBottom: 4,
  },
  counterCard: {
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 14,
    overflow: "hidden",
  },
  counterRow: {
    minHeight: 55,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 13,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
  },
  counterLabel: {
    flex: 1,
    color: palette.ink,
    fontSize: 12,
    fontWeight: "700",
  },
  counterControls: { flexDirection: "row", alignItems: "center", gap: 8 },
  counterButton: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: palette.sky,
    alignItems: "center",
    justifyContent: "center",
  },
  counterValue: {
    minWidth: 18,
    textAlign: "center",
    color: palette.navy,
    fontWeight: "900",
  },
  calendarCard: {
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 16,
    padding: 12,
  },
  calendarCardCompact: { padding: 8, borderRadius: 13 },
  calendarHead: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  calendarHeadCompact: { marginBottom: 3 },
  calendarArrow: {
    width: 35,
    height: 35,
    borderRadius: 18,
    backgroundColor: "#F2F5F8",
    alignItems: "center",
    justifyContent: "center",
  },
  calendarArrowCompact: { width: 28, height: 28, borderRadius: 14 },
  calendarArrowDisabled: { backgroundColor: "#F7F8FA" },
  calendarMonth: {
    color: palette.navy,
    fontSize: 14,
    fontWeight: "900",
    textAlign: "center",
  },
  calendarSub: {
    color: palette.muted,
    fontSize: 9,
    textAlign: "center",
    marginTop: 2,
  },
  weekRow: { flexDirection: "row" },
  weekday: {
    width: "14.285%",
    textAlign: "center",
    color: palette.muted,
    fontSize: 9,
    fontWeight: "900",
    paddingVertical: 6,
  },
  calendarGrid: { flexDirection: "row", flexWrap: "wrap" },
  calendarDay: {
    width: "14.285%",
    aspectRatio: 1,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  calendarDayCompact: { aspectRatio: 1.28 },
  calendarDayUnavailable: { opacity: 0.35 },
  calendarDayLimited: { backgroundColor: "#FFF8E7" },
  calendarDaySelected: { backgroundColor: palette.blue },
  calendarDayText: { color: palette.ink, fontSize: 11, fontWeight: "700" },
  calendarDayTextUnavailable: {
    color: palette.muted,
    textDecorationLine: "line-through",
  },
  calendarDayTextSelected: { color: "white", fontWeight: "900" },
  limitedDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: "#F2B94B",
    position: "absolute",
    bottom: 3,
  },
  calendarLegend: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 13,
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: palette.line,
  },
  legendItem: { flexDirection: "row", alignItems: "center", gap: 4 },
  legendDot: { width: 7, height: 7, borderRadius: 4 },
  legendText: { color: palette.muted, fontSize: 8 },
  textAreaField: { minHeight: 128 },
  textAreaInput: {
    minHeight: 88,
    color: palette.ink,
    fontSize: 12,
    lineHeight: 18,
  },
  photoHelp: {
    color: palette.muted,
    fontSize: 10,
    lineHeight: 15,
    marginBottom: 9,
  },
  cleanPhotoPicker: {
    minHeight: 112,
    borderWidth: 1.5,
    borderStyle: "dashed",
    borderColor: "#AFCDEB",
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#F7FBFF",
  },
  cleanPhotoGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginHorizontal: -4,
    marginTop: 9,
  },
  cleanPhotoWrap: { width: "33.33%", padding: 4 },
  cleanPhoto: {
    width: "100%",
    aspectRatio: 1,
    borderRadius: 11,
    backgroundColor: "#EEF2F6",
  },
  removePhoto: {
    position: "absolute",
    top: 8,
    right: 8,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: "rgba(8,38,95,.85)",
    alignItems: "center",
    justifyContent: "center",
  },
  cleanSummary: {
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    backgroundColor: palette.sky,
    borderRadius: 12,
    padding: 11,
    marginTop: 14,
  },
  cleanSummaryText: {
    flex: 1,
    color: palette.navy,
    fontSize: 10,
    fontWeight: "700",
    lineHeight: 15,
  },
  movingNotice: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 9,
    padding: 12,
    borderRadius: 12,
    backgroundColor: "#EAF8F8",
    marginTop: 12,
  },
  movingNoticeText: {
    flex: 1,
    color: "#135E62",
    fontSize: 10,
    lineHeight: 15,
    fontWeight: "700",
  },
  crewGrid: { gap: 8 },
  crewOption: {
    minHeight: 65,
    borderWidth: 1,
    borderColor: "#D7E1ED",
    borderRadius: 13,
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  crewOptionActive: { borderColor: palette.blue, backgroundColor: "#F2F8FE" },
  crewTitle: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  crewHint: { color: palette.muted, fontSize: 9, lineHeight: 13, marginTop: 2 },
  eventsTitleRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
    marginBottom: 14,
  },
  postEventButton: {
    minHeight: 38,
    borderRadius: 13,
    backgroundColor: palette.coral,
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 5,
  },
  postEventButtonText: { color: "white", fontSize: 11, fontWeight: "900" },
  customItemsList: { gap: 11, marginTop: 12 },
  customItemCard: {
    borderWidth: 1,
    borderColor: "#CFE0F1",
    borderRadius: 16,
    padding: 13,
    backgroundColor: "#FAFCFF",
  },
  customItemHead: {
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    marginBottom: 2,
  },
  customItemIcon: {
    width: 36,
    height: 36,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: palette.sky,
  },
  customItemTitle: { color: palette.navy, fontSize: 13, fontWeight: "900" },
  customItemSubtitle: {
    color: palette.muted,
    fontSize: 9,
    lineHeight: 13,
    marginTop: 2,
  },
  customMeasureLabel: {
    color: palette.navy,
    fontSize: 10,
    fontWeight: "900",
    marginBottom: 7,
  },
  customDimensions: { flexDirection: "row", alignItems: "flex-end", gap: 6 },
  customDimensionField: {
    flex: 1,
    minHeight: 63,
    borderWidth: 1,
    borderColor: "#D7E1ED",
    borderRadius: 11,
    paddingHorizontal: 8,
    paddingTop: 7,
    backgroundColor: "white",
  },
  customDimensionLabel: {
    color: palette.muted,
    fontSize: 8,
    fontWeight: "800",
  },
  customDimensionInput: {
    flex: 1,
    color: palette.ink,
    fontSize: 12,
    paddingVertical: 4,
  },
  customUnit: {
    minWidth: 45,
    height: 48,
    borderRadius: 11,
    borderWidth: 1,
    borderColor: "#D7E1ED",
    backgroundColor: "#F2F6FA",
    alignItems: "center",
    justifyContent: "center",
  },
  customUnitText: { color: palette.navy, fontSize: 10, fontWeight: "900" },
  customWeightRow: { flexDirection: "row", alignItems: "flex-end", gap: 7 },
  customWeightField: { flex: 1 },
  customNotesField: { marginBottom: 0 },
  bookingFilters: {
    flexDirection: "row",
    gap: 6,
    backgroundColor: "#F1F4F8",
    borderRadius: 14,
    padding: 4,
    marginBottom: 14,
  },
  bookingFilter: {
    flex: 1,
    minHeight: 38,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
  },
  bookingFilterActive: {
    backgroundColor: "white",
    shadowColor: "#29486F",
    shadowOpacity: 0.1,
    shadowRadius: 6,
  },
  bookingFilterText: { color: palette.muted, fontSize: 10, fontWeight: "800" },
  bookingFilterTextActive: { color: palette.navy },
  bookingCard: {
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 17,
    backgroundColor: "white",
    marginBottom: 13,
    overflow: "hidden",
  },
  bookingHead: {
    minHeight: 52,
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    paddingHorizontal: 13,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
  },
  bookingIcon: {
    width: 34,
    height: 34,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
  },
  bookingType: {
    flex: 1,
    color: palette.navy,
    fontSize: 11,
    fontWeight: "900",
  },
  bookingStatus: { fontSize: 10, fontWeight: "900" },
  bookingMain: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 15,
  },
  bookingTitle: { color: palette.ink, fontSize: 16, fontWeight: "900" },
  bookingDetail: {
    color: palette.muted,
    fontSize: 10,
    lineHeight: 15,
    marginTop: 4,
  },
  bookingPrice: { color: palette.navy, fontSize: 17, fontWeight: "900" },
  bookingActions: {
    flexDirection: "row",
    justifyContent: "flex-end",
    gap: 8,
    paddingHorizontal: 13,
    paddingBottom: 13,
  },
  bookingTextAction: {
    minHeight: 35,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: "#D6E0EA",
    paddingHorizontal: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  bookingTextActionLabel: {
    color: palette.muted,
    fontSize: 10,
    fontWeight: "800",
  },
  bookingPrimaryAction: {
    minHeight: 35,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: palette.blue,
    paddingHorizontal: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  bookingPrimaryActionLabel: {
    color: palette.blue,
    fontSize: 10,
    fontWeight: "900",
  },
  supportBody: { padding: 18, paddingBottom: 45 },
  supportBookingCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 11,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 15,
    padding: 13,
  },
  supportBookingTitle: {
    color: palette.ink,
    fontSize: 15,
    fontWeight: "900",
    marginTop: 2,
  },
  supportPromise: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 9,
    backgroundColor: "#ECF9F2",
    borderRadius: 13,
    padding: 12,
    marginTop: 12,
  },
  supportPromiseText: {
    flex: 1,
    color: "#397653",
    fontSize: 9,
    lineHeight: 14,
  },
  supportOption: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    minHeight: 67,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
    paddingVertical: 10,
  },
  supportOptionIcon: {
    width: 40,
    height: 40,
    borderRadius: 13,
    backgroundColor: palette.sky,
    alignItems: "center",
    justifyContent: "center",
  },
  supportOptionTitle: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  supportOptionText: {
    color: palette.muted,
    fontSize: 9,
    lineHeight: 14,
    marginTop: 3,
  },
  ratingCard: {
    backgroundColor: "#FFF9EC",
    borderRadius: 16,
    padding: 15,
    marginTop: 17,
  },
  ratingStars: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 13,
    maxWidth: 240,
  },
  satisfactionRow: { flexDirection: "row", gap: 7, marginTop: 13 },
  satisfactionChip: {
    flex: 1,
    minHeight: 35,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: "#E4D7B8",
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 6,
  },
  satisfactionChipActive: {
    borderColor: "#F2A91B",
    backgroundColor: "#FFF2C9",
  },
  satisfactionText: { color: palette.muted, fontSize: 9, fontWeight: "800" },
  satisfactionTextActive: { color: "#8A5B00" },
  messageSafety: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    padding: 14,
    borderRadius: 15,
    backgroundColor: "#ECF9F2",
    marginBottom: 12,
  },
  messageSafetyTitle: { color: "#17673B", fontSize: 12, fontWeight: "800" },
  messageSafetyText: {
    color: "#397653",
    fontSize: 11,
    lineHeight: 16,
    marginTop: 4,
  },
  messageRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    minHeight: 76,
    paddingVertical: 13,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
  },
  messageAvatarWrap: { width: 48, height: 48, position: "relative" },
  messageAvatar: {
    width: 48,
    height: 48,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  messageTitleRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  messageTitle: {
    flex: 1,
    color: palette.navy,
    fontSize: 14,
    fontWeight: "900",
  },
  messageTime: {
    minWidth: 48,
    color: palette.muted,
    fontSize: 10,
    textAlign: "right",
  },
  messageType: {
    color: palette.blue,
    fontSize: 10,
    fontWeight: "800",
    marginTop: 2,
  },
  messagePreview: { color: palette.muted, fontSize: 12, marginTop: 5, lineHeight: 17 },
  messageBadge: {
    position: "absolute",
    top: -6,
    right: -6,
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: palette.coral,
    borderWidth: 2,
    borderColor: "white",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 4,
  },
  messageBadgeText: { color: "white", fontSize: 8, fontWeight: "900" },
  chatScreen: { flex: 1, backgroundColor: "#F5F8FC" },
  chatHead: {
    minHeight: 64,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 16,
    backgroundColor: "white",
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
  },
  chatAvatar: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: "center",
    justifyContent: "center",
  },
  chatTitle: { color: palette.navy, fontSize: 15, fontWeight: "800" },
  chatType: { color: palette.muted, fontSize: 11, marginTop: 3 },
  groupHostCard: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 16, paddingVertical: 12, backgroundColor: "#FFFFFF", borderBottomWidth: 1, borderBottomColor: palette.line },
  groupHostAvatar: { width: 38, height: 38, borderRadius: 19, backgroundColor: "#DCEBFF", alignItems: "center", justifyContent: "center" },
  groupHostInitial: { color: palette.navy, fontWeight: "900", fontSize: 19 },
  groupHostEyebrow: { color: palette.muted, fontSize: 8, fontWeight: "800", letterSpacing: 0.8 },
  groupHostName: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  groupHostHint: { color: palette.muted, fontSize: 9, marginTop: 2 },
  groupHostMessage: { width: 34, height: 34, borderRadius: 17, backgroundColor: "#EDF6FF", alignItems: "center", justifyContent: "center" },
  chatSafety: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 11,
    backgroundColor: "#ECF9F2",
  },
  chatSafetyText: { flex: 1, color: "#397653", fontSize: 11, lineHeight: 16 },
  chatMessages: { flexGrow: 1, padding: 16, gap: 12 },
  incomingBubble: {
    alignSelf: "flex-start",
    maxWidth: "82%",
    backgroundColor: "white",
    borderRadius: 16,
    borderBottomLeftRadius: 5,
    paddingVertical: 11,
    paddingHorizontal: 13,
  },
  incomingText: { color: palette.ink, fontSize: 13, lineHeight: 19 },
  outgoingBubble: {
    alignSelf: "flex-end",
    maxWidth: "82%",
    backgroundColor: palette.blue,
    borderRadius: 16,
    borderBottomRightRadius: 5,
    paddingVertical: 11,
    paddingHorizontal: 13,
  },
  outgoingText: { color: "white", fontSize: 13, lineHeight: 19 },
  chatComposerArea: {
    backgroundColor: "white",
    borderTopWidth: 1,
    borderTopColor: palette.line,
  },
  mentionMenu: { backgroundColor: "white", borderTopWidth: 1, borderTopColor: palette.line, maxHeight: 224 },
  mentionOption: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 18, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: "#EEF2F7" },
  mentionHandle: { color: palette.blue, fontSize: 12, fontWeight: "800", minWidth: 100 },
  mentionDetail: { color: palette.muted, fontSize: 10, flex: 1 },
  chatComposer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    padding: 10,
    backgroundColor: "white",
  },
  chatToolButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: "#F1F6FB",
    alignItems: "center",
    justifyContent: "center",
  },
  chatToolButtonActive: { backgroundColor: "#DCEEFF" },
  chatInput: {
    flex: 1,
    minHeight: 42,
    borderRadius: 21,
    backgroundColor: "#F1F4F8",
    paddingHorizontal: 14,
    color: palette.ink,
  },
  chatSend: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: palette.blue,
    alignItems: "center",
    justifyContent: "center",
  },
  chatSendDisabled: { backgroundColor: "#A8C9EA" },
  emojiTray: {
    flexDirection: "row",
    flexWrap: "wrap",
    paddingHorizontal: 11,
    paddingTop: 10,
    gap: 5,
  },
  emojiOption: {
    width: 38,
    height: 36,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#F5F8FC",
  },
  emojiText: { fontSize: 21 },
  attachmentPreviewRow: { gap: 8, paddingHorizontal: 11, paddingTop: 10 },
  attachmentPreview: {
    width: 112,
    height: 60,
    borderRadius: 12,
    backgroundColor: "#F2F6FA",
    borderWidth: 1,
    borderColor: "#DCE5EF",
    paddingHorizontal: 9,
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  attachmentPreviewImage: { width: 42, height: 42, borderRadius: 8 },
  attachmentPreviewName: {
    flex: 1,
    color: palette.navy,
    fontSize: 8,
    fontWeight: "800",
  },
  attachmentRemove: {
    position: "absolute",
    top: -5,
    right: -5,
    width: 19,
    height: 19,
    borderRadius: 10,
    backgroundColor: palette.navy,
    alignItems: "center",
    justifyContent: "center",
  },
  sentMessageGroup: { alignSelf: "flex-end", maxWidth: "86%", gap: 6 },
  sentAttachmentGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "flex-end",
    gap: 5,
  },
  sentAttachmentImage: {
    width: 92,
    height: 92,
    borderRadius: 13,
    backgroundColor: "#E8EEF5",
  },
  sentFileCard: {
    width: 170,
    minHeight: 48,
    borderRadius: 12,
    backgroundColor: "white",
    borderWidth: 1,
    borderColor: "#CFE0F1",
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    paddingHorizontal: 10,
  },
  sentFileName: {
    flex: 1,
    color: palette.navy,
    fontSize: 9,
    fontWeight: "800",
  },
  eventAttendance: {
    flexDirection: "row",
    alignItems: "stretch",
    borderWidth: 1,
    borderColor: "#D9E8F6",
    backgroundColor: "#F5FAFF",
    borderRadius: 13,
    marginTop: 8,
    overflow: "hidden",
  },
  eventAttendanceItem: {
    flex: 1,
    minHeight: 52,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingHorizontal: 8,
  },
  eventAttendanceDivider: {
    width: 1,
    backgroundColor: "#D9E8F6",
    marginVertical: 9,
  },
  eventAttendanceValue: {
    color: palette.navy,
    fontSize: 13,
    fontWeight: "900",
  },
  eventFriendsGoing: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "#F1F8FF", borderRadius: 11, paddingHorizontal: 10, paddingVertical: 8, marginBottom: 9 },
  eventFriendAvatars: { flexDirection: "row", alignItems: "center" },
  eventFriendAvatar: { width: 24, height: 24, borderRadius: 12, borderWidth: 1.5, borderColor: "white", alignItems: "center", justifyContent: "center", marginRight: -5 },
  eventFriendInitials: { color: palette.navy, fontSize: 7, fontWeight: "900" },
  eventFriendsText: { flex: 1, color: palette.blue, fontSize: 10, fontWeight: "800" },
  eventAttendanceLabel: {
    color: palette.muted,
    fontSize: 8,
    fontWeight: "700",
    textTransform: "uppercase",
    marginTop: 1,
  },
  confirmGoingButton: {
    width: 176,
    minHeight: 42,
    borderRadius: 12,
    backgroundColor: palette.green,
    paddingHorizontal: 13,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
  confirmGoingText: { color: "white", fontSize: 10, fontWeight: "900", textAlign: "center", flexShrink: 1 },
  cancelGoingButton: { backgroundColor: "#FFF0F1", borderWidth: 1, borderColor: "#F5C8CC" },
  cancelGoingText: { color: palette.coral },
  cancelReservationDetail: { alignItems: "center", paddingVertical: 13, marginTop: 8, borderRadius: 12, borderWidth: 1, borderColor: "#F5C8CC", backgroundColor: "#FFF0F1" },
  cancelReservationDetailText: { color: palette.coral, fontWeight: "900", fontSize: 12 },
  viewEventHint: {
    width: 176,
    minHeight: 42,
    borderRadius: 12,
    backgroundColor: palette.sky,
    paddingHorizontal: 11,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
  viewEventHintText: { color: palette.blue, fontSize: 10, fontWeight: "900" },
  groupChatNotice: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    backgroundColor: palette.sky,
    borderRadius: 14,
    padding: 12,
    marginBottom: 13,
  },
  friendUsername: { color: palette.muted, fontSize: 11, marginTop: 2 },
  friendStatusPill: { backgroundColor: "#E9F8F0" },
  socialUnlocked: { borderColor: "#A8DDC0", backgroundColor: "#F1FBF5" },
  friendProfileActions: { flexDirection: "row", gap: 9, alignItems: "center" },
  friendMessageButton: { flex: 1 },
  manageFriendButton: {
    height: 36,
    paddingHorizontal: 10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#D7E1ED",
    marginTop: 18,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 5,
  },
  manageFriendText: { color: palette.muted, fontSize: 10, fontWeight: "900" },
  friendMoreButton: {
    width: 35,
    height: 35,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    marginLeft: 5,
    backgroundColor: "#F3F6F9",
  },
  requestModeTabs: {
    flexDirection: "row",
    borderRadius: 13,
    backgroundColor: "#F1F4F8",
    padding: 4,
    marginBottom: 8,
  },
  requestModeTab: {
    flex: 1,
    minHeight: 38,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  requestModeTabActive: { backgroundColor: "white" },
  requestModeText: { color: palette.muted, fontSize: 10, fontWeight: "800" },
  requestModeTextActive: { color: palette.navy },
  retractButton: {
    alignSelf: "flex-start",
    borderWidth: 1,
    borderColor: "#F0B9BD",
    borderRadius: 14,
    paddingVertical: 7,
    paddingHorizontal: 12,
    marginTop: 9,
  },
  retractButtonText: { color: palette.coral, fontSize: 9, fontWeight: "900" },
  requestOverview: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderRadius: 17,
    padding: 14,
    marginBottom: 12,
    backgroundColor: "#F2F8FE",
    borderWidth: 1,
    borderColor: "#D7E8F7",
  },
  requestOverviewIcon: {
    width: 46,
    height: 46,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "white",
    shadowColor: "#173A65",
    shadowOpacity: 0.08,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
  },
  requestOverviewTitle: {
    color: palette.navy,
    fontSize: 14,
    fontWeight: "900",
  },
  requestOverviewText: {
    color: palette.muted,
    fontSize: 10,
    lineHeight: 15,
    marginTop: 3,
  },
  requestCardPro: {
    borderWidth: 1,
    borderColor: "#DCE5EF",
    borderRadius: 18,
    backgroundColor: "white",
    padding: 14,
    marginTop: 11,
    shadowColor: "#173A65",
    shadowOpacity: 0.07,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
  requestIdentityRow: { flexDirection: "row", alignItems: "center" },
  requestAvatar: {
    width: 58,
    height: 58,
    borderRadius: 29,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
    borderWidth: 3,
    borderColor: "white",
    shadowColor: "#173A65",
    shadowOpacity: 0.1,
    shadowRadius: 7,
  },
  requestAvatarText: { color: palette.navy, fontSize: 15, fontWeight: "900" },
  requestNameRow: { flexDirection: "row", alignItems: "center", gap: 5 },
  requestName: { color: palette.navy, fontSize: 16, fontWeight: "900" },
  requestUniversity: {
    color: palette.blue,
    fontSize: 10,
    fontWeight: "800",
    marginTop: 2,
  },
  requestTime: { color: palette.muted, fontSize: 9, marginTop: 4 },
  requestMatchBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    backgroundColor: "#F6F9FC",
    borderRadius: 13,
    padding: 10,
    marginTop: 13,
  },
  requestMatchTitle: { color: palette.navy, fontSize: 9, fontWeight: "900" },
  requestMatchText: { color: palette.muted, fontSize: 9, marginTop: 2 },
  requestActionsPro: { flexDirection: "row", gap: 8, marginTop: 13 },
  acceptButtonPro: {
    flex: 1.25,
    minHeight: 43,
    borderRadius: 13,
    backgroundColor: palette.blue,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
  acceptTextPro: { color: "white", fontSize: 11, fontWeight: "900" },
  declineButtonPro: {
    flex: 1,
    minHeight: 43,
    borderRadius: 13,
    backgroundColor: "#F1F4F8",
    alignItems: "center",
    justifyContent: "center",
  },
  declineTextPro: { color: palette.muted, fontSize: 11, fontWeight: "900" },
  retractButtonPro: {
    minHeight: 42,
    borderRadius: 13,
    borderWidth: 1,
    borderColor: "#F2C7CA",
    backgroundColor: "#FFF7F7",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    marginTop: 13,
  },
  retractButtonTextPro: {
    color: palette.coral,
    fontSize: 10,
    fontWeight: "900",
  },
  requestSafetyCard: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    borderRadius: 15,
    backgroundColor: "#F1FAF5",
    padding: 13,
    marginTop: 15,
    borderWidth: 1,
    borderColor: "#D5EDDF",
  },
  requestSafetyIcon: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  requestSafetyTitle: { color: "#226E48", fontSize: 11, fontWeight: "900" },
  requestSafetyText: {
    color: "#4C765F",
    fontSize: 9,
    lineHeight: 14,
    marginTop: 3,
  },
  requestEmptyState: { alignItems: "center", paddingVertical: 34 },
  requestEmptyIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "#F2F8FE",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 9,
  },
  requestEmptyText: { color: palette.muted, fontSize: 10, marginTop: 4 },
  addFriendBody: { padding: 18, paddingBottom: 42 },
  addMethodGrid: { flexDirection: "row", gap: 7, marginTop: 16 },
  addMethod: {
    flex: 1,
    minHeight: 78,
    borderWidth: 1,
    borderColor: "#D7E1ED",
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    paddingHorizontal: 4,
  },
  addMethodActive: { borderColor: palette.blue, backgroundColor: "#F2F8FE" },
  addMethodText: {
    color: palette.muted,
    fontSize: 9,
    fontWeight: "800",
    textAlign: "center",
  },
  addMethodTextActive: { color: palette.navy },
  contactPermissionCard: {
    alignItems: "center",
    backgroundColor: "#F5FAF7",
    borderRadius: 16,
    padding: 18,
    marginTop: 16,
  },
  belongingsNotice: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    borderWidth: 1,
    borderColor: "#F0DDAF",
    backgroundColor: "#FFF9EC",
    borderRadius: 13,
    padding: 12,
    marginTop: 13,
  },
  belongingsIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  belongingsTitle: { color: "#704A00", fontSize: 11, fontWeight: "900" },
  belongingsText: {
    color: "#876A2D",
    fontSize: 9,
    lineHeight: 14,
    marginTop: 3,
  },
  messageAvatarPhoto: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: "#EEF2F6",
  },
  staffVerifiedMini: {
    position: "absolute",
    right: -5,
    bottom: -5,
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: palette.green,
    borderWidth: 2,
    borderColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  chatStaffPhoto: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: "#EEF2F6",
  },
  chatHeadAction: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#F1F6FB",
  },
  groupChatBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    backgroundColor: palette.sky,
    padding: 11,
    borderBottomWidth: 1,
    borderBottomColor: "#CFE4F8",
  },
  staffProfileBody: { padding: 18, paddingBottom: 45, alignItems: "center" },
  staffProfilePhotoWrap: {
    width: 108,
    height: 108,
    position: "relative",
  },
  staffProfilePhoto: {
    width: 108,
    height: 108,
    borderRadius: 54,
    backgroundColor: "#EEF2F6",
  },
  staffProfilePhotoBadge: {
    position: "absolute",
    right: -3,
    bottom: -3,
    width: 29,
    height: 29,
    borderRadius: 15,
    borderWidth: 3,
    borderColor: "#FFFFFF",
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
  },
  approvedPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: palette.blue,
    borderRadius: 14,
    paddingVertical: 7,
    paddingHorizontal: 12,
    marginTop: 9,
  },
  approvedPillText: {
    color: "#FFFFFF",
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 0.2,
  },
  staffProfileName: {
    color: palette.navy,
    fontSize: 23,
    fontWeight: "900",
    marginTop: 10,
  },
  staffProfileRole: { color: palette.muted, fontSize: 12, marginTop: 3 },
  staffStats: {
    alignSelf: "stretch",
    flexDirection: "row",
    gap: 10,
    marginTop: 17,
  },
  staffStat: {
    flex: 1,
    alignItems: "center",
    backgroundColor: "#F3F7FB",
    borderRadius: 14,
    padding: 13,
  },
  staffStatValue: { color: palette.navy, fontSize: 17, fontWeight: "900" },
  staffStatLabel: { color: palette.muted, fontSize: 9, marginTop: 3 },
  staffChecks: { alignSelf: "stretch", gap: 8 },
  staffCheck: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 12,
    padding: 10,
  },
  staffCheckText: { color: palette.ink, fontSize: 11, fontWeight: "700" },
  staffReview: {
    alignSelf: "stretch",
    borderRadius: 15,
    backgroundColor: "#FFF9EC",
    padding: 14,
  },
  staffReviewStars: { color: "#F2A91B", fontSize: 16, letterSpacing: 2 },
  staffReviewText: {
    color: palette.ink,
    fontSize: 12,
    lineHeight: 18,
    marginTop: 7,
  },
  staffReviewMeta: { color: palette.muted, fontSize: 9, marginTop: 8 },
  groupMembersBody: { padding: 18, paddingBottom: 45 },
  groupPrivacy: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 9,
    backgroundColor: palette.sky,
    borderRadius: 14,
    padding: 12,
    marginBottom: 10,
  },
  groupPrivacyText: {
    flex: 1,
    color: palette.navy,
    fontSize: 9,
    lineHeight: 14,
  },
  groupMemberRow: {
    flexDirection: "row",
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
    paddingVertical: 13,
  },
  groupMemberAvatar: { width: 46, height: 46, borderRadius: 23 },
  darkSafe: { backgroundColor: "#0F1929" },
  darkHeader: { backgroundColor: "#111D30", borderBottomColor: "#30415A" },
  // Web's SVG tint filter can leave the lettering dark; keep the colour mark
  // in its existing overlay and whiten the wordmark with a CSS filter instead.
  brandLogoDark: Platform.OS === "web"
    ? { filter: "brightness(0) invert(1)" }
    : { tintColor: "#F5F8FF" },
  darkContent: { backgroundColor: "#0F1929" },
  darkTabBar: { backgroundColor: "#111D30", borderTopColor: "#30415A" },
  attendingButton: {
    backgroundColor: palette.green,
    flexDirection: "row",
    gap: 7,
  },
  visitDateWrap: { marginTop: 12 },
  visitDateButton: {
    minHeight: 56,
    borderWidth: 1,
    borderColor: "#D7E1ED",
    borderRadius: 11,
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "white",
  },
  visitDateValue: { color: palette.ink, fontSize: 12, fontWeight: "700" },
  visitCalendar: {
    borderWidth: 1,
    borderColor: "#C9D8E8",
    borderTopWidth: 0,
    borderBottomLeftRadius: 14,
    borderBottomRightRadius: 14,
    padding: 11,
    backgroundColor: "white",
  },
  fairPriceCaution: { borderColor: "#F2D388", backgroundColor: "#FFF9E8" },
  priceScaleWrap: { marginTop: 10 },
  priceMarkerRow: { height: 31, marginHorizontal: 8, position: "relative" },
  priceMarker: {
    position: "absolute",
    transform: [{ translateX: -18 }],
    alignItems: "center",
  },
  priceMarkerText: {
    color: palette.navy,
    fontSize: 9,
    fontWeight: "900",
    backgroundColor: "white",
    paddingHorizontal: 5,
    paddingVertical: 2,
    borderRadius: 6,
  },
  priceScale: {
    height: 11,
    borderRadius: 6,
    overflow: "hidden",
    flexDirection: "row",
  },
  priceScaleSegment: { flex: 1 },
  priceLegend: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 5,
  },
  priceLegendText: {
    width: "33.33%",
    color: palette.muted,
    fontSize: 7,
    fontWeight: "800",
    textAlign: "center",
  },
  sellerPayoutCard: {
    borderWidth: 1,
    borderColor: "#A8DDC0",
    borderRadius: 15,
    backgroundColor: "#F1FBF5",
    padding: 13,
    marginTop: 13,
  },
  payoutHead: {
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    marginBottom: 8,
  },
  payoutTitle: { color: "#28754C", fontSize: 13, fontWeight: "900" },
  payoutLine: { flexDirection: "row", alignItems: "center", minHeight: 29 },
  payoutLabel: { flex: 1, color: palette.muted, fontSize: 10 },
  payoutValue: { color: palette.ink, fontSize: 11, fontWeight: "800" },
  payoutFee: { color: palette.coral, fontSize: 11, fontWeight: "800" },
  payoutTotal: {
    flexDirection: "row",
    alignItems: "center",
    borderTopWidth: 1,
    borderTopColor: "#CFE8D9",
    paddingTop: 9,
    marginTop: 4,
  },
  payoutTotalLabel: {
    flex: 1,
    color: palette.navy,
    fontSize: 11,
    fontWeight: "900",
  },
  payoutTotalValue: { color: palette.green, fontSize: 19, fontWeight: "900" },
  payoutHint: { color: palette.muted, fontSize: 8, marginTop: 7 },
  friendMainTabs: { minWidth: "100%" },
  friendNotificationStatus: {
    color: palette.green,
    fontSize: 8,
    fontWeight: "800",
    marginTop: 4,
  },
  followingNotice: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    borderRadius: 14,
    backgroundColor: palette.sky,
    padding: 12,
    marginBottom: 7,
  },
  followingButton: {
    borderWidth: 1,
    borderColor: "#BFD7ED",
    borderRadius: 15,
    paddingVertical: 7,
    paddingHorizontal: 9,
    marginLeft: 7,
  },
  followingButtonText: { color: palette.blue, fontSize: 8, fontWeight: "900" },
  profilePhotoWrap: { width: 90, height: 90, position: "relative" },
  profileAvatarBadge: { position: "absolute", right: 0, bottom: 0, width: 27, height: 27, borderRadius: 14, borderWidth: 3, borderColor: "#FFFFFF", backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" },
  profilePhoto: {
    width: 82,
    height: 82,
    borderRadius: 41,
    backgroundColor: "#EEF2F6",
  },
  profileCamera: {
    position: "absolute",
    right: 1,
    bottom: 5,
    width: 29,
    height: 29,
    borderRadius: 15,
    backgroundColor: palette.blue,
    borderWidth: 2,
    borderColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  profileDisplayName: {
    color: palette.navy,
    fontSize: 22,
    fontWeight: "900",
    marginTop: 8,
  },
  viewProfileButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    borderWidth: 1,
    borderColor: "#BFD7ED",
    backgroundColor: "#F5FAFF",
    borderRadius: 18,
    paddingVertical: 9,
    paddingHorizontal: 13,
    marginTop: 11,
  },
  viewProfileButtonText: {
    color: palette.blue,
    fontSize: 10,
    fontWeight: "900",
  },
  publicProfileBody: { padding: 18, paddingBottom: 45 },
  publicProfileHero: { alignItems: "center", paddingTop: 2, paddingBottom: 5 },
  publicProfilePhotoWrap: { width: 88, height: 88, position: "relative" },
  publicProfilePhoto: {
    width: 88,
    height: 88,
    borderRadius: 44,
    marginRight: 0,
    backgroundColor: "#EEF2F6",
    alignItems: "center",
    justifyContent: "center",
  },
  publicProfileName: {
    color: palette.navy,
    fontSize: 23,
    fontWeight: "900",
    marginTop: 9,
  },
  publicProfileSection: { marginTop: 17 },
  publicProfileSectionTitle: { color: palette.navy, fontSize: 14, fontWeight: "900", marginBottom: 8 },
  publicProfileInterests: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  publicBio: {
    color: palette.ink,
    fontSize: 13,
    lineHeight: 20,
    backgroundColor: "#F6F9FC",
    borderRadius: 14,
    padding: 13,
  },
  profileActivityHead: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  profileActivityCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 11,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 14,
    padding: 10,
    marginBottom: 9,
  },
  profileActivityImage: {
    width: 66,
    height: 57,
    borderRadius: 10,
    backgroundColor: "#EEF2F6",
  },
  editPhotoButton: { alignItems: "center", gap: 8, marginBottom: 8 },
  editPhotoPreview: {
    width: 86,
    height: 86,
    borderRadius: 43,
    backgroundColor: palette.sky,
    alignItems: "center",
    justifyContent: "center",
  },
  usernameStatus: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    marginTop: 5,
  },
  usernameStatusText: { fontSize: 8, fontWeight: "900" },
  interestTagPicker: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 7,
    marginTop: 10,
  },
  interestTagOption: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    borderWidth: 1,
    borderColor: "#CFE0F1",
    borderRadius: 16,
    paddingVertical: 8,
    paddingHorizontal: 11,
    backgroundColor: "white",
  },
  interestTagOptionActive: {
    backgroundColor: palette.blue,
    borderColor: palette.blue,
  },
  interestTagOptionText: {
    color: palette.muted,
    fontSize: 10,
    fontWeight: "800",
  },
  interestTagOptionTextActive: { color: "white" },
  customInterestRow: { flexDirection: "row", gap: 7, marginTop: 11 },
  customInterestInput: {
    flex: 1,
    minHeight: 45,
    borderWidth: 1,
    borderColor: "#D7E1ED",
    borderRadius: 12,
    paddingHorizontal: 12,
    color: palette.ink,
  },
  customInterestAdd: {
    width: 45,
    height: 45,
    borderRadius: 13,
    backgroundColor: palette.blue,
    alignItems: "center",
    justifyContent: "center",
  },
  verificationBody: { padding: 18, paddingBottom: 45 },
  verificationHero: { alignItems: "center", paddingVertical: 8 },
  verificationTick: {
    width: 66,
    height: 66,
    borderRadius: 33,
    backgroundColor: palette.green,
    alignItems: "center",
    justifyContent: "center",
  },
  verificationTitle: {
    color: palette.navy,
    fontSize: 23,
    fontWeight: "900",
    marginTop: 10,
  },
  verificationText: {
    color: palette.muted,
    fontSize: 11,
    lineHeight: 17,
    textAlign: "center",
    marginTop: 6,
    maxWidth: 390,
  },
  verificationChecks: { gap: 8, marginTop: 15 },
  verificationCheck: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 13,
    padding: 10,
  },
  verificationCheckIcon: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: "#ECF9F2",
    alignItems: "center",
    justifyContent: "center",
  },
  verificationPrivacy: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 9,
    backgroundColor: palette.sky,
    borderRadius: 13,
    padding: 12,
    marginTop: 13,
  },
  verificationPrivacyText: {
    flex: 1,
    color: palette.navy,
    fontSize: 9,
    lineHeight: 14,
  },
  secondaryButton: {
    minHeight: 48,
    borderRadius: 13,
    borderWidth: 1,
    borderColor: palette.blue,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 8,
    paddingHorizontal: 14,
    marginTop: 15,
  },
  secondaryButtonText: { color: palette.blue, fontSize: 12, fontWeight: "900", textAlign: "center", flexShrink: 1 },
  verificationStepIntro: {
    backgroundColor: "#F4F8FC",
    borderRadius: 14,
    padding: 13,
  },
  verificationUploadRow: { flexDirection: "row", gap: 9, marginTop: 13 },
  verificationUpload: {
    flex: 1,
    minHeight: 222,
    borderRadius: 14,
    borderWidth: 1.5,
    borderStyle: "dashed",
    borderColor: "#AFCDEB",
    backgroundColor: "#F7FBFF",
    alignItems: "stretch",
    justifyContent: "space-between",
    padding: 8,
    overflow: "hidden",
  },
  verificationUploadDone: { borderStyle: "solid", borderColor: palette.green },
  verificationUploadContent: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 3 },
  verificationUploadVisual: { height: 40, width: 64, alignItems: "center", justifyContent: "center" },
  verificationUploadActions: { width: "100%", gap: 6 },
  verificationCameraOnly: { minHeight: 34, flexDirection: "row", gap: 5, alignItems: "center", justifyContent: "center" },
  verificationCameraOnlyText: { color: palette.muted, fontSize: 9, fontWeight: "700" },
  verificationDemoPanel: { marginTop: 13, padding: 12, borderRadius: 13, borderWidth: 1, borderColor: "#CFE0F3", backgroundColor: "#F4F8FD" },
  verificationDemoTitle: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  verificationDemoText: { color: palette.muted, fontSize: 10, lineHeight: 15, marginTop: 4 },
  verificationDemoOutcomes: { flexDirection: "row", gap: 6, marginTop: 10 },
  verificationDemoOption: { flex: 1, minHeight: 38, borderWidth: 1, borderColor: "#CFE0F3", borderRadius: 10, alignItems: "center", justifyContent: "center", paddingHorizontal: 3, backgroundColor: "#FFFFFF" },
  verificationDemoOptionActive: { borderColor: palette.blue, backgroundColor: "#E5F2FF" },
  verificationDemoOptionText: { color: palette.muted, fontSize: 9, fontWeight: "800", textAlign: "center" },
  verificationDemoOptionTextActive: { color: palette.blue },
  verificationUploadImage: {
    width: 60,
    height: 40,
    borderRadius: 7,
  },
  verificationUploadTitle: {
    color: palette.navy,
    fontSize: 10,
    fontWeight: "900",
    marginTop: 7,
  },
  verificationUploadMeta: { color: palette.muted, fontSize: 8, lineHeight: 11, minHeight: 24, marginTop: 4, textAlign: "center" },
  backToStatus: { alignItems: "center", padding: 13 },
  backToStatusText: { color: palette.blue, fontSize: 10, fontWeight: "800" },
  locationSheet: { padding: 18 },
  currentLocation: {
    borderWidth: 1,
    borderColor: "#CFE3F8",
    backgroundColor: palette.sky,
    borderRadius: 16,
    padding: 15,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  locationIcon: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  currentTitle: { color: palette.navy, fontWeight: "900", fontSize: 15 },
  orText: {
    color: palette.muted,
    fontSize: 10,
    fontWeight: "900",
    textAlign: "center",
    marginVertical: 18,
    letterSpacing: 1,
  },
  manualLocation: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#D7E1ED",
    borderRadius: 13,
    height: 50,
    paddingHorizontal: 12,
  },
  addressResults: { marginTop: 12, gap: 7 },
  addressResultsHead: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 2 },
  addressResultsTitle: { color: palette.navy, fontSize: 11, fontWeight: "900" },
  addressResultsCount: { color: palette.muted, fontSize: 9, fontWeight: "700" },
  addressSuggestion: { minHeight: 62, flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderColor: "#DDE6F0", borderRadius: 13, paddingHorizontal: 11, backgroundColor: "white" },
  addressSuggestionSelected: { borderColor: palette.green, backgroundColor: "#F1FBF5" },
  addressNumber: { width: 34, height: 34, borderRadius: 11, backgroundColor: palette.sky, alignItems: "center", justifyContent: "center" },
  addressSuggestionMain: { color: palette.navy, fontSize: 11, fontWeight: "800" },
  addressSuggestionPostcode: { color: palette.muted, fontSize: 9, marginTop: 3 },
  addressNoResults: { flexDirection: "row", alignItems: "flex-start", gap: 9, padding: 13, borderRadius: 13, backgroundColor: "#F5F7FA" },
  addressNoResultsText: { flex: 1, color: palette.muted, fontSize: 10, lineHeight: 15 },
  quickLocationsTitle: { color: palette.muted, fontSize: 9, fontWeight: "900", textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 4 },
  quickLocations: { marginTop: 13 },
  quickLocation: {
    minHeight: 49,
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
  },
  supportBack: {
    alignSelf: "flex-start",
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    marginBottom: 12,
  },
  supportBackText: { color: palette.blue, fontSize: 10, fontWeight: "900" },
  supportFlowTitle: { color: palette.navy, fontSize: 23, fontWeight: "900" },
  supportFlowSubtitle: {
    color: palette.muted,
    fontSize: 10,
    lineHeight: 15,
    marginTop: 5,
  },
  supportRuleCard: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 9,
    backgroundColor: "#FFF8E7",
    borderWidth: 1,
    borderColor: "#F1DC9E",
    borderRadius: 14,
    padding: 12,
    marginTop: 15,
  },
  supportRuleText: { flex: 1, color: "#785A17", fontSize: 10, lineHeight: 15 },
  supportInfoCard: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 9,
    backgroundColor: palette.sky,
    borderRadius: 14,
    padding: 12,
    marginTop: 15,
  },
  supportInfoText: {
    flex: 1,
    color: palette.navy,
    fontSize: 10,
    lineHeight: 15,
  },
  supportChoiceGrid: { flexDirection: "row", gap: 7 },
  supportChoice: {
    flex: 1,
    minHeight: 76,
    borderWidth: 1,
    borderColor: "#D7E1ED",
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingHorizontal: 5,
  },
  supportChoiceActive: {
    borderColor: palette.blue,
    backgroundColor: "#F2F8FE",
  },
  supportChoiceText: {
    color: palette.muted,
    fontSize: 9,
    fontWeight: "800",
    textAlign: "center",
  },
  supportChoiceTextActive: { color: palette.navy },
  supportReasonWrap: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  supportReasonChip: {
    borderWidth: 1,
    borderColor: "#D7E1ED",
    borderRadius: 16,
    paddingVertical: 8,
    paddingHorizontal: 11,
    backgroundColor: "white",
  },
  supportReasonChipActive: {
    borderColor: palette.blue,
    backgroundColor: palette.sky,
  },
  supportReasonText: { color: palette.muted, fontSize: 9, fontWeight: "800" },
  supportReasonTextActive: { color: palette.blue },
  supportEvidence: {
    minHeight: 48,
    borderWidth: 1,
    borderStyle: "dashed",
    borderColor: "#AFCDEB",
    borderRadius: 13,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 12,
    marginTop: 12,
  },
  supportEvidenceText: {
    flex: 1,
    color: palette.blue,
    fontSize: 10,
    fontWeight: "800",
  },
  supportAcknowledge: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 9,
    marginTop: 14,
  },
  supportAcknowledgeText: {
    flex: 1,
    color: palette.muted,
    fontSize: 9,
    lineHeight: 14,
  },
  botIdentity: {
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    marginBottom: 2,
  },
  botIcon: {
    width: 38,
    height: 38,
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: palette.blue,
  },
  botName: { color: palette.navy, fontSize: 13, fontWeight: "900" },
  botMeta: { color: palette.muted, fontSize: 9, marginTop: 2 },
  faqGrid: { gap: 7 },
  faqButton: {
    minHeight: 45,
    borderWidth: 1,
    borderColor: "#CFE0F1",
    borderRadius: 13,
    backgroundColor: "white",
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
  },
  faqButtonText: {
    flex: 1,
    color: palette.navy,
    fontSize: 10,
    fontWeight: "800",
  },
  technicianButton: {
    minHeight: 48,
    borderRadius: 13,
    backgroundColor: palette.blue,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
  },
  technicianButtonText: { color: "white", fontSize: 11, fontWeight: "900" },
  technicianStatus: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 9,
    backgroundColor: "#ECF9F2",
    borderRadius: 14,
    padding: 12,
  },
  technicianStatusTitle: { color: "#236E47", fontSize: 11, fontWeight: "900" },
  technicianStatusText: {
    color: "#4B765E",
    fontSize: 9,
    lineHeight: 14,
    marginTop: 3,
  },
  lostModeRow: { flexDirection: "row", gap: 8 },
  lostModeButton: {
    flex: 1,
    minHeight: 48,
    borderRadius: 13,
    borderWidth: 1,
    borderColor: "#BFD7ED",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    backgroundColor: "white",
  },
  lostModeButtonActive: {
    backgroundColor: palette.blue,
    borderColor: palette.blue,
  },
  lostModeText: { color: palette.blue, fontSize: 9, fontWeight: "900" },
  lostModeTextActive: { color: "white" },
  lostPhotoCard: { borderWidth: 1, borderColor: "#D8E5F1", borderRadius: 15, padding: 12, backgroundColor: "white" },
  lostPhotoHead: { flexDirection: "row", alignItems: "flex-start", gap: 9 },
  lostPhotoIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: palette.sky, alignItems: "center", justifyContent: "center" },
  lostPhotoCount: { color: palette.blue, fontSize: 10, fontWeight: "900" },
  lostClaimCard: {
    alignItems: "center",
    backgroundColor: "#ECF9F2",
    borderRadius: 16,
    padding: 20,
  },
  lostClaimTitle: {
    color: "#236E47",
    fontSize: 16,
    fontWeight: "900",
    marginTop: 7,
  },
  lostClaimReference: {
    color: palette.navy,
    fontSize: 19,
    fontWeight: "900",
    letterSpacing: 1,
    marginTop: 6,
  },
  lostClaimText: {
    color: "#4B765E",
    fontSize: 9,
    lineHeight: 14,
    textAlign: "center",
    marginTop: 5,
  },
  universitySearchWrap: { marginTop: 4, zIndex: 5 },
  universitySearchField: { minHeight: 54, flexDirection: "row", alignItems: "center", gap: 8, borderWidth: 1, borderColor: "#D5E1ED", borderRadius: 13, paddingHorizontal: 12, backgroundColor: "white" },
  universitySearchFieldActive: { borderColor: palette.blue, borderBottomLeftRadius: 7, borderBottomRightRadius: 7 },
  universitySearchInput: { flex: 1, color: palette.ink, fontSize: 12, fontWeight: "700" },
  universitySuggestions: { borderWidth: 1, borderColor: "#D5E1ED", borderTopWidth: 0, borderBottomLeftRadius: 13, borderBottomRightRadius: 13, backgroundColor: "white", overflow: "hidden" },
  universitySuggestion: { minHeight: 51, flexDirection: "row", alignItems: "center", gap: 9, paddingHorizontal: 11, borderTopWidth: 1, borderTopColor: "#EDF1F6" },
  universitySuggestionSelected: { backgroundColor: "#F1FBF5" },
  universitySuggestionIcon: { width: 31, height: 31, borderRadius: 10, backgroundColor: palette.sky, alignItems: "center", justifyContent: "center" },
  universitySuggestionText: { flex: 1, color: palette.navy, fontSize: 10, fontWeight: "800" },
  universityEmpty: { padding: 13, backgroundColor: "#F7F9FC" },
  universityEmptyText: { color: palette.muted, fontSize: 10, lineHeight: 15 },
  usernameLockedField: { backgroundColor: "#F3F5F8", opacity: 0.82 },
  usernamePolicy: { flexDirection: "row", alignItems: "flex-start", gap: 8, padding: 11, borderRadius: 12, backgroundColor: palette.sky, marginTop: 8 },
  usernamePolicyText: { flex: 1, color: palette.navy, fontSize: 9, lineHeight: 14 },
  interestSuggestions: { marginTop: 8, borderRadius: 12, borderWidth: 1, borderColor: "#DCE6F0", backgroundColor: "white", padding: 8, gap: 4 },
  interestSuggestionsLabel: { color: palette.muted, fontSize: 8, fontWeight: "900", textTransform: "uppercase", letterSpacing: 0.7, marginBottom: 2 },
  interestSuggestion: { minHeight: 36, flexDirection: "row", alignItems: "center", gap: 7, borderRadius: 9, paddingHorizontal: 7, backgroundColor: "#F7FAFD" },
  interestSuggestionText: { color: palette.navy, fontSize: 10, fontWeight: "800" },
  bookingDetailSheet: { padding: 18, paddingBottom: 40 },
  bookingDetailHero: { flexDirection: "row", alignItems: "center", gap: 11, padding: 14, borderRadius: 16, backgroundColor: "#F7FAFD", borderWidth: 1, borderColor: "#DDE7F1" },
  bookingDetailHeroIcon: { width: 50, height: 50, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  bookingDetailType: { color: palette.muted, fontSize: 8, fontWeight: "900", textTransform: "uppercase", letterSpacing: 0.7 },
  bookingDetailTitle: { color: palette.navy, fontSize: 16, fontWeight: "900", marginTop: 3 },
  bookingDetailStatus: { color: palette.green, fontSize: 9, fontWeight: "800", marginTop: 3 },
  bookingDetailPrice: { color: palette.navy, fontSize: 18, fontWeight: "900" },
  bookingDetailFacts: { gap: 8, marginTop: 14 },
  bookingDetailFact: { minHeight: 58, flexDirection: "row", alignItems: "flex-start", gap: 10, padding: 12, borderWidth: 1, borderColor: "#E0E7EF", borderRadius: 13, backgroundColor: "white" },
  bookingReferenceCard: { flexDirection: "row", alignItems: "flex-start", gap: 9, backgroundColor: "#ECF9F2", borderRadius: 13, padding: 12, marginTop: 14 },
  bookingReferenceText: { flex: 1, color: "#347253", fontSize: 9, lineHeight: 14 },
  eventDateField: { marginTop: 8 },
  eventTimeField: { marginTop: 8 },
  eventDateButton: { minHeight: 62, flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderColor: "#D7E1ED", borderRadius: 13, paddingHorizontal: 11, backgroundColor: "white" },
  eventDateButtonOpen: { borderColor: palette.blue },
  eventScheduleIcon: { width: 34, height: 34, borderRadius: 10, backgroundColor: palette.sky, alignItems: "center", justifyContent: "center" },
  eventDateButtonCopy: { flex: 1, justifyContent: "center" },
  eventScheduleLabel: { color: palette.muted, fontSize: 10, fontWeight: "800", marginBottom: 3 },
  eventDateButtonText: { color: palette.navy, fontSize: 13, fontWeight: "800" },
  eventTimeValue: { color: palette.navy, fontSize: 14, fontWeight: "900", fontVariant: ["tabular-nums"] },
  eventTimeFormat: { color: palette.blue, fontSize: 8, fontWeight: "900", backgroundColor: palette.sky, borderRadius: 7, paddingHorizontal: 6, paddingVertical: 3 },
  eventCalendarPanel: { marginTop: 6, borderWidth: 1, borderColor: palette.line, borderRadius: 13, padding: 12, backgroundColor: "white" },
  eventCalendarPickerLabel: { color: palette.muted, fontSize: 8, fontWeight: "900", textTransform: "uppercase", letterSpacing: 0.7, marginTop: 5, marginBottom: 6 },
  eventCalendarChoiceRow: { gap: 6, paddingRight: 8 },
  eventCalendarChoice: { minHeight: 32, minWidth: 48, borderWidth: 1, borderColor: "#D6E1ED", borderRadius: 10, alignItems: "center", justifyContent: "center", paddingHorizontal: 8, backgroundColor: "white" },
  eventCalendarChoiceActive: { backgroundColor: palette.blue, borderColor: palette.blue },
  eventCalendarChoiceDisabled: { backgroundColor: "#F1F3F6", borderColor: "#E4E8ED" },
  eventCalendarChoiceText: { color: palette.muted, fontSize: 9, fontWeight: "800" },
  eventCalendarChoiceTextActive: { color: "white" },
  eventTimePanel: { marginTop: 6, borderWidth: 1, borderColor: palette.line, borderRadius: 13, padding: 12, backgroundColor: "white" },
  eventTimeChoice: { width: 42, height: 34, borderWidth: 1, borderColor: "#D6E1ED", borderRadius: 9, alignItems: "center", justifyContent: "center", backgroundColor: "white" },
  eventCalendarWindowNote: { flexDirection: "row", alignItems: "center", gap: 7, backgroundColor: palette.sky, borderRadius: 10, padding: 9, marginBottom: 8 },
  eventCalendarWindowText: { flex: 1, color: palette.navy, fontSize: 9, fontWeight: "700" },
  eventCalendarYearRow: { flexDirection: "row", gap: 8 },
  eventCalendarYearChoice: { flex: 1 },
  eventCalendarMonthGrid: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  eventCalendarMonthChoice: { width: "23%", minHeight: 34, borderWidth: 1, borderColor: "#D6E1ED", borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "white" },
  eventCalendarDivider: { height: 1, backgroundColor: palette.line, marginVertical: 12 },
  eventTimeHeader: { alignItems: "center", marginBottom: 10 },
  eventTimePanelTitle: { color: palette.navy, fontSize: 13, fontWeight: "900" },
  eventTimePanelHint: { color: palette.muted, fontSize: 8, marginTop: 2 },
  eventTimeStepperRow: { flexDirection: "row", alignItems: "flex-end", gap: 9 },
  eventTimeSegment: { flex: 1 },
  eventTimeSegmentLabel: { color: palette.muted, fontSize: 8, fontWeight: "900", textAlign: "center", textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 5 },
  eventTimeStepper: { minHeight: 52, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderWidth: 1, borderColor: "#D6E1ED", borderRadius: 13, padding: 5, backgroundColor: "#F8FBFE" },
  eventTimeStepButton: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "white", borderWidth: 1, borderColor: "#D5E5F4" },
  eventTimeStepValue: { color: palette.navy, fontSize: 20, fontWeight: "900", fontVariant: ["tabular-nums"] },
  eventTimeColon: { color: palette.navy, fontSize: 24, fontWeight: "900", paddingBottom: 12 },
  eventTimeDone: { minHeight: 40, borderRadius: 11, backgroundColor: palette.blue, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, marginTop: 10 },
  eventTimeDoneText: { color: "white", fontSize: 10, fontWeight: "900" },
  technicianJoinedNotice: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, marginVertical: 5 },
  technicianJoinedNoticeText: { color: "#347253", fontSize: 10, fontWeight: "900" },
  technicianIdentity: { minHeight: 66, flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderColor: "#B9E3CB", borderRadius: 15, padding: 10, backgroundColor: "#F2FBF6" },
  technicianPhoto: { width: 44, height: 44, borderRadius: 22, backgroundColor: "#DCE5EF" },
  technicianNameRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  technicianName: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  technicianVerifiedPill: { flexDirection: "row", alignItems: "center", gap: 3, borderRadius: 9, backgroundColor: "#DDF5E7", paddingHorizontal: 6, paddingVertical: 3 },
  technicianVerifiedText: { color: "#28754C", fontSize: 7, fontWeight: "900" },
  technicianRole: { color: palette.muted, fontSize: 9, marginTop: 4 },
  technicianMessageRow: { flexDirection: "row", alignItems: "flex-start", gap: 8, marginTop: 2 },
  technicianMessagePhoto: { width: 32, height: 32, borderRadius: 16, backgroundColor: "#DCE5EF" },
  technicianMessageAuthor: { color: palette.navy, fontSize: 9, fontWeight: "900", marginBottom: 4 },
  technicianMessageBubble: { alignSelf: "flex-start", backgroundColor: "white", borderRadius: 15, borderTopLeftRadius: 4, padding: 12, maxWidth: 360, shadowColor: "#17365E", shadowOpacity: 0.06, shadowRadius: 7 },
  endSupportSessionButton: { minHeight: 62, flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderColor: "#BFD7ED", borderRadius: 15, backgroundColor: "#F8FBFE", paddingHorizontal: 13, marginTop: 8 },
  endSupportSessionTitle: { color: palette.navy, fontSize: 11, fontWeight: "900" },
  endSupportSessionText: { color: palette.muted, fontSize: 8, lineHeight: 12, marginTop: 2 },
  technicianRatingCard: { borderWidth: 1, borderColor: "#D7E4F1", borderRadius: 18, backgroundColor: "white", padding: 15, marginTop: 9 },
  technicianRatingHead: { flexDirection: "row", alignItems: "center", gap: 10 },
  technicianRatingIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#FFF5D9", alignItems: "center", justifyContent: "center" },
  technicianRatingTitle: { color: palette.navy, fontSize: 13, fontWeight: "900" },
  technicianRatingSubtitle: { color: palette.muted, fontSize: 9, lineHeight: 13, marginTop: 3 },
  technicianStars: { flexDirection: "row", justifyContent: "space-between", gap: 7, marginTop: 14 },
  technicianStarButton: { flex: 1, minHeight: 48, borderRadius: 13, borderWidth: 1, borderColor: "#DCE5EF", backgroundColor: "#F8FAFC", alignItems: "center", justifyContent: "center" },
  technicianStarButtonActive: { borderColor: "#E7B439", backgroundColor: "#FFF8DF" },
  technicianNoReviewNote: { flexDirection: "row", alignItems: "flex-start", gap: 7, borderRadius: 11, backgroundColor: palette.sky, padding: 9, marginTop: 12 },
  technicianNoReviewText: { flex: 1, color: palette.navy, fontSize: 8, lineHeight: 12 },
  submitTechnicianRating: { minHeight: 44, borderRadius: 12, backgroundColor: palette.blue, alignItems: "center", justifyContent: "center", marginTop: 11 },
  submitTechnicianRatingText: { color: "white", fontSize: 10, fontWeight: "900" },
  technicianRatingThanks: { flexDirection: "row", alignItems: "flex-start", gap: 10, borderWidth: 1, borderColor: "#B9E3CB", borderRadius: 15, backgroundColor: "#F2FBF6", padding: 13, marginTop: 9 },
  technicianRatingThanksIcon: { width: 34, height: 34, borderRadius: 17, backgroundColor: palette.green, alignItems: "center", justifyContent: "center" },
  technicianRatingThanksTitle: { color: "#236E47", fontSize: 11, fontWeight: "900" },
  technicianRatingThanksText: { color: "#4B765E", fontSize: 9, lineHeight: 14, marginTop: 3 },
  technicianFeedbackPolicy: { flexDirection: "row", alignItems: "flex-start", gap: 10, borderWidth: 1, borderColor: "#CFE0F1", borderRadius: 15, backgroundColor: "#F7FBFF", padding: 13, marginTop: 15 },
  technicianFeedbackPolicyTitle: { color: palette.navy, fontSize: 11, fontWeight: "900" },
  technicianFeedbackPolicyText: { color: palette.muted, fontSize: 9, lineHeight: 14, marginTop: 3 },
  ticketPaymentBody: { padding: 18, paddingBottom: 42 },
  ticketCheckoutHeader: { alignItems: "center", marginBottom: 16 },
  ticketPaymentEvent: { flexDirection: "row", alignItems: "center", gap: 11, borderRadius: 15, borderWidth: 1, borderColor: "#DCE6F0", padding: 11, backgroundColor: "white" },
  ticketPaymentThumb: { width: 74, height: 58, borderRadius: 10 },
  ticketPaymentEventTitle: { color: palette.navy, fontSize: 13, fontWeight: "900" },
  ticketPaymentMeta: { color: palette.muted, fontSize: 9, marginTop: 3 },
  ticketOrderSummary: { marginTop: 13, borderRadius: 15, borderWidth: 1, borderColor: "#DCE6F0", padding: 13, backgroundColor: "#F8FBFE" },
  ticketOrderLine: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 7 },
  ticketOrderLineText: { color: palette.muted, fontSize: 10, fontWeight: "700" },
  ticketOrderLinePrice: { color: palette.navy, fontSize: 10, fontWeight: "900" },
  ticketOrderTotal: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderTopWidth: 1, borderTopColor: palette.line, paddingTop: 11, marginTop: 5 },
  ticketOrderTotalLabel: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  ticketOrderTotalValue: { color: palette.navy, fontSize: 19, fontWeight: "900" },
  ticketCompletePage: { flex: 1, alignItems: "center", justifyContent: "center", padding: 28 },
  ticketCompleteIcon: { width: 76, height: 76, borderRadius: 38, backgroundColor: palette.green, alignItems: "center", justifyContent: "center" },
  ticketCompleteTitle: { color: palette.navy, fontSize: 24, fontWeight: "900", marginTop: 15 },
  ticketCompleteText: { color: palette.muted, fontSize: 11, lineHeight: 17, textAlign: "center", maxWidth: 360, marginTop: 7 },
  openGroupChatButton: { width: "100%", minHeight: 51, borderRadius: 13, backgroundColor: palette.green, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, marginTop: 19 },
  eventShareSheet: { padding: 18, paddingBottom: 40 },
  eventSharePreview: { flexDirection: "row", alignItems: "center", gap: 10, borderRadius: 15, backgroundColor: "#F7FAFD", borderWidth: 1, borderColor: "#DEE7F0", padding: 10 },
  eventShareImage: { width: 72, height: 58, borderRadius: 10 },
  eventShareTitle: { color: palette.navy, fontSize: 13, fontWeight: "900" },
  eventShareMeta: { color: palette.muted, fontSize: 9, marginTop: 4 },
  eventShareLinkCard: { flexDirection: "row", alignItems: "center", gap: 8, borderWidth: 1, borderColor: "#D9E5F0", borderRadius: 13, padding: 7, marginTop: 12 },
  eventShareLinkCopy: { flex: 1, flexDirection: "row", alignItems: "center", gap: 7, paddingLeft: 5 },
  eventShareLinkText: { flex: 1, color: palette.muted, fontSize: 9 },
  eventShareCopyButton: { minHeight: 37, borderRadius: 10, backgroundColor: palette.blue, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, paddingHorizontal: 10 },
  eventShareCopyText: { color: "white", fontSize: 9, fontWeight: "900" },
  eventShareNativeButton: { minHeight: 48, borderRadius: 13, backgroundColor: palette.blue, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, marginTop: 10 },
  eventShareFriends: { gap: 7, marginTop: 8 },
  eventShareFriendRow: { minHeight: 62, flexDirection: "row", alignItems: "center", gap: 10, borderBottomWidth: 1, borderBottomColor: palette.line, paddingVertical: 7 },
  eventShareSendButton: { minWidth: 68, height: 34, borderRadius: 17, alignItems: "center", justifyContent: "center", backgroundColor: palette.blue },
  eventShareSentButton: { backgroundColor: "#E8F7EF" },
  eventShareSendText: { color: "white", fontSize: 9, fontWeight: "900" },
  eventShareSentText: { color: palette.green },
  eventViewTabs: {
    flexDirection: "row",
    gap: 6,
    backgroundColor: "#EEF3F8",
    borderRadius: 14,
    padding: 4,
    marginTop: 14,
    marginBottom: 13,
  },
  eventViewTab: {
    flex: 1,
    minHeight: 40,
    borderRadius: 11,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
  eventViewTabActive: { backgroundColor: palette.blue },
  eventViewTabText: {
    color: palette.muted,
    fontSize: 10,
    fontWeight: "900",
  },
  eventViewTabTextActive: { color: "white" },
  goingStatusRow: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 8, marginTop: 4 },
  goingStatusText: { color: palette.green, fontSize: 11, fontWeight: "900" },
  goingPendingNote: { flexDirection: "row", alignItems: "center", gap: 9, borderWidth: 1, borderColor: palette.line, borderRadius: 13, padding: 13, marginTop: 14 },
  largeEventAttachmentRow: { flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderColor: palette.line, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 9, marginTop: 8 },
  myEventsSubtitle: {
    color: palette.muted,
    fontSize: 9,
    lineHeight: 14,
    marginTop: 4,
    maxWidth: 290,
  },
  myEventsSummary: {
    flexDirection: "row",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#D9E7F2",
    backgroundColor: palette.sky,
    paddingVertical: 13,
    marginBottom: 13,
  },
  myEventsSummaryItem: { flex: 1, alignItems: "center" },
  myEventsSummaryValue: {
    color: palette.navy,
    fontSize: 19,
    fontWeight: "900",
  },
  myEventsSummaryLabel: {
    color: palette.muted,
    fontSize: 8,
    fontWeight: "800",
    marginTop: 3,
  },
  myEventManageCard: {
    borderWidth: 1,
    borderColor: "#DCE6F0",
    borderRadius: 18,
    backgroundColor: "white",
    padding: 13,
    shadowColor: "#17365E",
    shadowOpacity: 0.07,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
  },
  myEventManageImage: { width: "100%", height: 155, borderRadius: 13 },
  myEventStatusRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 11,
  },
  myEventLivePill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: "#EAF8F0",
    borderRadius: 12,
    paddingVertical: 5,
    paddingHorizontal: 8,
  },
  myEventLiveText: { color: "#28764C", fontSize: 8, fontWeight: "900" },
  myEventReference: { color: palette.muted, fontSize: 8, fontWeight: "800" },
  myEventManageTitle: {
    color: palette.navy,
    fontSize: 17,
    fontWeight: "900",
    marginTop: 10,
  },
  myEventManageMeta: { color: palette.muted, fontSize: 9, marginTop: 4 },
  myEventProgressTrack: {
    height: 7,
    borderRadius: 4,
    backgroundColor: "#E5EDF5",
    overflow: "hidden",
    marginTop: 14,
  },
  myEventProgressFill: {
    width: "24%",
    height: "100%",
    borderRadius: 4,
    backgroundColor: palette.green,
  },
  myEventCapacityLine: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 6,
  },
  myEventCapacityText: { color: palette.muted, fontSize: 8, fontWeight: "800" },
  myEventActions: { flexDirection: "row", gap: 8, marginTop: 14 },
  myEventSecondaryAction: {
    flex: 1,
    minHeight: 44,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: palette.blue,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
  myEventSecondaryActionText: {
    color: palette.blue,
    fontSize: 9,
    fontWeight: "900",
  },
  myEventPrimaryAction: {
    flex: 1,
    minHeight: 44,
    borderRadius: 12,
    backgroundColor: palette.blue,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
  },
  myEventPrimaryActionText: { color: "white", fontSize: 9, fontWeight: "900" },
  myEventChatLink: {
    minHeight: 42,
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    borderTopWidth: 1,
    borderTopColor: palette.line,
    marginTop: 12,
    paddingTop: 10,
  },
  myEventChatLinkText: { flex: 1, color: palette.blue, fontSize: 9, fontWeight: "900" },
  cancelEventButton: { minHeight: 42, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, borderTopWidth: 1, borderTopColor: "#F1D3D5", marginTop: 2, paddingTop: 10 },
  cancelEventButtonText: { color: palette.coral, fontSize: 9, fontWeight: "900" },
  cancelledEventNotice: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 12, backgroundColor: "#FFF4F5", padding: 10, marginTop: 11 },
  cancelledEventNoticeText: { flex: 1, color: "#8B4047", fontSize: 9, lineHeight: 14 },
  eventRefundCard: { borderWidth: 1, borderColor: "#CBE8D7", borderRadius: 14, backgroundColor: "#F2FBF6", padding: 11, marginTop: 10 },
  eventRefundHead: { flexDirection: "row", alignItems: "center", gap: 9 },
  eventRefundIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: "white", alignItems: "center", justifyContent: "center" },
  eventRefundTitle: { color: "#276B47", fontSize: 10, fontWeight: "900" },
  eventRefundMeta: { color: "#4D7A61", fontSize: 8, marginTop: 2 },
  eventRefundAmount: { color: palette.navy, fontSize: 15, fontWeight: "900" },
  eventRefundFacts: { flexDirection: "row", justifyContent: "space-between", borderTopWidth: 1, borderTopColor: "#D5EADF", marginTop: 9, paddingTop: 8 },
  eventRefundFact: { color: "#4D7A61", fontSize: 8, fontWeight: "800" },
  myEventStateCard: { borderWidth: 1, borderColor: "#DCE6F0", borderRadius: 17, backgroundColor: "white", padding: 13, marginTop: 12 },
  myEventStateHead: { flexDirection: "row", alignItems: "center", gap: 10 },
  myEventStateIcon: { width: 42, height: 42, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  myEventStateTitle: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  myEventStateMeta: { color: palette.muted, fontSize: 8, marginTop: 3 },
  myEventPendingPill: { borderRadius: 11, backgroundColor: "#FFF5D9", paddingVertical: 6, paddingHorizontal: 8 },
  myEventPendingText: { color: "#9A680D", fontSize: 7, fontWeight: "900" },
  myEventDeclinedPill: { borderRadius: 11, backgroundColor: "#FFF0F1", paddingVertical: 6, paddingHorizontal: 8 },
  myEventDeclinedText: { color: palette.coral, fontSize: 7, fontWeight: "900" },
  myEventReviewNotice: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 12, backgroundColor: "#FFFAEC", padding: 10, marginTop: 11 },
  myEventDeclinedNotice: { backgroundColor: "#FFF5F5" },
  myEventReviewText: { flex: 1, color: palette.muted, fontSize: 9, lineHeight: 14 },
  myEventStatusAction: { minHeight: 42, borderRadius: 11, borderWidth: 1, borderColor: palette.blue, alignItems: "center", justifyContent: "center", marginTop: 10 },
  myEventStatusActionText: { color: palette.blue, fontSize: 9, fontWeight: "900" },
  eventEditBody: { padding: 18, paddingBottom: 42 },
  eventEditAnnouncementNotice: { flexDirection: "row", alignItems: "flex-start", gap: 9, borderRadius: 14, backgroundColor: palette.sky, padding: 12, marginBottom: 4 },
  eventEditAnnouncementText: { flex: 1, color: palette.navy, fontSize: 9, lineHeight: 14 },
  organiserAnnouncement: { borderWidth: 1, borderColor: "#BBD9F5", borderRadius: 15, backgroundColor: "#F2F8FE", padding: 12, marginBottom: 10 },
  organiserAnnouncementHead: { flexDirection: "row", alignItems: "center", gap: 9 },
  organiserAnnouncementIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: palette.blue, alignItems: "center", justifyContent: "center" },
  organiserAnnouncementTitle: { color: palette.navy, fontSize: 10, fontWeight: "900" },
  organiserAnnouncementTime: { color: palette.muted, fontSize: 8, marginTop: 2 },
  organiserAnnouncementText: { color: palette.ink, fontSize: 10, lineHeight: 16, marginTop: 9 },
  organiserAnnouncementDelivery: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: 9 },
  organiserAnnouncementDeliveryText: { color: palette.green, fontSize: 8, fontWeight: "800" },
  approvalNotificationNote: {
    width: "100%",
    maxWidth: 450,
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 9,
    backgroundColor: palette.sky,
    borderRadius: 14,
    padding: 12,
    marginTop: 13,
  },
  approvalNotificationText: {
    flex: 1,
    color: palette.navy,
    fontSize: 10,
    lineHeight: 15,
  },
  eventCapacityField: {
    marginTop: 12,
    borderWidth: 1,
    borderColor: "#D7E1ED",
    borderRadius: 15,
    padding: 13,
    backgroundColor: "white",
  },
  eventCapacityHead: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  eventCapacityIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: palette.sky,
    alignItems: "center",
    justifyContent: "center",
  },
  eventCapacityHint: { color: palette.muted, fontSize: 9, marginTop: 3 },
  eventCapacityControl: {
    minHeight: 62,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "#F6F9FC",
    borderRadius: 14,
    padding: 7,
    marginTop: 12,
  },
  eventCapacityButton: {
    width: 46,
    height: 46,
    borderRadius: 12,
    backgroundColor: "white",
    borderWidth: 1,
    borderColor: "#D3E2F0",
    alignItems: "center",
    justifyContent: "center",
  },
  eventCapacityButtonDisabled: {
    backgroundColor: "#EDF1F5",
    borderColor: "#E0E6EC",
  },
  eventCapacityValueWrap: { flex: 1, alignItems: "center", justifyContent: "center" },
  eventCapacityValue: {
    color: palette.navy,
    fontSize: 23,
    fontWeight: "900",
    fontVariant: ["tabular-nums"],
  },
  eventCapacityUnit: {
    color: palette.muted,
    fontSize: 8,
    fontWeight: "800",
    textTransform: "uppercase",
  },
  eventCapacityPresets: { flexDirection: "row", gap: 7, marginTop: 9 },
  eventCapacityPreset: {
    flex: 1,
    minHeight: 34,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#D6E1ED",
    alignItems: "center",
    justifyContent: "center",
  },
  eventCapacityPresetActive: {
    backgroundColor: palette.blue,
    borderColor: palette.blue,
  },
  eventCapacityPresetText: {
    color: palette.muted,
    fontSize: 10,
    fontWeight: "900",
  },
  eventCapacityPresetTextActive: { color: "white" },
  eventCapacityPolicy: { flexDirection: "row", alignItems: "flex-start", gap: 7, backgroundColor: palette.sky, borderRadius: 11, padding: 9, marginTop: 9 },
  eventCapacityPolicyText: { flex: 1, color: palette.navy, fontSize: 8, lineHeight: 13 },
  profileAudienceTabs: {
    flexDirection: "row",
    gap: 6,
    backgroundColor: "#F0F4F8",
    borderRadius: 14,
    padding: 4,
    marginTop: 12,
  },
  profileAudienceTab: {
    flex: 1,
    minHeight: 38,
    borderRadius: 11,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
  profileAudienceTabActive: { backgroundColor: palette.blue },
  profileAudienceText: {
    color: palette.muted,
    fontSize: 10,
    fontWeight: "900",
  },
  profileAudienceTextActive: { color: "white" },
  profileSocialStats: {
    flexDirection: "row",
    borderWidth: 1,
    borderColor: "#DEE7F0",
    borderRadius: 15,
    backgroundColor: "white",
    marginTop: 12,
    overflow: "hidden",
  },
  profileSocialStat: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 13,
  },
  profileSocialStatValue: {
    color: palette.navy,
    fontSize: 16,
    fontWeight: "900",
  },
  profileSocialStatLabel: {
    color: palette.muted,
    fontSize: 8,
    fontWeight: "800",
    marginTop: 3,
  },
  profileConnectionsCard: {
    borderWidth: 1,
    borderColor: "#CFE5D8",
    borderRadius: 15,
    backgroundColor: "#F4FBF7",
    padding: 13,
    marginTop: 10,
  },
  profileConnectionsHead: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 10,
  },
  profileConnectionsTitle: {
    color: palette.navy,
    fontSize: 12,
    fontWeight: "900",
  },
  profileConnectionsText: {
    color: palette.muted,
    fontSize: 9,
    lineHeight: 14,
    marginTop: 3,
  },
  profileConnectionFaces: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 11,
  },
  profileConnectionAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: "white",
  },
  profileConnectionNames: {
    color: palette.navy,
    fontSize: 9,
    fontWeight: "800",
    marginLeft: 9,
  },
  profileConnectionLink: {
    minHeight: 39,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderTopWidth: 1,
    borderTopColor: "#D8EAE0",
    marginTop: 10,
    paddingTop: 9,
  },
  profileConnectionLinkText: {
    color: palette.blue,
    fontSize: 9,
    fontWeight: "900",
  },
  profileConnectionsLocked: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    backgroundColor: "#F3F6F9",
    borderRadius: 13,
    padding: 11,
    marginTop: 10,
  },
  profileConnectionsLockedText: {
    flex: 1,
    color: palette.muted,
    fontSize: 9,
    lineHeight: 14,
  },
  blockedPeopleBody: { padding: 18, paddingBottom: 40 },
  blockedPersonRow: {
    minHeight: 72,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
  },
  unblockButton: {
    minHeight: 35,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: palette.blue,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 12,
  },
  unblockButtonText: { color: palette.blue, fontSize: 9, fontWeight: "900" },
  settingsBody: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 54,
  },
  listingSummaryCard: {
    flexDirection: "row",
    justifyContent: "space-around",
    borderRadius: 16,
    backgroundColor: palette.sky,
    padding: 16,
    marginBottom: 11,
  },
  listingSummaryValue: {
    color: palette.navy,
    fontSize: 21,
    fontWeight: "900",
    textAlign: "center",
  },
  listingSummaryLabel: {
    color: palette.muted,
    fontSize: 9,
    fontWeight: "800",
    marginTop: 3,
  },
  profileListingRow: {
    minHeight: 70,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
  },
  profileListingIcon: {
    width: 42,
    height: 42,
    borderRadius: 13,
    backgroundColor: palette.sky,
    alignItems: "center",
    justifyContent: "center",
  },
  profileListingPrice: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  settingsSectionLabel: {
    color: palette.muted,
    fontSize: 10,
    fontWeight: "900",
    textTransform: "uppercase",
    letterSpacing: 1,
    marginTop: 24,
    marginBottom: 10,
  },
  settingsFirstSectionLabel: { marginTop: 2 },
  settingsCard: {
    borderWidth: 1,
    borderColor: "#DEE6EF",
    borderRadius: 18,
    backgroundColor: "white",
    overflow: "hidden",
    shadowColor: "#0A3266",
    shadowOpacity: 0.04,
    shadowRadius: 10,
  },
  settingsRow: {
    minHeight: 78,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 15,
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
  },
  settingsIcon: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: palette.sky,
    alignItems: "center",
    justifyContent: "center",
  },
  settingsRowTitle: { color: palette.navy, fontSize: 12, fontWeight: "900" },
  settingsRowText: {
    color: palette.muted,
    fontSize: 10,
    lineHeight: 15,
    marginTop: 4,
  },
  settingsLanguageRow: { flexDirection: "row", gap: 9 },
  settingsLanguageButton: {
    flex: 1,
    minHeight: 52,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: "#D9E3ED",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 5,
  },
  settingsLanguageButtonActive: {
    backgroundColor: palette.blue,
    borderColor: palette.blue,
  },
  settingsLanguageText: {
    color: palette.muted,
    fontSize: 10,
    fontWeight: "900",
  },
  settingsLanguageTextActive: { color: "white" },
  settingsPrivacyLink: {
    minHeight: 132,
    flexDirection: "row",
    alignItems: "center",
    gap: 13,
    borderWidth: 1,
    borderColor: "#BDD9F5",
    borderRadius: 20,
    padding: 16,
    backgroundColor: "#F2F8FF",
  },
  settingsPrivacyIcon: {
    width: 52,
    height: 52,
    borderRadius: 17,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#0B6FC8",
    shadowOpacity: 0.08,
    shadowRadius: 8,
  },
  settingsPrivacyContent: { flex: 1 },
  settingsPrivacyTitle: {
    color: palette.navy,
    fontSize: 15,
    fontWeight: "900",
  },
  settingsPrivacyText: {
    color: palette.muted,
    fontSize: 10,
    lineHeight: 15,
    marginTop: 4,
  },
  settingsPrivacyMetaRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 6,
    marginTop: 10,
  },
  settingsPrivacyBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    borderRadius: 12,
    backgroundColor: "#E3F1FF",
    paddingHorizontal: 8,
    paddingVertical: 5,
  },
  settingsPrivacyBadgeText: {
    color: "#2878C8",
    fontSize: 8,
    fontWeight: "900",
  },
  settingsChevron: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  settingsBlockedLink: {
    minHeight: 74,
    flexDirection: "row",
    alignItems: "center",
    gap: 11,
    borderWidth: 1,
    borderColor: "#E1E6EC",
    borderRadius: 17,
    paddingHorizontal: 14,
    backgroundColor: "white",
  },
  settingsBlockedIcon: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: "#FFF1F2",
    alignItems: "center",
    justifyContent: "center",
  },
  settingsBlockedCount: {
    minWidth: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: "#FFF1F2",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 7,
  },
  settingsBlockedCountText: {
    color: palette.coral,
    fontSize: 10,
    fontWeight: "900",
  },
  logoutButton: {
    minHeight: 56,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: "#BFD7ED",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
  },
  logoutButtonText: { color: palette.blue, fontSize: 12, fontWeight: "900" },
  dangerZone: {
    borderWidth: 1,
    borderColor: "#F3CDD0",
    borderRadius: 18,
    backgroundColor: "#FFF7F7",
    padding: 16,
    marginTop: 14,
  },
  dangerZoneTitle: { color: palette.coral, fontSize: 13, fontWeight: "900" },
  dangerZoneText: {
    color: palette.muted,
    fontSize: 10,
    lineHeight: 15,
    marginTop: 5,
  },
  deleteAccountButton: {
    minHeight: 50,
    borderRadius: 13,
    borderWidth: 1,
    borderColor: palette.coral,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    marginTop: 13,
  },
  deleteAccountText: { color: palette.coral, fontSize: 11, fontWeight: "900" },
});
export {ServiceForm as CanonicalServiceForm,DarkModeContext as PrototypeThemeContext,EventCard as CanonicalEventCard,AvailabilityCalendar as CanonicalCalendar,SelectField as CanonicalSelect};
export type {ServiceCheckoutOrder};

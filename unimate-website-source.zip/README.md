# UniMate website

Public website at https://hellounimate.com. This is a separate website project; it does not change the original mobile app.

The production entry point is `PublicWebsite.tsx`. It opens a standalone introduction page for visitors, with Sign up and Sign in links and no app navigation, and once Supabase is configured restores authenticated users to their own dashboard. Legacy `App.tsx` is retained as a design reference but is not imported into the public build. It contains prototype data and must not be reconnected to the production entry point.

## Current status

- Public pages contain no interactive sample users, listings, events, conversations or bookings. Clearly labelled app screenshots illustrate the dashboard, Moments and Student Forum; sample screenshot content is not live data.
- Community, marketplace and service pages show honest empty or coming-soon states.
- Email signup, login, email confirmation, password recovery and logout are implemented using Supabase Auth.
- Authentication remains unavailable until the owner's Supabase project and email sender are configured. See `AUTH_SETUP.md`.
- Real service bookings, payments, messaging, content publishing and staff workflows are not connected yet.

## Development

Use this project's own dependencies. Do not link `node_modules` to the original mobile app.

```
pnpm install
pnpm typecheck
pnpm web
```

The local website runs at http://localhost:8083. Layout follows screen size automatically, with an optional display preference in the footer. Public Supabase configuration is supplied at build time; secrets never belong in this frontend. Changes to environment configuration require restarting development and rebuilding the published site.

Build and publish with the Sites source workflow and the existing `.openai/hosting.json` project identity. Preserve the public audience and existing custom domains.

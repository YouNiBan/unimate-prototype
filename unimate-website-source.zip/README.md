# UniMate website

Public website at https://hellounimate.com. This is a separate website project; it does not change the original mobile app.

The production entry point is `PublicWebsite.tsx`. Visitors see the introduction page and account links. A session verified by the UniMate member API opens the member's dashboard. Legacy `App.tsx` is retained as a design reference and is not imported into the public build; its prototype identities and records must never become live account data.

## Current status

- Public pages and app previews contain no fictional users, listings, events, conversations or bookings. Homepage previews use empty interface illustrations; the old screenshots containing sample records are not imported or shipped.
- Community, marketplace and service pages show honest empty or coming-soon states.
- Email signup, login, email confirmation, password recovery and logout use the UniMate-owned backend with HttpOnly session cookies and CSRF protection. See `AUTH_SETUP.md`.
- Production builds connect to the existing Render member API at `https://admin.hellounimate.com`. On 21 October 2026 it reported hosted mode, registration enabled and SMTP configured, and accepted credentialed requests from `https://hellounimate.com`. This is the account API origin; a separate `api.hellounimate.com` hostname is not required. Successful account confirmation still depends on delivery to the member's inbox.
- Bookings, support messages, marketplace and restaurant features have member-API integrations. Their public availability depends on that backend. Moments, Forum and event publishing still require production integration; local prototype actions are not live features.

## Development

Use this project's own dependencies. Do not link `node_modules` to the original mobile app.

```
pnpm install
pnpm typecheck
pnpm web
```

The local website runs at http://localhost:8083. Layout follows screen size automatically, with an optional display preference in the footer. Set `EXPO_PUBLIC_API_URL` in ignored `.env.local` for local development. `pnpm build` uses `scripts/build-production.mjs` to embed the Render API origin, or an explicitly supplied HTTPS `EXPO_PUBLIC_API_URL`. Sites runtime variables do not rewrite a static bundle. Secrets never belong in this frontend; API changes require rebuilding and publishing.

Build and publish with the Sites source workflow and the existing `.openai/hosting.json` project identity. Preserve the public audience and existing custom domains.

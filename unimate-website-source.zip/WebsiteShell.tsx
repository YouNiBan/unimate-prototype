import {UniMateSelect} from './UniMateSelect';
import React from 'react';
import { useWindowDimensions } from 'react-native';
import { AppIonicons, UniMateMomentsIcon } from './AppIcons';
import ForumIcon from './ForumIcon';

type Language = 'EN' | '简体' | '繁體';
export const WebsiteLanguageContext = React.createContext<Language>('EN');
export const WebsiteLayoutWidthContext = React.createContext(0);
const t = (language: Language, en: string, cn: string, tw: string) => language === 'EN' ? en : language === '简体' ? cn : tw;
export type WebsiteDestination = 'home' | 'support' | 'my-events' | 'listings' | 'events' | 'food' | 'forum' | 'friends' | 'connections' | 'bookings' | 'messages' | 'profile' | 'market' | 'airport' | 'moving' | 'cleaning';
const navigationIconColors: Record<WebsiteDestination, string> = {
  home: '#1683DF', events: '#FF4657', forum: '#0799AD', friends: '#8B5CF6', connections: '#8262DB',
  food: '#E95E32', market: '#854CE9', airport: '#17A957', moving: '#00A1A7', cleaning: '#F28A18',
  'my-events': '#FF4657', listings: '#854CE9', bookings: '#2487DF', messages: '#C98712', profile: '#2DBE78', support: '#D58A12',
};
const entries: [WebsiteDestination, string, string, string, string][] = [
  ['home','home','Overview','首页','首頁'],
  ['events','calendar','Events','活动','活動'],
  ['market','bag-handle','Marketplace','学生集市','學生市集'],
  ['food','restaurant','Places & Reviews','好去处与点评','好去處與評價'],
  ['friends','images','Moments','朋友圈','朋友圈'],
  ['forum','forum','Student Forum','学生问答','學生問答'],
  ['connections','people','Friends','好友','好友'],
  ['airport','car-sport','Airport transfers','机场接送','機場接送'],
  ['moving','cube','Moving','搬家服务','搬家服務'],
  ['cleaning','home','Cleaning','保洁服务','清潔服務'],
  ['my-events','calendar','My events','我的活动','我的活動'],
  ['listings','bag-handle','My marketplace','我的市场','我的市場'],
  ['bookings','receipt','Bookings & purchases','预订与购买记录','預訂與購買記錄'],
  ['messages','chatbubbles','Messages','消息','訊息'],
  ['support','headset','Support','客服支持','客戶支援'],
  ['profile','person','My account','我的账户','我的帳戶'],
];

export function WebsiteSidebar({ language, current, onNavigate, onLogout, signedOut = false, liveAccount = false, hasUnread = true, hideSessionAction = false }: { language: Language; current: string; onNavigate: (destination: WebsiteDestination) => void; onLogout: () => void; signedOut?: boolean; liveAccount?: boolean; hasUnread?: boolean; hideSessionAction?: boolean }) {
  return <aside className="website-sidebar"><div className="website-sidebar-scroll">

    <nav aria-label={t(language,'Main navigation','主导航','主導覽')}>
      {entries.map(([id,icon,en,cn,tw]) => <React.Fragment key={id}>
        {(['home', 'friends', 'airport', 'my-events', 'messages'].includes(id)) && <p className={'website-nav-group' + (id === 'messages' ? ' website-nav-group-personal' : '')}>{id === 'home' ? t(language,'DISCOVER','发现','探索') : id === 'friends' ? t(language,'SOCIAL','社交','社交') : id === 'airport' ? t(language,'SERVICES','服务','服務') : id === 'my-events' ? t(language,'YOUR SPACE','个人空间','個人空間') : t(language,'PERSONAL','个人中心','個人中心')}</p>}
        <a href={'#/'+id} className={'website-nav-item '+(current === id ? 'is-active' : '')} aria-current={current === id ? 'page' : undefined} onClick={e => { e.preventDefault(); onNavigate(id); }}><span aria-hidden="true" className="website-nav-icon">{icon === 'forum' ? <ForumIcon size={22} color={current === id ? navigationIconColors[id] : 'var(--muted, #71839B)'} /> : id === 'friends' ? <><span className="website-mobile-moments-logo"><UniMateMomentsIcon size={24} active={current === id}/></span><span className="website-desktop-moments-logo"><AppIonicons name="images" size={21} color={current === id ? navigationIconColors[id] : 'var(--muted, #71839B)'}/></span></> : <AppIonicons name={icon as React.ComponentProps<typeof AppIonicons>['name']} size={21} color={current === id ? navigationIconColors[id] : 'var(--muted, #71839B)'} />}</span>{t(language,en,cn,tw)}{id === 'messages' && !signedOut && hasUnread && <span className="website-nav-dot" />}</a>
      </React.Fragment>)}
    </nav>

    {!hideSessionAction && <button className="website-signout" onClick={onLogout}>{signedOut ? t(language,'Sign in','登录','登入') : liveAccount ? t(language,'Sign out','退出登录','登出') : t(language,'Sign in / explore workspaces','登录 / 探索工作空间','登入 / 探索工作空間')} <span>↗</span></button>}
    <small className="website-copyright">© {new Date().getFullYear()} UniMate 优你伴</small>
  </div></aside>;
}

type LayoutMode = 'auto' | 'desktop' | 'mobile';
const WebsiteDisplayContext = React.createContext<{ mode: LayoutMode; setMode: (mode: LayoutMode) => void; onExploreWorkspaces?: () => void }>({ mode: 'auto', setMode: () => {} });

export function WebsiteBanner({ language: requestedLanguage, controls = false }: { language?: Language; controls?: boolean }) {
  const currentLanguage = React.useContext(WebsiteLanguageContext);
  const language = requestedLanguage || currentLanguage;
  const { mode, setMode, onExploreWorkspaces } = React.useContext(WebsiteDisplayContext);
  return <div className="website-demo-banner">
    <div className="website-demo-copy">{controls && onExploreWorkspaces ? <button className="website-preview-label website-preview-button" aria-label={t(language,'Explore workspaces','探索工作空间','探索工作空間')} onClick={onExploreWorkspaces}>{t(language,'PREVIEW','预览','預覽')} <span aria-hidden="true">⌄</span></button> : <span className="website-preview-label">{t(language,'PREVIEW','预览','預覽')}</span>}<span>{t(language,'Sample content. Bookings, payments and messages are demos.','示例内容。预订、付款和消息均为演示。','範例內容。預訂、付款和訊息均為示範。')}</span></div>
    {controls && <WebsiteDisplayControl language={language} />}
  </div>;
}

export function WebsiteDisplayControl({ language }: { language: Language }) {
  const { mode, setMode } = React.useContext(WebsiteDisplayContext);
  return <label className="website-display-control"><AppIonicons name="desktop-outline" size={15} color="currentColor" /><span className="website-display-label">{t(language,'Display','显示','顯示')}</span><UniMateSelect aria-label={t(language,'Website display','网站显示模式','網站顯示模式')} value={mode} onChange={e => setMode(e.target.value as LayoutMode)}>
      <option value="auto">{t(language,'Automatic','自动','自動')}</option><option value="desktop">{t(language,'Desktop','桌面版','桌面版')}</option><option value="mobile">{t(language,'Mobile','手机版','手機版')}</option>
    </UniMateSelect></label>;
}

export function WebsiteLayoutFrame({ language, children, onExploreWorkspaces }: { language: Language; children: React.ReactNode; onExploreWorkspaces?: () => void }) {
  const { width } = useWindowDimensions();
  // A fresh preference key retires the preview toolbar's forced layout choices.
  const [mode, setMode] = React.useState<LayoutMode>(() => {
    try { if(new URLSearchParams(window.location.search).get('owner-embed')==='1')return 'auto';const saved = localStorage.getItem('unimate-display-preference'); return saved === 'desktop' || saved === 'mobile' ? saved : 'auto'; }
    catch { return 'auto'; }
  });
  React.useEffect(() => {
    document.documentElement.dataset.unimateLayout = mode;
    try { if(new URLSearchParams(window.location.search).get('owner-embed')!=='1')localStorage.setItem('unimate-display-preference', mode); } catch { /* Still works for this visit. */ }
  }, [mode]);
  const layoutWidth = mode === 'mobile' ? Math.min(width, 430) : mode === 'desktop' ? Math.max(width, 1280) : width;
  return <WebsiteDisplayContext.Provider value={{ mode, setMode, onExploreWorkspaces }}><WebsiteLayoutWidthContext.Provider value={layoutWidth}>
    <div className="website-viewport"><div className="website-layout-scroll"><div className={'website-layout-frame website-layout-' + mode}>{children}</div></div></div>
  </WebsiteLayoutWidthContext.Provider></WebsiteDisplayContext.Provider>;
}

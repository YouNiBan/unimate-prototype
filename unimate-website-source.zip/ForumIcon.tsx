import React from "react";
import { AppIonicons } from "./AppIcons";

// Use the same filled icon family as the rest of the website navigation.
export default function ForumIcon({ size = 24, color }: { size?: number; color: string }) {
  return <AppIonicons name="chatbox-ellipses" size={size} color={color} accessibilityElementsHidden importantForAccessibility="no" />;
}

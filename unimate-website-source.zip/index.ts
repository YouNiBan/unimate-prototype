import './website.css';
import { registerRootComponent } from 'expo';
import App from './PublicWebsite';
registerRootComponent(App);

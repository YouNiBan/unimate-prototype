import {installPhotoEditor} from './photo-editor.mjs';
import './website.css';
import { registerRootComponent } from 'expo';
import App from './PublicWebsite';
installPhotoEditor();
registerRootComponent(App);

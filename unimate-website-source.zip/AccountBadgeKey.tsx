import React from 'react';
import {useUiText} from './useUiText';

export type AccountBadgeKind = 'student' | 'staff' | 'official' | 'seller' | 'unverified';
const labels: Record<AccountBadgeKind, string> = {
  student: 'Verified student', staff: 'Staff', official: 'Official page',
  seller: 'Approved seller', unverified: 'Unverified',
};

export function AccountBadge({kind}: {kind: AccountBadgeKind}) {
  return <span className={'account-badge-symbol account-badge-' + kind} aria-hidden="true">
    {kind === 'staff'
      ? <svg viewBox="0 0 32 36" width="28" height="32"><path fill="#1479D3" d="M16 1 30 5v11c0 9-8 16-14 19C10 32 2 25 2 16V5Z"/><path d="m9 17 5 5 10-12" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/></svg>
      : kind === 'official' ? '★' : kind === 'unverified' ? '?' : <svg viewBox="0 0 24 24" width="22" height="22"><path d="m5 12 5 5L20 6" fill="none" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>}
  </span>;
}

export function AccountBadgeKey() {
  const ui = useUiText();
  return <section className="account-badge-key" aria-label={ui('Account badge key')}>
    <ul>{(Object.keys(labels) as AccountBadgeKind[]).map(kind =>
      <li key={kind}><AccountBadge kind={kind}/><span>{ui(labels[kind])}</span></li>
    )}</ul>
  </section>;
}

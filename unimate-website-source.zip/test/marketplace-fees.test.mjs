import test from 'node:test';
import assert from 'node:assert/strict';
import { marketplaceSplit as webSplit } from '../marketplace-fees.mjs';
import { marketplaceSplit as mobileSplit } from '../../unimate-prototype/marketplace-fees.mjs';

for (const [app, split] of [['web', webSplit], ['mobile', mobileSplit]]) {
  test(`${app}: a £20 item leaves £17.60 for the seller`, () => {
    assert.deepEqual(split(2000), { commissionPence: 240, sellerPence: 1760 });
  });
  test(`${app}: rounding preserves every penny of the item price`, () => {
    for (const price of [0, 1, 4, 5, 99, 1999, 10000000]) {
      const result = split(price);
      assert.equal(result.commissionPence + result.sellerPence, price);
      assert.ok(Number.isSafeInteger(result.commissionPence));
      assert.ok(Number.isSafeInteger(result.sellerPence));
    }
    assert.deepEqual(split(1999), { commissionPence: 240, sellerPence: 1759 });
  });
  test(`${app}: invalid monetary values are rejected`, () => {
    for (const price of [-1, 0.5, NaN, Infinity, '2000', 10000001]) {
      assert.throws(() => split(price), RangeError);
    }
  });
}

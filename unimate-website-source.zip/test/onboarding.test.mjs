import test from 'node:test';
import assert from 'node:assert/strict';
import {harness,React,act,textOf,student,session,json} from './frontend-harness.mjs';
const profile={name:'Test Student',birthday:'2002-07-17',country:'GB',province:'',profileComplete:true,studentVerified:false,university:'',universityEmail:'',universityVerifiedAt:null};
test('onboarding resumes the saved step and displays where the email code goes before sending',async t=>{
 const h=harness({handler:path=>path.endsWith('/session')?json(session({...student,profileComplete:true})):json(profile)});
 const {StudentOnboarding}=h.load('StudentOnboarding.tsx');await h.mount(React.createElement(StudentOnboarding));t.after(()=>h.unmount());
 const root=h.renderer().root;
 assert.match(textOf(root),/Steps to completion/);
 assert.equal(root.findByProps({'aria-label':'Six-digit verification code'}).props.disabled,true);
 assert.match(textOf(root),/Send a code first/);
 assert.equal(h.calls.filter(c=>c.options.method==='POST').length,0);
});
test('owner tester is not shown a required university code form or a false academic badge',async t=>{
 const h=harness({handler:path=>path.endsWith('/session')?json(session({...student,ownerTester:true})):json({...profile,ownerTester:true})});
 const {StudentOnboarding}=h.load('StudentOnboarding.tsx');await h.mount(React.createElement(StudentOnboarding));t.after(()=>h.unmount());
 const root=h.renderer().root;
 assert.match(textOf(root),/Owner \/ tester access enabled/);
 assert.match(textOf(root),/not marked as verified/);
 assert.equal(root.findAllByProps({'aria-label':'Six-digit verification code'}).length,0);
 assert.equal(h.current().user.studentVerified,false);
});
test('birthday uses three contained controls, and finish later saves partial details to the account',async t=>{
 let saved;
 const h=harness({handler:(path,options)=>path.endsWith('/session')?json(session(student)):options.method==='POST'?(saved=JSON.parse(options.body),json({profile:{...profile,birthday:'',country:'',profileComplete:false}})):json({...profile,birthday:'',country:'',profileComplete:false})});
 const {StudentOnboarding}=h.load('StudentOnboarding.tsx');await h.mount(React.createElement(StudentOnboarding));t.after(()=>h.unmount());
 const root=h.renderer().root;
 for(const label of ['Day','Month','Year'])assert.equal(root.findByProps({'aria-label':label}).type,'select');
 const later=root.findAllByType('button').find(node=>textOf(node)==='Save and finish later');
 await act(async()=>{await later.props.onClick();});
 assert.equal(saved.draft,true);assert.equal(saved.birthday,'');
 assert.match(textOf(root),/progress is saved/);
});
test('admin-approved accounts display verified access without claiming a confirmed university mailbox',async t=>{
 const h=harness({handler:path=>path.endsWith('/session')?json(session({...student,studentVerified:true})):json({...profile,studentVerified:true,verificationSource:'admin'})});
 const {StudentOnboarding}=h.load('StudentOnboarding.tsx');await h.mount(React.createElement(StudentOnboarding));t.after(()=>h.unmount());
 const text=textOf(h.renderer().root);assert.match(text,/Account verified by UniMate/);assert.match(text,/without university email confirmation/);assert.doesNotMatch(text,/University email verified/);
 assert.equal(h.renderer().root.findAllByProps({'aria-label':'Six-digit verification code'}).length,0);
});

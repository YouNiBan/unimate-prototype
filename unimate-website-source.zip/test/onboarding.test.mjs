import test from 'node:test';
import assert from 'node:assert/strict';
import {harness,React,act,textOf,student,session,json} from './frontend-harness.mjs';
const profile={name:'Test Student',birthday:'2002-07-17',country:'GB',province:'',profileComplete:true,studentVerified:false,university:'',universityEmail:'',universityVerifiedAt:null};
test('onboarding resumes the saved step and displays where the email code goes before sending',async t=>{
 const h=harness({handler:path=>path.endsWith('/session')?json(session({...student,profileComplete:true})):json(profile)});
 const {StudentOnboarding}=h.load('StudentOnboarding.tsx');await h.mount(React.createElement(StudentOnboarding));t.after(()=>h.unmount());
 const root=h.renderer().root;
 assert.match(textOf(root),/Steps to completion/);
 assert.equal(root.findByProps({'aria-label':'Six-digit verification code'}).props.disabled,true);
 assert.match(textOf(root),/Send a code first/);
 assert.equal(h.calls.filter(c=>c.options.method==='POST').length,0);
});
test('owner tester is not shown a required university code form or a false academic badge',async t=>{
 const h=harness({handler:path=>path.endsWith('/session')?json(session({...student,ownerTester:true})):json({...profile,ownerTester:true})});
 const {StudentOnboarding}=h.load('StudentOnboarding.tsx');await h.mount(React.createElement(StudentOnboarding));t.after(()=>h.unmount());
 const root=h.renderer().root;
 assert.match(textOf(root),/Owner \/ tester access enabled/);
 assert.match(textOf(root),/not marked as verified/);
 assert.equal(root.findAllByProps({'aria-label':'Six-digit verification code'}).length,0);
 assert.equal(h.current().user.studentVerified,false);
});
test('birthday uses three contained controls, and saving partial details keeps the member on their profile',async t=>{
 let saved;
 const h=harness({handler:(path,options)=>path.endsWith('/session')?json(session(student)):options.method==='POST'?(saved=JSON.parse(options.body),json({profile:{...profile,birthday:'',country:'',profileComplete:false}})):json({...profile,birthday:'',country:'',profileComplete:false})});
 const {StudentOnboarding}=h.load('StudentOnboarding.tsx');await h.mount(React.createElement(StudentOnboarding));t.after(()=>h.unmount());
 const root=h.renderer().root;
 for(const label of ['Day','Month','Year'])assert.equal(root.findByProps({'aria-label':label}).type,'select');
 const later=root.findAllByType('button').find(node=>textOf(node)==='Save personal details');
 await act(async()=>{await later.props.onClick();});
 assert.equal(saved.draft,true);assert.equal(saved.birthday,'');
 assert.match(textOf(root),/Personal details saved/);
});
test('admin-approved accounts display verified access without claiming a confirmed university mailbox',async t=>{
 const h=harness({handler:path=>path.endsWith('/session')?json(session({...student,studentVerified:true})):json({...profile,studentVerified:true,verificationSource:'admin'})});
 const {StudentOnboarding}=h.load('StudentOnboarding.tsx');await h.mount(React.createElement(StudentOnboarding));t.after(()=>h.unmount());
 const text=textOf(h.renderer().root);assert.match(text,/Account verified by UniMate/);assert.match(text,/without university email confirmation/);assert.doesNotMatch(text,/University email verified/);
 assert.equal(h.renderer().root.findAllByProps({'aria-label':'Six-digit verification code'}).length,0);
});
test('a verified member finishing personal details is not asked to repeat university verification',async t=>{
 const h=harness({handler:()=>json(session({...student,studentVerified:true,profileComplete:false}))});const {StudentWelcomeSteps}=h.load('StudentOnboarding.tsx');await h.mount(React.createElement(StudentWelcomeSteps,{onOpen(){}}));t.after(()=>h.unmount());const text=textOf(h.renderer().root);assert.match(text,/Account verified by UniMate/);assert.doesNotMatch(text,/then verify your university email/);assert.match(text,/Continue my profile/);
});

test('a completed verified profile has no setup wizard or finish-later controls and can edit details',async t=>{
 const h=harness({handler:path=>path.endsWith('/session')?json(session({...student,studentVerified:true,profileComplete:true})):json({...profile,studentVerified:true,verificationSource:'admin'})});
 const {StudentOnboarding}=h.load('StudentOnboarding.tsx');await h.mount(React.createElement(StudentOnboarding));t.after(()=>h.unmount());
 const root=h.renderer().root;assert.match(textOf(root),/Account verified by UniMate/);assert.doesNotMatch(textOf(root),/Finish later|finish later|Steps to completion|Save each step/);
 await act(async()=>root.findAllByType('button').find(n=>textOf(n)==='Personal details').props.onClick());
 assert.match(textOf(root),/Save changes/);assert.doesNotMatch(textOf(root),/finish later|Save and continue/);
});
test('Home keeps the setup reminder across visits until both personal details and access are complete',async t=>{
 for(const flags of [{profileComplete:false,studentVerified:false},{profileComplete:true,studentVerified:false},{profileComplete:false,studentVerified:true}]){
  const h=harness({handler:()=>json(session({...student,...flags}))});const {StudentWelcomeSteps}=h.load('StudentOnboarding.tsx');
  for(let visit=0;visit<2;visit++){await h.mount(React.createElement(StudentWelcomeSteps,{onOpen(){}}));assert.match(textOf(h.renderer().root),/Make UniMate yours/);await h.unmount();}
 }
 for(const flags of [{studentVerified:true},{ownerTester:true}]){
  const h=harness({handler:()=>json(session({...student,profileComplete:true,...flags}))});const {StudentWelcomeSteps}=h.load('StudentOnboarding.tsx');await h.mount(React.createElement(StudentWelcomeSteps,{onOpen(){}}));assert.equal(h.renderer().root.findAllByType('section').length,0);await h.unmount();
 }
});

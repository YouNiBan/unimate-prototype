import assert from 'node:assert/strict';
import test from 'node:test';
import {harness, json, session, act, React, textOf} from './frontend-harness.mjs';

function ownerHarness(role='owner') {
 return harness({handler:(path,options,calls)=>{
  if(path==='/api/member/owner-preview'){
   const destination=new URL(calls.at(-1).url).searchParams.get('path');
   if(destination==='/api/session')return json({admin:{role}});
   if(destination.startsWith('/api/oversight/accounts?'))return json({rows:[],total:0});
   return json({rows:[],total:0});
  }
  return json(session());
 }});
}
test('desktop preview reuses the original grouped sidebar and mobile keeps its tab bar',async t=>{
 const h=ownerHarness();await h.mount(React.createElement(h.load('OwnerViews.tsx').OwnerViews));t.after(()=>h.unmount());
 const root=h.renderer().root;
 const toolbar=root.findByProps({'aria-label':'Preview size'});
 await act(async()=>toolbar.findAllByType('button')[0].props.onClick());
 const nav=root.findByProps({'aria-label':'Main navigation'});
 for(const group of ['DISCOVER','SOCIAL','SERVICES','YOUR SPACE'])assert.match(textOf(nav),new RegExp(group));
 assert.equal(root.findAllByProps({'aria-label':'Student preview navigation'}).length,0);
 assert.equal(root.findAllByProps({className:'website-signout'}).length,0);
 await act(async()=>nav.findAllByType('a').find(link=>textOf(link).includes('Bookings & purchases')).props.onClick({preventDefault(){}}));
 assert.match(textOf(h.renderer().toJSON()),/My bookings/);
 await act(async()=>toolbar.findAllByType('button')[1].props.onClick());
 assert.equal(root.findByProps({'aria-label':'Student preview navigation'}).findAllByType('button').length,5);
 assert.equal(h.current().user,null);
 assert.ok(h.calls.every(call=>!call.options.method||call.options.method==='GET'));
});
test('owner preview changes role navigation and pages without changing the signed-in account',async t=>{
 const h=ownerHarness();await h.mount(React.createElement(h.load('OwnerViews.tsx').OwnerViews));t.after(()=>h.unmount());
 const root=h.renderer().root;
 assert.equal(root.findByProps({'aria-label':'Student preview navigation'}).findAllByType('button').length,5);
 const roles=root.findByProps({'aria-label':'Choose account view'});
 await act(async()=>roles.findAllByType('button')[1].props.onClick());
 const staffNav=root.findByProps({'aria-label':'Staff preview navigation'});
 await act(async()=>staffNav.findAllByType('button')[1].props.onClick());
 assert.equal(staffNav.findAllByType('button')[1].props['aria-current'],'page');
 assert.match(textOf(h.renderer().toJSON()),/Assigned jobs/);
 await act(async()=>roles.findAllByType('button')[0].props.onClick());
 assert.equal(root.findByProps({'aria-label':'Student preview navigation'}).findAllByType('button')[0].props['aria-current'],'page');
 assert.equal(h.current().user,null);
 assert.ok(h.calls.every(call=>!call.options.method||call.options.method==='GET'));
});
test('seller and organisation previews clearly identify proposed navigation',async t=>{
 const h=ownerHarness();await h.mount(React.createElement(h.load('OwnerViews.tsx').OwnerViews));t.after(()=>h.unmount());
 const root=h.renderer().root, roles=root.findByProps({'aria-label':'Choose account view'});
 await act(async()=>roles.findAllByType('button')[2].props.onClick());
 assert.match(textOf(h.renderer().toJSON()),/Proposed navigation/);
 assert.match(textOf(h.renderer().toJSON()),/Seller product uploads and sales are not connected yet/);
 await act(async()=>roles.findAllByType('button')[3].props.onClick());
 assert.match(textOf(h.renderer().toJSON()),/organisation app workspace is not available yet/);
 assert.equal(root.findByProps({'aria-label':'Organisation preview navigation'}).findAllByType('button').length,5);
});
test('a non-owner cannot open the view switcher or request account records',async t=>{
 const h=ownerHarness('support');await h.mount(React.createElement(h.load('OwnerViews.tsx').OwnerViews));t.after(()=>h.unmount());
 assert.match(textOf(h.renderer().toJSON()),/Owner or SuperAdmin/);
 assert.equal(h.renderer().root.findAllByProps({'aria-label':'Choose account view'}).length,0);
 assert.ok(!h.calls.some(call=>new URL(call.url).searchParams.get('path')?.startsWith('/api/oversight')));
});

test('every owner account preview has a read-only support entry',async t=>{
 const h=ownerHarness();await h.mount(React.createElement(h.load('OwnerViews.tsx').OwnerViews));t.after(()=>h.unmount());
 const root=h.renderer().root;
 for(let index=0;index<4;index++){
  await act(async()=>root.findByProps({'aria-label':'Choose account view'}).findAllByType('button')[index].props.onClick());
  await act(async()=>root.findByProps({'aria-label':'Contact UniMate Support'}).props.onClick());
  assert.match(textOf(h.renderer().toJSON()),/Contact UniMate Support/);
  assert.match(textOf(h.renderer().toJSON()),/Messages cannot be sent on someone else’s behalf/);
 }
 assert.ok(h.calls.every(call=>!call.options.method||call.options.method==='GET'));
});
test('owner header provides owner sign-in instead of public registration',async t=>{
 const h=harness({search:'#/owner-views'});await h.mount(React.createElement(h.load('PublicWebsite.tsx').default));t.after(()=>h.unmount());
 const header=h.renderer().root.findByType('header');
 assert.ok(!textOf(header).includes('Sign up'));assert.ok(!textOf(header).includes('Sign in'));
 assert.equal(header.findByProps({'aria-label':'Owner sign-in and security'}).props.href,'http://localhost:8090/owner-login');
});

test('all account previews include app controls and notification navigation remains read only',async t=>{
 const h=ownerHarness();let toggles=0;await h.mount(React.createElement(h.load('OwnerViews.tsx').OwnerViews,{onToggleTheme:()=>toggles++}));t.after(()=>h.unmount());
 const root=h.renderer().root;
 for(let index=0;index<4;index++){
  await act(async()=>root.findByProps({'aria-label':'Choose account view'}).findAllByType('button')[index].props.onClick());
  const controls=root.findByProps({'aria-label':'Preview app controls'});
  const buttons=controls.findAllByType('button');
  assert.equal(buttons[0].props['aria-label'],'Notifications');assert.equal(buttons[1].props['aria-label'],'Switch to dark mode');
  await act(async()=>buttons[0].props.onClick());assert.match(textOf(root),/no personal notifications/);
  await act(async()=>buttons[1].props.onClick());
  const messages=root.findAllByType('button').find(button=>textOf(button)==='View support references');await act(async()=>messages.props.onClick());
  assert.match(textOf(root),/Choose an account to review its support references/);
 }
 assert.equal(toggles,4);assert.ok(h.calls.every(call=>!call.options.method||call.options.method==='GET'));
});

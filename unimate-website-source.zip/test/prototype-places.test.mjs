import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';
import {harness,React,act,textOf,student,session,json,deferred} from './frontend-harness.mjs';
const row={id:'place-a',name:'Real fixture restaurant',address:'10 Example Road',postcode:'E1 1AA',place_type:'restaurant',phone:'',website:'',cuisine:'Italian',category:'Birthday',area:'Soho',city:'London',price_band:'£',minimum_spend_pence:1000,maximum_spend_pence:1800,reviewCount:1,rating:5,quote:'A real server-provided review.',friendCount:0,friendRating:null,saved:false,visitedOn:null,reviewed:false,previewPhoto:null};
const data={rows:[row],total:1,features:[{id:'under20',title:'Top 10 under £20',filter:'Under £20',mode:'discover',count:1,photo:null}]};
test('prototype places has two section tabs, search, Add review, featured lists and working filters',async t=>{
 const h=harness({handler:path=>path.endsWith('/session')?json(session({...student,studentVerified:true})):json(data)}),{FoodReviews}=h.load('FoodReviews.tsx');let leaderboard=0;await h.mount(React.createElement(FoodReviews,{onLeaderboard(){leaderboard++;},onVerify(){}}));t.after(()=>h.unmount());const root=h.renderer().root;
 assert.deepEqual(root.findByProps({className:'prototype-food-section-tabs'}).findAllByProps({role:'tab'}).map(n=>textOf(n).trim()),['Restaurants & Activities','Leaderboard']);assert.match(textOf(root),/Featured student lists/);assert.match(textOf(root),/Explore places/);assert.equal(root.findByProps({'aria-label':'Search restaurants and activities'}).props.maxLength,100);
 await act(async()=>root.findAllByProps({role:'tab'}).find(n=>textOf(n).includes('Leaderboard')).props.onClick());assert.equal(leaderboard,1);
 const button=label=>root.findAllByType('button').find(n=>textOf(n).trim()===label);await act(async()=>button('Pottery').props.onClick());assert.ok(h.calls.some(c=>c.url.includes('type=pottery')));assert.equal(button('Pottery').props['aria-pressed'],true);
 await act(async()=>button('££').props.onClick());assert.ok(h.calls.some(c=>new URL(c.url).searchParams.get('filter')==='££'));
 await act(async()=>button('Trending').props.onClick());assert.ok(h.calls.some(c=>c.url.includes('mode=trending')));
});
test('all featured lists stay in one swipeable row without See all or expansion',async t=>{
 const features=Array.from({length:6},(_,i)=>({...data.features[0],id:'list-'+i,title:'Featured list '+i}));
 const h=harness({handler:path=>path.endsWith('/session')?json(session(student)):json({...data,features})}),C=h.load('PrototypePlaces.tsx').PlaceExplorer;
 await h.mount(React.createElement(C,{onOpen(){},onVerify(){},onLeaderboard(){}}));t.after(()=>h.unmount());
 const root=h.renderer().root,rail=root.findByProps({className:'prototype-featured-lists'});
 assert.equal(rail.findAllByType('button').length,6);assert.equal(rail.props.tabIndex,0);
 assert.doesNotMatch(textOf(root),/See all|Show less/);assert.match(textOf(root),/Swipe to explore/);
 let distance=0,prevented=false;const target={scrollBy:({left})=>{distance+=left;}};
 rail.props.onKeyDown({target,currentTarget:target,key:'ArrowRight',preventDefault(){prevented=true;}});assert.equal(distance,225);assert.equal(prevented,true);
 await act(async()=>rail.findAllByType('button')[5].props.onClick());assert.ok(h.calls.some(c=>new URL(c.url).searchParams.get('filter')==='Under £20'));
 const css=readFileSync(new URL('../prototype-food.css',import.meta.url),'utf8');assert.match(css,/scroll-snap-type:x mandatory/);assert.doesNotMatch(css,/prototype-featured-lists\.is-expanded/);
});

test('place save waits for persistence, rejects errors and never sends an account identifier',async t=>{
 const pending=deferred();let saved=false;const h=harness({handler:(path,options)=>path.endsWith('/session')?json(session(student)):path.endsWith('place-bookmark')?pending.promise:json({...data,rows:[{...row,saved}]})}),C=h.load('PrototypePlaces.tsx').PlaceExplorer;await h.mount(React.createElement(C,{onOpen(){},onVerify(){},onLeaderboard(){}}));t.after(()=>h.unmount());const root=h.renderer().root,button=root.findByProps({'aria-label':'Bookmark place: '+row.name});let task;await act(async()=>{task=button.props.onClick();});assert.equal(button.props['aria-pressed'],false);const mutation=h.calls.find(c=>c.url.includes('place-bookmark'));assert.deepEqual(JSON.parse(mutation.options.body),{restaurantId:row.id,saved:true});saved=true;await act(async()=>{pending.resolve(json({saved:true}));await task;});assert.ok(root.findByProps({'aria-label':'Remove bookmark: '+row.name}).props['aria-pressed']);
});
test('stale account responses and failed discovery cannot show fictional or previous-account listings',async t=>{
 const pending=deferred();let count=0;const h=harness({handler:path=>path.endsWith('/session')?json(session(student)):++count===1?pending.promise:json({error:'Server unavailable'},503)}),C=h.load('PrototypePlaces.tsx').PlaceExplorer;const props={onOpen(){},onVerify(){},onLeaderboard(){}};await h.mount(React.createElement(C,{...props,key:'a'}));await h.update(React.createElement(C,{...props,key:'b'}));await act(async()=>pending.resolve(json(data)));t.after(()=>h.unmount());assert.doesNotMatch(textOf(h.renderer().root),/Real fixture restaurant/);assert.match(textOf(h.renderer().root),/unavailable/);assert.doesNotMatch(textOf(h.renderer().root),/No matching places yet/);
});
test('selected prototype categories keep explicit contrasting text in light and dark themes',()=>{const css=readFileSync(new URL('../prototype-food.css',import.meta.url),'utf8');assert.match(css,/prototype-food-filters button\[aria-pressed=true\][^{]*\{color:#fff!important;background:#0671db/);assert.match(css,/prototype-food-section-tabs button\[aria-selected=true\][^{]*\{background:#0671db;color:#fff!important/);});

import test from 'node:test';
import assert from 'node:assert/strict';
import {harness,React,act,textOf,student,session,json,deferred} from './frontend-harness.mjs';
const pause=()=>new Promise(r=>setTimeout(r,500));
test('username suggestions select a new handle and a stale lookup cannot replace the latest result',async t=>{
 const first=deferred();const h=harness({handler:(path,options,calls)=>path.endsWith('/session')?json(session(student)):calls.at(-1).url.includes('username=first.name')?first.promise:json({username:'second_name',valid:true,available:true,suggestions:[],message:'Username available'})});
 const {UsernameField}=h.load('UsernameField.tsx');function Form(){const [value,set]=React.useState('first.name');return React.createElement(UsernameField,{value,onChange:set});}
 await h.mount(React.createElement(Form));t.after(()=>h.unmount());await act(pause);
 await act(async()=>h.renderer().root.findByType('input').props.onChange({target:{value:'SECOND_Name'}}));await act(pause);
 assert.match(textOf(h.renderer().root),/Username available/);assert.equal(h.renderer().root.findByType('input').props.value,'second_name');
 await act(async()=>{first.resolve(json({username:'first.name',valid:true,available:false,suggestions:['old_suggestion'],message:'Username unavailable'}));await first.promise;});
 assert.doesNotMatch(textOf(h.renderer().root),/Username unavailable|old_suggestion/);
});
test('signup includes a chosen handle while retaining email as the login identity',async t=>{
 let body;const h=harness({handler:(path,options)=>path.endsWith('/session')?json(session(null)): (body=JSON.parse(options.body),json({ok:true,needsConfirmation:true},202))});await h.mount();t.after(()=>h.unmount());await act(async()=>{const r=await h.current().signUp('personal@example.invalid','ExamplePassword123!','Example','ExamplePassword123!',{accountType:'student',username:'example.person_1'});assert.equal(r.error,undefined);});assert.equal(body.username,'example.person_1');assert.equal(body.email,'personal@example.invalid');
});

import assert from 'node:assert/strict';
import test from 'node:test';
import { harness, student, staff, session, json, act, deferred, React, textOf } from './frontend-harness.mjs';

test('missing configuration stays signed out and cannot fabricate an account', async t=>{
  const h=harness({configured:false});await h.mount();t.after(()=>h.unmount());
  assert.equal(h.current().configured,false);assert.equal(h.current().user,null);assert.equal(h.current().loading,false);
  assert.ok((await h.current().signIn('a@example.invalid','UnusedPass!123')).error);assert.equal(h.calls.length,0);assert.equal(h.writes.length,0);
});
test('unavailable endpoint closes forms and does not create a session',async t=>{
  const h=harness({handler:()=>{throw Error('offline');}});await h.mount();t.after(()=>h.unmount());
  assert.equal(h.current().configured,false);assert.equal(h.current().user,null);assert.match(h.current().error,/connect/);
});
test('restoration accepts only a server account and uses credentialed requests',async t=>{
  const h=harness({handler:()=>json(session(staff))});await h.mount();t.after(()=>h.unmount());
  assert.equal(h.current().user.role,'staff');assert.equal(h.current().user.id,staff.id);
  assert.equal(h.calls[0].options.credentials,'include');assert.equal(h.calls[0].options.cache,'no-store');assert.equal(h.writes.length,0);
});
test('a malformed privileged account response never opens the workspace',async t=>{
  const h=harness({handler:()=>json(session({...student,role:'owner'}))});await h.mount();t.after(()=>h.unmount());
  assert.equal(h.current().user,null);assert.equal(h.current().configured,false);
});
test('signup submits only entered identity with CSRF and waits for verification',async t=>{
  const h=harness({handler:path=>path.endsWith('/signup')?json({ok:true,needsConfirmation:true},202):json(session())});await h.mount();t.after(()=>h.unmount());
  let result;await act(async()=>{result=await h.current().signUp(' real@example.invalid ','StrongPassword!12',' Real Name ','StrongPassword!12');});
  assert.equal(result.needsConfirmation,true);assert.equal(h.current().user,null);
  const call=h.calls.find(call=>call.url.endsWith('/signup'));const body=JSON.parse(call.options.body);
  assert.deepEqual(body,{name:'Real Name',email:'real@example.invalid',password:'StrongPassword!12',confirmPassword:'StrongPassword!12',accountType:'student'});
  assert.equal(call.options.headers['X-CSRF-Token'],'test-csrf-token');assert.equal(call.options.credentials,'include');assert.ok(!('role' in body));assert.equal(h.writes.length,0);
});
test('registration closure does not disable existing sign-in',async t=>{
  let loggedIn=false;
  const h=harness({handler:path=>{if(path.endsWith('/login')){loggedIn=true;return json(session(student,{registrationEnabled:false}));}return json(session(loggedIn?student:null,{registrationEnabled:false}));}});await h.mount();t.after(()=>h.unmount());
  assert.equal(h.current().configured,true);assert.equal(h.current().registrationEnabled,false);
  assert.ok((await h.current().signUp('a@example.invalid','StrongPassword!12','Name')).error);
  let result;await act(async()=>{result=await h.current().signIn(student.email,'StrongPassword!12');});
  assert.equal(result.error,undefined);assert.equal(h.current().user.id,student.id);
});
test('failed login stays signed out; successful login must restore a verified session',async t=>{
  const h=harness({handler:path=>path.endsWith('/login')?json({error:'Incorrect credentials'},401):json(session())});await h.mount();t.after(()=>h.unmount());
  let result;await act(async()=>{result=await h.current().signIn(student.email,'wrong-password');});
  assert.equal(result.error,'Incorrect credentials');assert.equal(h.current().user,null);
  const stale=harness({handler:path=>path.endsWith('/login')?json({ok:true}):json(session())});await stale.mount();t.after(()=>stale.unmount());
  await act(async()=>{result=await stale.current().signIn(student.email,'StrongPassword!12');});assert.match(result.error,/could not be verified/);assert.equal(stale.current().user,null);
});
test('verification link is inert until explicit confirmation, then removed from URL',async t=>{
  const token='a'.repeat(64);const h=harness({search:'?member_action=verify&token='+token,handler:path=>path.endsWith('/verify')?json({ok:true}):json(session())});await h.mount();t.after(()=>h.unmount());
  assert.equal(h.current().verification,true);assert.equal(h.calls.length,1);assert.equal(h.current().user,null);
  await act(async()=>{await h.current().verifyEmail();});
  const call=h.calls.find(call=>call.url.endsWith('/verify'));assert.equal(JSON.parse(call.options.body).token,token);
  assert.equal(h.current().verification,false);assert.equal(h.window.location.search,'');assert.equal(h.writes.length,0);assert.equal(h.current().user,null);
});
test('reset requires callback token but no logged-in user, and removes consumed token',async t=>{
  const token='b'.repeat(64);const h=harness({search:'?member_action=reset&token='+token,handler:path=>path.endsWith('/reset-password')?json({ok:true}):json(session(null,{mailConfigured:false}))});await h.mount();t.after(()=>h.unmount());
  assert.equal(h.current().recovery,true);assert.equal(h.calls.length,1);
  let result;await act(async()=>{result=await h.current().updatePassword('NewPassword!123','NewPassword!123');});
  assert.equal(result.error,undefined);assert.equal(h.current().recovery,false);assert.equal(h.window.location.search,'');assert.equal(h.writes.length,0);
  const body=JSON.parse(h.calls.find(call=>call.url.endsWith('/reset-password')).options.body);assert.equal(body.token,token);assert.equal(body.confirmPassword,'NewPassword!123');
});
test('expired reset error preserves the callback for error display without inventing login',async t=>{
  const h=harness({search:'?member_action=reset&token='+'c'.repeat(64),handler:path=>path.endsWith('/reset-password')?json({error:'This link has expired.'},400):json(session())});await h.mount();t.after(()=>h.unmount());
  let result;await act(async()=>{result=await h.current().updatePassword('NewPassword!123');});
  assert.match(result.error,/expired/);assert.equal(h.current().recovery,true);assert.equal(h.current().user,null);
});
test('session expiry clears identity and increments the workspace generation',async t=>{
  let expired=false;const h=harness({handler:path=>{if(path.endsWith('/bookings')){expired=true;return json({error:'Sign in again.'},401);}return json(session(expired?null:student));}});await h.mount();t.after(()=>h.unmount());
  const version=h.current().sessionVersion;
  await act(async()=>{await assert.rejects(()=>h.current().request('/api/member/bookings'));});
  assert.equal(h.current().user,null);assert.ok(h.current().sessionVersion>version);
});
test('logout revokes server session and clears the authenticated identity',async t=>{
  let loggedIn=true;const h=harness({handler:path=>{if(path.endsWith('/logout')){loggedIn=false;return json({ok:true});}return json(session(loggedIn?student:null));}});await h.mount();t.after(()=>h.unmount());
  await act(async()=>{await h.current().signOut();});assert.equal(h.current().user,null);assert.equal(h.calls.find(call=>call.url.endsWith('/logout')).options.method,'POST');
});
test('a stale session response cannot restore a previous account',async t=>{
  const pending=deferred();let calls=0;const h=harness({handler:()=>++calls===2?pending.promise:json(session(calls===1?student:staff))});await h.mount();t.after(()=>h.unmount());
  let old;await act(async()=>{old=h.current().refreshSession();});await act(async()=>{await h.current().refreshSession();});assert.equal(h.current().user.id,staff.id);
  await act(async()=>{pending.resolve(json(session(student)));await old;});assert.equal(h.current().user.id,staff.id);
});
test('public callback presents an explicit confirm button without posting on mount',async t=>{
  const h=harness({search:'?member_action=verify&token='+'d'.repeat(64)});const Public=h.load('PublicWebsite.tsx').default;
  await h.mount(React.createElement(Public));t.after(()=>h.unmount());
  assert.ok(textOf(h.renderer().toJSON()).includes('Confirm email address'));assert.equal(h.calls.filter(call=>call.options.method==='POST').length,0);
});

test('an old unauthorized booking response cannot clear a newer login',async t=>{
  const pending=deferred();let account=student;
  const h=harness({handler:path=>path.endsWith('/bookings')?pending.promise:json(session(account))});await h.mount();t.after(()=>h.unmount());
  let request;await act(async()=>{request=h.current().request('/api/member/bookings').catch(error=>error);});
  account=staff;await act(async()=>h.current().refreshSession());
  await act(async()=>{pending.resolve(json({error:'Old request expired.'},401));await request;});assert.equal(h.current().user.id,staff.id);
});
test('background session validation does not reset an unchanged workspace',async t=>{
  const h=harness({handler:()=>json(session(student))});await h.mount();t.after(()=>h.unmount());const version=h.current().sessionVersion;
  await act(async()=>h.current().refreshSession(true));assert.equal(h.current().sessionVersion,version);assert.equal(h.current().user.id,student.id);
});
test('local signup success links the protected test mailbox and says no email was sent',async t=>{
  const h=harness({search:'#/signup',handler:path=>path.endsWith('/signup')?json({ok:true,needsConfirmation:true},202):json(session(null,{mailMode:'local'}))});
  const Public=h.load('PublicWebsite.tsx').default;await h.mount(React.createElement(Public));t.after(()=>h.unmount());
  const root=h.renderer().root;await act(async()=>{root.findByProps({autoComplete:'name'}).props.onChange({target:{value:'Test Person'}});root.findByProps({type:'email'}).props.onChange({target:{value:'person@example.invalid'}});root.findAllByProps({type:'password'}).forEach(input=>input.props.onChange({target:{value:'StrongPassword!12'}}));});
  await act(async()=>root.findByType('form').props.onSubmit({preventDefault(){}}));
  const text=textOf(h.renderer().toJSON());assert.ok(text.includes('No email was sent.'));assert.equal(root.findByProps({href:'http://localhost:8090/test-mail'}).props.rel,'noopener noreferrer');
});

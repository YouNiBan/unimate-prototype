import assert from 'node:assert/strict';
import test from 'node:test';
import { harness, student, staff, session, json, act, deferred, React, textOf } from './frontend-harness.mjs';
const row={id:'booking-a',title:'Cleaning request',customer:'Test Student',service:'cleaning',status:'requested',amount_pence:0,pricingStatus:'unquoted',created_at:'2026-10-20T09:00:00Z',submission:{intake:{fields:[{label:'Requested date',value:'2026-10-24'},{label:'Address / route',value:'Test-only address'}]}},assignment:null,photos:[]};
const detail=booking=>({row:booking,photos:booking.photos,pricingStatus:booking.pricingStatus,assignment:booking.assignment,submission:booking.submission});
const findButton=(h,label)=>h.renderer().root.findAllByType('button').find(button=>textOf(button).replace(/\s+/g,' ').includes(label));
async function mountBookings(h,props={}) { const {SharedBookings}=h.load('SharedBookings.tsx');await h.mount(React.createElement(SharedBookings,props)); }

test('unquoted request never appears as a free confirmed booking',()=>{
  const h=harness();const {bookingPrice,bookingStatus}=h.load('bookings-api.ts');
  assert.equal(bookingPrice(row),'Awaiting quote');assert.equal(bookingStatus(row.status),'Request received');assert.equal(bookingPrice({...row,pricingStatus:'confirmed',amount_pence:15450}),'£154.50');
});
test('photo validation bounds input and refuses arbitrary remote media paths',async()=>{
  const h=harness();const {photoUpload,privatePhotoPath}=h.load('bookings-api.ts');
  await assert.rejects(()=>photoUpload(new File(['<svg/>'],'image.svg',{type:'image/svg+xml'})),/JPEG, PNG or WebP/);
  await assert.rejects(()=>photoUpload(new File([new Uint8Array(5*1024*1024+1)],'large.png',{type:'image/png'})),/5 MB/);
  assert.throws(()=>privatePhotoPath('booking-a',{id:'photo-a',url:'https://outside.invalid/photo-a'}),/unavailable/);
  assert.equal(privatePhotoPath('booking-a',{id:'photo-a',url:'/api/member/bookings/booking-a/photos/photo-a'}),'/api/member/bookings/booking-a/photos/photo-a');
  const data=await photoUpload(new File(['test bytes'],'photo.png',{type:'image/png'}));assert.equal(data.base64,Buffer.from('test bytes').toString('base64'));
});
test('student request waits for the server before announcing success',async t=>{
  const pending=deferred();const h=harness({handler:(path,options)=>path.endsWith('/session')?json(session(student)):options.method==='POST'?pending.promise:path.endsWith('/booking-a')?json(detail(row)):json({rows:[]})});
  await mountBookings(h);t.after(()=>h.unmount());
  await act(async()=>findButton(h,'Request a service').props.onClick());
  const root=h.renderer().root,{CanonicalServiceForm}=h.load('PrototypeServiceUI.tsx');await act(async()=>root.findByType(CanonicalServiceForm).props.onCheckout({service:'cleaning',title:'Cleaning Services',bookingDate:'24 Oct 2026',bookingAddress:'Test-only address',bookingTime:'09:00–12:00',intake:{fields:[{label:'Clean type',value:'Deep'}],photos:[]}}));
  let sending;await act(async()=>{sending=findButton(h,'Send request').props.onClick();});
  assert.ok(textOf(h.renderer().toJSON()).includes('Saving…'));assert.ok(!textOf(h.renderer().toJSON()).includes('Your request has been saved'));
  const body=JSON.parse(h.calls.find(call=>call.options.method==='POST').options.body);assert.equal(body.service,'cleaning');assert.equal(body.requestedDate,'2026-10-24');assert.ok(!('customer' in body));assert.ok(!('amount_pence' in body));
  await act(async()=>{pending.resolve(json(detail(row),201));await sending;});
  const text=textOf(h.renderer().toJSON());assert.ok(text.includes('Your request has been saved'));assert.ok(text.includes('Awaiting quote'));assert.ok(text.includes('Test-only address'));assert.ok(!text.includes('£0'));
});
test('rejected service requests show the server error without success',async t=>{
  const h=harness({handler:(path,options)=>path.endsWith('/session')?json(session(student)):options.method==='POST'?json({error:'Please check the address.'},400):json({rows:[]})});await mountBookings(h,{initialService:'moving'});t.after(()=>h.unmount());
  const {CanonicalServiceForm}=h.load('PrototypeServiceUI.tsx');await act(async()=>h.renderer().root.findByType(CanonicalServiceForm).props.onCheckout({service:'moving',title:'Moving',bookingDate:'24 Oct 2026',bookingAddress:'Test pickup → Test drop-off',bookingTime:'09:00–12:00',intake:{fields:[{label:'Pickup address',value:'Test pickup'},{label:'Drop-off address',value:'Test drop-off'}],photos:[]}}));await act(async()=>findButton(h,'Send request').props.onClick());
  const text=textOf(h.renderer().toJSON());assert.ok(text.includes('Please check the address.'));assert.ok(!text.includes('Your request has been saved'));
});
test('assigned staff can open an explicitly private job chat with its reference',async t=>{
  const assigned={...row,reference:'UM-000042',status:'confirmed',assignment:{member_id:'staff-member',name:'Test Staff',team:'cleaners'}};
  const h=harness({handler:(path,options)=>path.endsWith('/session')?json(session(staff)):path.endsWith('/conversation')?json({conversationId:'internal-job-thread'}):path.endsWith('/booking-a')?json(detail(assigned)):json({rows:[assigned]})});
  await mountBookings(h);t.after(()=>h.unmount());
  await act(async()=>findButton(h,'Cleaning request').props.onClick());
  const text=textOf(h.renderer().toJSON());assert.match(text,/UM-000042/);assert.match(text,/client cannot see/);assert.match(text,/Only official team inboxes reply/);
  await act(async()=>findButton(h,'Message UniMate about this job').props.onClick());
  const call=h.calls.find(c=>c.url.endsWith('/conversation'));assert.equal(call.options.method,'POST');
  assert.equal(h.window.location.hash,'#/messages?conversation=internal-job-thread');
});

test('staff workspace has assigned jobs and status actions but no student create form',async t=>{
  const assigned={...row,status:'confirmed',pricingStatus:'confirmed',amount_pence:10000,assignment:{member_id:'staff-member',name:'Test Staff',team:'cleaners',starts_at:'2026-10-24T09:00:00Z',ends_at:'2026-10-24T11:00:00Z'}};
  let started=false;const h=harness({handler:(path,options)=>{if(path.endsWith('/session'))return json(session(staff));if(path.endsWith('/status')){started=true;return json(detail({...assigned,status:'in_progress'}));}if(path.endsWith('/booking-a'))return json(detail({...assigned,status:started?'in_progress':'confirmed'}));return json({rows:[assigned]});}});
  await mountBookings(h);t.after(()=>h.unmount());assert.ok(!findButton(h,'Request a service'));
  await act(async()=>findButton(h,'Cleaning request').props.onClick());
  assert.equal(h.renderer().root.findAllByType('input').filter(input=>input.props.type==='file').length,2);
  await act(async()=>findButton(h,'Start service').props.onClick());
  const call=h.calls.find(call=>call.url.endsWith('/status'));assert.equal(JSON.parse(call.options.body).expectedStatus,'confirmed');assert.equal(JSON.parse(call.options.body).status,'in_progress');assert.ok(textOf(h.renderer().toJSON()).includes('Service started.'));
});
test('private photos use credentialed blob requests and revoke URLs on close',async t=>{
  const photo={id:'photo-a',group:'request',filename:'request.png',mime:'image/png',bytes:10,createdAt:row.created_at,url:'/api/member/bookings/booking-a/photos/photo-a'};
  const withPhoto={...row,photos:[photo]};const h=harness({handler:path=>path.endsWith('/session')?json(session(student)):path.endsWith('/photos/photo-a')?{ok:true,status:200,blob:async()=>new Blob(['test image'],{type:'image/png'})}:path.endsWith('/booking-a')?json(detail(withPhoto)):json({rows:[withPhoto]})});
  await mountBookings(h);t.after(()=>h.unmount());await act(async()=>findButton(h,'Cleaning request').props.onClick());
  await act(async()=>{await new Promise(resolve=>setImmediate(resolve));});
  const call=h.calls.find(call=>call.url.endsWith('/photos/photo-a'));assert.equal(call.options.credentials,'include');assert.equal(h.renderer().root.findAllByType('img').length,1,textOf(h.renderer().toJSON()));assert.equal(h.renderer().root.findByType('img').props.src.startsWith('blob:'),true);
  await act(async()=>findButton(h,'All bookings').props.onClick());assert.equal(h.revoked.length,1);
});
test('stale list requests cannot populate another account workspace',async t=>{
  const pending=deferred();let account=student;let lists=0;
  const h=harness({handler:path=>path.endsWith('/session')?json(session(account)):++lists===1?pending.promise:json({rows:[]})});
  await mountBookings(h);t.after(()=>h.unmount());account=staff;await act(async()=>{await h.current().refreshSession();});
  await act(async()=>pending.resolve(json({rows:[row]})));
  const text=textOf(h.renderer().toJSON());assert.ok(!text.includes('Cleaning request'));assert.ok(text.includes('No assigned jobs yet'));
});
test('unsafe API configuration and escaped request paths are refused',async()=>{
  const h=harness();const api=h.load('member-api.ts');
  assert.equal(api.resolveApiBase('http://public.invalid'),'');assert.equal(api.resolveApiBase('https://user:password@example.invalid'),'');assert.equal(api.resolveApiBase('https://example.invalid?key=bad'),'');assert.equal(api.resolveApiBase('http://localhost:8090/'),'http://localhost:8090');
  await assert.rejects(()=>api.apiRequest('/api/../private'),/unavailable/);assert.equal(h.calls.length,0);
});

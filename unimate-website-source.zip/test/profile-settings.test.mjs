import test from 'node:test';
import assert from 'node:assert/strict';
import {harness,React,act,textOf,student,session,json} from './frontend-harness.mjs';
const profile={university:'Fixture University',name:student.name,birthday:'2000-01-01',country:'UK',province:'',profileComplete:true,studentVerified:true};
const button=(h,label)=>h.renderer().root.findAllByType('button').find(b=>textOf(b).trim()===label);
const props={navigate(){},dark:false,onTheme(){},language:'EN',onLanguage(){},onLogout(){},onDeactivated(){}};
async function mount(h,extra={}){await h.mount(React.createElement(h.load('PrototypeProfile.tsx').PrototypeProfile,{...props,...extra}));}
test('prototype profile shows the actual username and all nine original menu sections',async t=>{
 const h=harness({handler:path=>path.endsWith('/session')?json(session({...student,username:'real.member',studentVerified:true})):json(profile)});await mount(h);t.after(()=>h.unmount());
 const text=textOf(h.renderer().root);assert.match(text,/@\s*real.member/);assert.match(text,/Fixture University/);assert.doesNotMatch(text,/Sophie Chen|studybuddy_uk/);
 for(const label of ['Edit profile','Manage profile privacy','Your activity','My events','Marketplace listings','My bookings','My purchase history','Payment methods','Settings'])assert.ok(button(h,label),label);
 await act(async()=>button(h,'Settings').props.onClick());for(const label of ['Change password','Change username','Account verification','Sign out','Deactivate account'])assert.ok(button(h,label),label);
 await act(async()=>button(h,'Change username').props.onClick());assert.ok(h.calls.some(c=>c.url.endsWith('/username')));
});
test('deactivation never submits before two explicit confirmations and password; cancel makes no account mutation',async t=>{
 let closed=0;
 const h=harness({handler:(path,options)=>path.endsWith('/session')?json({...session(student),accountDeactivationEnabled:true}):path.endsWith('/deactivation-request')?json({token:'test-challenge'}):path.endsWith('/deactivate-account')?json({ok:true}):json(profile)});await mount(h,{onDeactivated(){closed++;}});t.after(()=>h.unmount());
 await act(async()=>button(h,'Settings').props.onClick());await act(async()=>button(h,'Deactivate account').props.onClick());
 assert.match(textOf(h.renderer().root),/1 of 2/);assert.equal(h.calls.filter(c=>c.options.method==='POST').length,0);
 await act(async()=>button(h,'Keep my account').props.onClick());assert.equal(h.calls.filter(c=>c.options.method==='POST').length,0);
 await act(async()=>button(h,'Deactivate account').props.onClick());await act(async()=>button(h,'Continue to confirmation').props.onClick());
 assert.match(textOf(h.renderer().root),/2 of 2/);assert.equal(button(h,'Confirm deactivation').props.disabled,true);assert.equal(closed,0);
 const root=h.renderer().root;await act(async()=>{root.findByProps({autoComplete:'off'}).props.onChange({target:{value:'DEACTIVATE'}});root.findByProps({autoComplete:'current-password'}).props.onChange({target:{value:'Fixture-password1!'}});});
 await act(async()=>root.findByType('form').props.onSubmit({preventDefault(){}}));
 assert.equal(closed,1);const sent=JSON.parse(h.calls.find(c=>c.url.endsWith('/deactivate-account')).options.body);assert.deepEqual(sent,{token:'test-challenge',password:'Fixture-password1!',confirmation:'DEACTIVATE'});
});
test('password change waits for server success, sends current password, then refreshes the rotated session',async t=>{
 let submitted;
 const h=harness({handler:(path,options)=>path.endsWith('/session')?json(session(student)):path.endsWith('/change-password')?(submitted=JSON.parse(options.body),json({ok:true})):json(profile)});await mount(h);t.after(()=>h.unmount());
 await act(async()=>button(h,'Settings').props.onClick());await act(async()=>button(h,'Change password').props.onClick());const root=h.renderer().root;
 await act(async()=>{root.findByProps({autoComplete:'current-password'}).props.onChange({target:{value:'Current-pass1!'}});const fields=root.findAllByProps({autoComplete:'new-password'});fields[0].props.onChange({target:{value:'New-password1!'}});fields[1].props.onChange({target:{value:'New-password1!'}});});
 await act(async()=>root.findByType('form').props.onSubmit({preventDefault(){}}));assert.deepEqual(submitted,{password:'Current-pass1!',newPassword:'New-password1!',confirmPassword:'New-password1!'});assert.match(textOf(root),/Password updated/);assert.equal(root.findByProps({autoComplete:'current-password'}).props.value,'');
});

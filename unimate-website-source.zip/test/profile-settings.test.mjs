import test from 'node:test';
import assert from 'node:assert/strict';
import {harness,React,act,textOf,student,session,json} from './frontend-harness.mjs';
const profile={university:'Fixture University',name:student.name,birthday:'2000-01-01',country:'UK',province:'',profileComplete:true,studentVerified:true};
const button=(h,label)=>h.renderer().root.findAllByType('button').find(b=>textOf(b).trim()===label);
const props={navigate(){},dark:false,onTheme(){},language:'EN',onLanguage(){},onLogout(){},onDeactivated(){}};
test('Edit profile has personal content fields but no username or security controls; saves through the backend',async t=>{
 const editable={...profile,country:'GB',bio:'Original bio',interests:['Food'],avatar:'',banner:'',revision:2,profileEditorEnabled:true};let saved;
 const h=harness({handler:(path,options)=>path.endsWith('/session')?json(session({...student,username:'real.member'})):options?.method==='POST'?(saved=JSON.parse(options.body),json({profile:{...editable,...saved,revision:3}})):json(editable)});await mount(h);t.after(()=>h.unmount());await act(async()=>button(h,'Edit profile').props.onClick());
 const root=h.renderer().root,text=textOf(root);for(const label of ['Change profile banner','Camera','Photo library','Display name','Bio','Birthday (YYYY-MM-DD)','Country of origin','Province, city or state','Hobbies and interests','Save profile'])assert.match(text,new RegExp(label.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
 assert.doesNotMatch(text,/Change username|Change password|Account verification|Next username change|Username/);
 await act(async()=>root.findByType('textarea').props.onChange({target:{value:'My new bio'}}));await act(async()=>button(h,'Music').props.onClick());await act(async()=>root.findByType('form').props.onSubmit({preventDefault(){}}));
 assert.equal(saved.bio,'My new bio');assert.deepEqual(saved.interests,['Food','Music']);assert.equal(saved.revision,2);assert.equal(saved.username,undefined);assert.match(textOf(root),/Profile saved/);
});
async function mount(h,extra={}){await h.mount(React.createElement(h.load('PrototypeProfile.tsx').PrototypeProfile,{...props,...extra}));}
test('profile editor keeps unsaved content and shows a real server error instead of false success',async t=>{
 const h=harness({handler:(path,options)=>path.endsWith('/session')?json(session(student)):options?.method==='POST'?json({error:'Your profile changed elsewhere. Reload before saving.'},409):json({...profile,profileEditorEnabled:true,revision:0})});await mount(h);t.after(()=>h.unmount());await act(async()=>button(h,'Edit profile').props.onClick());const root=h.renderer().root;await act(async()=>root.findByType('textarea').props.onChange({target:{value:'Unsaved content'}}));await act(async()=>root.findByType('form').props.onSubmit({preventDefault(){}}));assert.equal(root.findByType('textarea').props.value,'Unsaved content');assert.match(textOf(root),/changed elsewhere/);assert.doesNotMatch(textOf(root),/Profile saved/);
});
test('prototype profile shows the actual username and all nine original menu sections',async t=>{
 const h=harness({handler:path=>path.endsWith('/session')?json(session({...student,username:'real.member',studentVerified:true})):json(profile)});await mount(h);t.after(()=>h.unmount());
 const text=textOf(h.renderer().root);assert.match(text,/@\s*real.member/);assert.match(text,/Fixture University/);assert.doesNotMatch(text,/Sophie Chen|studybuddy_uk/);
 for(const label of ['Edit profile','Manage profile privacy','Your activity','My events','Marketplace listings','My bookings','My purchase history','Payment methods','Settings'])assert.ok(button(h,label),label);
 await act(async()=>button(h,'Settings').props.onClick());for(const label of ['Change password','Change username','Account verification','Sign out','Deactivate account'])assert.ok(button(h,label),label);
 await act(async()=>button(h,'Change username').props.onClick());assert.ok(h.calls.some(c=>c.url.endsWith('/username')));
});
test('deactivation never submits before two explicit confirmations and password; cancel makes no account mutation',async t=>{
 let closed=0;
 const h=harness({handler:(path,options)=>path.endsWith('/session')?json({...session(student),accountDeactivationEnabled:true}):path.endsWith('/deactivation-request')?json({token:'test-challenge'}):path.endsWith('/deactivate-account')?json({ok:true}):json(profile)});await mount(h,{onDeactivated(){closed++;}});t.after(()=>h.unmount());
 await act(async()=>button(h,'Settings').props.onClick());await act(async()=>button(h,'Deactivate account').props.onClick());
 assert.match(textOf(h.renderer().root),/1 of 2/);assert.equal(h.calls.filter(c=>c.options.method==='POST').length,0);
 await act(async()=>button(h,'Keep my account').props.onClick());assert.equal(h.calls.filter(c=>c.options.method==='POST').length,0);
 await act(async()=>button(h,'Deactivate account').props.onClick());await act(async()=>button(h,'Continue to confirmation').props.onClick());
 assert.match(textOf(h.renderer().root),/2 of 2/);assert.equal(button(h,'Confirm deactivation').props.disabled,true);assert.equal(closed,0);
 const root=h.renderer().root;await act(async()=>{root.findByProps({autoComplete:'off'}).props.onChange({target:{value:'DEACTIVATE'}});root.findByProps({autoComplete:'current-password'}).props.onChange({target:{value:'Fixture-password1!'}});});
 await act(async()=>root.findByType('form').props.onSubmit({preventDefault(){}}));
 assert.equal(closed,1);const sent=JSON.parse(h.calls.find(c=>c.url.endsWith('/deactivate-account')).options.body);assert.deepEqual(sent,{token:'test-challenge',password:'Fixture-password1!',confirmation:'DEACTIVATE'});
});
test('password change waits for server success, sends current password, then refreshes the rotated session',async t=>{
 let submitted;
 const h=harness({handler:(path,options)=>path.endsWith('/session')?json(session(student)):path.endsWith('/change-password')?(submitted=JSON.parse(options.body),json({ok:true})):json(profile)});await mount(h);t.after(()=>h.unmount());
 await act(async()=>button(h,'Settings').props.onClick());await act(async()=>button(h,'Change password').props.onClick());const root=h.renderer().root;
 await act(async()=>{root.findByProps({autoComplete:'current-password'}).props.onChange({target:{value:'Current-pass1!'}});const fields=root.findAllByProps({autoComplete:'new-password'});fields[0].props.onChange({target:{value:'New-password1!'}});fields[1].props.onChange({target:{value:'New-password1!'}});});
 await act(async()=>root.findByType('form').props.onSubmit({preventDefault(){}}));assert.deepEqual(submitted,{password:'Current-pass1!',newPassword:'New-password1!',confirmPassword:'New-password1!'});assert.match(textOf(root),/Password updated/);assert.equal(root.findByProps({autoComplete:'current-password'}).props.value,'');
});

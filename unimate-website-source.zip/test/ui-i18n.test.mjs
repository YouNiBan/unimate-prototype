import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {translateUi,translateCurrent,bindText,setUiLanguage} from '../ui-i18n.mjs';
import {uiTranslations} from '../ui-translations.mjs';

test('both Chinese catalogues keep interpolation values intact',()=>{
  for(const [source,translations] of Object.entries(uiTranslations)){
    assert.equal(translations.length,2,source);
    const placeholders=value=>[...value.matchAll(/\{\w+\}/g)].map(match=>match[0]).sort();
    for(const translation of translations){
      assert.ok(translation.trim(),source);
      assert.deepEqual(placeholders(translation),placeholders(source),source);
    }
  }
  assert.equal(translateUi('简体','Download {filename}',{filename:'My Bookings.pdf'}),'下载My Bookings.pdf');
});

test('live language changes translate interface copy while preserving user content',()=>{
  const label={isConnected:true},feedback={isConnected:true},userContent={isConnected:true};
  setUiLanguage('EN');
  bindText(label,'Account views');
  bindText(feedback,()=>'No matching bookings or holidays');
  bindText(userContent,'Account views',false);
  for(const language of ['简体','繁體','EN']){
    setUiLanguage(language);
    assert.equal(label.textContent,translateUi(language,'Account views'));
    assert.equal(feedback.textContent,translateUi(language,'No matching bookings or holidays'));
    assert.equal(userContent.textContent,'Account views');
  }
});

test('language switches do not reset changing counts or substitute user values twice',()=>{
  let count=2;
  const label={isConnected:true};
  bindText(label,()=>translateCurrent('{count} records · Page {page}',{count,page:1}));
  count=3;
  setUiLanguage('繁體');
  assert.match(label.textContent,/3/);
  assert.ok(!label.textContent.includes('records'));
  setUiLanguage('EN');
  assert.equal(label.textContent,'3 records · Page 1');
});

test('website and administration share the same translation and chat modules',()=>{
  for(const file of ['ui-i18n.mjs','ui-translations.mjs','shared-chat.mjs']){
    assert.equal(readFileSync(new URL('../'+file,import.meta.url),'utf8'),
      readFileSync(new URL('../../unimate-prototype/backend/public/'+file,import.meta.url),'utf8'),file);
  }
});

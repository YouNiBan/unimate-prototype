import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';
import {harness,React,act,textOf,session,json} from './frontend-harness.mjs';
test('successful signup unmounts username lookup instead of reporting its own reservation as unavailable',async t=>{
 let registered=false;const h=harness({search:'#/signup',handler:(path,options)=>path.endsWith('/session')?json(session(null)):path.endsWith('/signup')?(registered=true,json({ok:true,needsConfirmation:true},202)):json({username:'test.name',valid:true,available:!registered,suggestions:[],message:registered?'Username unavailable':'Username available'})});
 await h.mount(React.createElement(h.load('PublicWebsite.tsx').default));t.after(()=>h.unmount());
 const input=key=>h.renderer().root.findAllByType('input').find(n=>n.props.autoComplete===key);
 await act(async()=>{input('name').props.onChange({target:{value:'Test Person'}});input('username').props.onChange({target:{value:'test.name'}});input('email').props.onChange({target:{value:'test@example.invalid'}});for(const n of h.renderer().root.findAllByType('input').filter(n=>n.props.type==='password'))n.props.onChange({target:{value:'ExamplePassword123!'}});});
 await act(()=>new Promise(r=>setTimeout(r,500)));assert.match(textOf(h.renderer().root),/Username available/);
 await act(async()=>h.renderer().root.findByType('form').props.onSubmit({preventDefault(){}}));
 const count=h.calls.filter(c=>c.url.includes('username-availability')).length;await act(()=>new Promise(r=>setTimeout(r,500)));
 assert.equal(h.calls.filter(c=>c.url.includes('username-availability')).length,count);assert.equal(h.renderer().root.findAllByType('form').length,0);assert.match(textOf(h.renderer().root),/Check your email/);assert.doesNotMatch(textOf(h.renderer().root),/Username unavailable/);assert.ok(registered);
});
test('email confirmation shows an account-ready handoff without silently logging in or reposting the token',async t=>{
 const h=harness({search:'?member_action=verify&token='+'a'.repeat(64)+'#/verify-email',handler:path=>path.endsWith('/session')?json(session(null)):json({ok:true})});await h.mount(React.createElement(h.load('PublicWebsite.tsx').default));t.after(()=>h.unmount());assert.equal(h.calls.filter(c=>c.url.endsWith('/verify')).length,0);
 await act(async()=>h.renderer().root.findByType('form').props.onSubmit({preventDefault(){}}));assert.match(textOf(h.renderer().root),/Your account is ready/);assert.match(textOf(h.renderer().root),/Sign in to my account/);assert.equal(h.renderer().root.findAllByType('form').length,0);assert.equal(h.current().user,null);assert.equal(h.calls.filter(c=>c.url.endsWith('/verify')).length,1);assert.equal(h.window.location.search,'');
 const go=h.renderer().root.findAllByType('button').find(b=>textOf(b)==='Sign in to my account');await act(async()=>go.props.onClick());assert.equal(h.window.location.hash,'#/signin');assert.ok(h.renderer().root.findAllByType('input').some(n=>n.props.type==='email'));
});
test('dark shell supplies legacy card tokens, readable fields and opaque placeholders; flight starts empty',()=>{
 const css=readFileSync(new URL('../dark-contrast.css',import.meta.url),'utf8');assert.match(css,/--text:var\(--ink\)/);assert.match(css,/-webkit-text-fill-color:var\(--ink\)/);assert.match(css,/color:#bacbdf[^}]*opacity:1/);
 const ui=readFileSync(new URL('../PrototypeServiceUI.tsx',import.meta.url),'utf8');assert.match(ui,/\[flightNumber, setFlightNumber\] = useState\(""\)/);assert.doesNotMatch(ui,/useState\("BA 2836"\)/);
});

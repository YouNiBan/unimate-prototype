import assert from 'node:assert/strict';
import test from 'node:test';
import { harness, student, session, json, act, deferred, React, textOf } from './frontend-harness.mjs';

for(const change of ['unmount','account','booking']){
  test(`an old checkout cannot navigate after ${change} changes`,async t=>{
    const pending=deferred(),redirects=[];let account=student;
    const h=harness({handler:(path,options)=>path.endsWith('/session')?json(session(account)):path.endsWith('/checkout')?pending.promise:path.endsWith('/config')?json({enabled:true,mode:'test'}):json({payment:null})});
    h.window.location.assign=url=>redirects.push(url);
    const {BookingPayment}=h.load('BookingPayment.tsx');
    const component=id=>React.createElement(BookingPayment,{bookingId:id,bookingStatus:'confirmed',quoted:true});
    await h.mount(component('booking-a'));t.after(()=>h.unmount());
    const pay=h.renderer().root.findAllByType('button').find(button=>textOf(button).includes('Pay with Stripe'));
    await act(async()=>pay.props.onClick());
    if(change==='unmount')await h.update(null);
    else if(change==='booking')await h.update(component('booking-b'));
    else{account={...student,id:'another-student',name:'Another fixture'};await act(async()=>h.current().refreshSession(true));}
    await act(async()=>pending.resolve(json({mode:'test',url:'https://checkout.stripe.com/c/pay/fixture-only'})));
    assert.deepEqual(redirects,[]);
  });
}

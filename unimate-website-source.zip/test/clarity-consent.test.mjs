import test from 'node:test';
import assert from 'node:assert/strict';
import {eligibleForClarity} from '../clarity-consent.mjs';
const allowed={hostname:'hellounimate.com',search:'',hash:'#/home',signedIn:false,loading:false};
test('recording is limited to signed-out public homepage without query data',()=>{
 assert.equal(eligibleForClarity(allowed),true);
 for(const patch of [{hostname:'localhost'},{hostname:'admin.hellounimate.com'},{search:'?email=private'},{hash:'#/signin'},{hash:'#/signup'},{hash:'#/messages'},{hash:'#/profile'},{hash:'#/bookings'},{hash:'#/owner-views'},{signedIn:true},{loading:true}])assert.equal(eligibleForClarity({...allowed,...patch}),false);
});
test('consent prevents loading and leaving a recorded document forces reload',async()=>{
 const values=new Map(),scripts=[];let reloads=0;
 globalThis.localStorage={getItem:k=>values.get(k)||null,setItem:(k,v)=>values.set(k,v)};
 globalThis.window={location:{hash:'#/home',reload:()=>reloads++}};
 globalThis.document={documentElement:{setAttribute:()=>{}},createElement:()=>({dataset:{}}),head:{append:s=>scripts.push(s)}};
 const m=await import('../clarity-consent.mjs?isolated');
 m.startClarity();assert.equal(scripts.length,0);m.saveConsent('declined');m.startClarity();assert.equal(scripts.length,0);
 m.saveConsent('accepted');m.startClarity();m.startClarity();assert.equal(scripts.length,1);assert.equal(window.clarity.q[0][1].ad_Storage,'denied');
 assert.equal(m.leaveRecordedHome('#/home'),false);assert.equal(m.leaveRecordedHome('#/signin'),true);assert.equal(reloads,1);assert.equal(window.location.hash,'#/signin');
 m.saveConsent('declined');assert.equal(reloads,2);
 delete globalThis.localStorage;delete globalThis.window;delete globalThis.document;
});

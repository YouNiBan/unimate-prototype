import test from 'node:test';import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {harness,React,act,textOf,student,session,json} from './frontend-harness.mjs';
const initial={username:'old.name',changedAt:'2025-01-01T00:00:00Z',nextChangeAt:'2025-04-01T00:00:00Z',canChange:true};
test('staff profile exposes username settings while students retain onboarding settings',()=>{
 const source=readFileSync(new URL('../PublicWebsite.tsx',import.meta.url),'utf8');
 assert.match(source,/staff\?<UsernameSettings key=\{auth\.user\?\.id\}\/>:<StudentOnboarding/);
});
test('username settings confirms password, refreshes identity and displays the server cooldown',async t=>{
 let user={...student,username:'old.name'},submitted;
 const h=harness({handler:(path,options)=>{if(path.endsWith('/session'))return json(session(user));if(path.endsWith('/username')&&options.method==='POST'){submitted=JSON.parse(options.body);user={...user,username:submitted.username};return json({...initial,username:submitted.username,canChange:false,nextChangeAt:'2027-01-21T00:00:00Z'});}if(path.endsWith('/username'))return json(initial);return json({valid:true,available:true,suggestions:[],message:'Username available'});}});
 const {UsernameSettings}=h.load('UsernameSettings.tsx');await h.mount(React.createElement(UsernameSettings));t.after(()=>h.unmount());const root=h.renderer().root;
 await act(async()=>root.findAllByType('button').find(n=>textOf(n)==='Change username').props.onClick());
 await act(async()=>{root.findByProps({autoComplete:'username'}).props.onChange({target:{value:'new.name_'}});root.findByProps({autoComplete:'current-password'}).props.onChange({target:{value:'Fixture-password1!'}});});
 await act(async()=>{await root.findByType('form').props.onSubmit({preventDefault(){}});});
 assert.deepEqual(submitted,{username:'new.name_',password:'Fixture-password1!',expectedUsername:'old.name'});assert.equal(h.current().user.username,'new.name_');assert.match(textOf(root),/Next username change.*21 January 2027/);assert.equal(root.findAllByProps({type:'password'}).length,0);
});
test('a locked username shows its next date without a change form; a rejected password cannot claim success',async t=>{
 const locked=harness({handler:path=>path.endsWith('/session')?json(session(student)):json({...initial,canChange:false})});const {UsernameSettings}=locked.load('UsernameSettings.tsx');await locked.mount(React.createElement(UsernameSettings));assert.match(textOf(locked.renderer().root),/Next username change/);assert.equal(locked.renderer().root.findAllByType('form').length,0);await locked.unmount();
 const h=harness({handler:(path,options)=>path.endsWith('/session')?json(session(student)):options.method==='POST'?json({error:'Your current password is incorrect.'},403):json(initial)});const C=h.load('UsernameSettings.tsx').UsernameSettings;await h.mount(React.createElement(C));t.after(()=>h.unmount());const root=h.renderer().root;await act(async()=>root.findAllByType('button').find(n=>textOf(n)==='Change username').props.onClick());await act(async()=>{await root.findByType('form').props.onSubmit({preventDefault(){}});});assert.match(textOf(root),/current password is incorrect/);assert.doesNotMatch(textOf(root),/Username updated/);assert.equal(root.findByProps({type:'password'}).props.value,'');
});
test('Friends search displays matching handles and connection usernames',async t=>{
 const h=harness({handler:path=>path.endsWith('/session')?json(session(student)):json({rows:[{id:'friend',name:'Friend',username:'my.friend',status:'accepted'}],matches:[{id:'person',name:'Jenna',username:'jenna.food'}]})});const {StudentConnections}=h.load('RestaurantCommunity.tsx');await h.mount(React.createElement(StudentConnections));t.after(()=>h.unmount());const text=textOf(h.renderer().root);assert.match(text,/Search by name or username/);assert.match(text,/@\s*jenna.food/);assert.match(text,/@\s*my.friend/);
});

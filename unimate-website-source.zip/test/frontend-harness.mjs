import { readFileSync, existsSync } from 'node:fs';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, extname } from 'node:path';
import vm from 'node:vm';
const require = createRequire(import.meta.url);
export const React = require('react');
export const { create, act } = require('react-test-renderer');
const ts = require('typescript');
const root = fileURLToPath(new URL('../', import.meta.url));
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
export const student = { id: 'student-a', email: 'student@example.invalid', name: 'Test Student', role: 'student', staffTeams: [] };
export const staff = { id: 'staff-a', email: 'staff@example.invalid', name: 'Test Staff', role: 'staff', staffTeams: ['cleaners'] };
export const session = (user = null, extra = {}) => ({ user, csrf: 'test-csrf-token', configured: true, registrationEnabled: true, mailConfigured: true, ...extra });
export const json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
export function deferred() { let resolve, reject; const promise = new Promise((a,b) => { resolve=a; reject=b; }); return { promise, resolve, reject }; }
export function harness({ configured = true, handler = () => json(session()), search = '' } = {}) {
  const calls=[], writes=[], storage=new Map(), listeners=new Map(), modules=new Map(), revoked=[];
  const location = new URL('http://localhost:8083/' + search);
  const localStorage = { getItem: key => storage.get(key) ?? null, setItem: (key,value) => { writes.push({key,value}); storage.set(key,value); }, removeItem: key => storage.delete(key) };
  const window = { location, localStorage, addEventListener(name, fn) { listeners.set(name,fn); }, removeEventListener(name) { listeners.delete(name); }, history: { state: null, replaceState(_state,_title,path) { window.location = new URL(path,window.location); } } };
  const document = { visibilityState:'visible', documentElement:{dataset:{},lang:''}, title:'', addEventListener(name,fn){listeners.set(name,fn);}, removeEventListener(name){listeners.delete(name);}, getElementById(){return null;} };
  class TestURL extends URL { static createObjectURL(){return 'blob:test-'+Math.random();} static revokeObjectURL(value){revoked.push(value);} }
  const context=vm.createContext({ console, process:{env:configured ? { EXPO_PUBLIC_API_URL:'http://localhost:8090' } : {}}, URL:TestURL,URLSearchParams,setTimeout,clearTimeout,setInterval,clearInterval,crypto:globalThis.crypto,AbortController,Blob,File,Uint8Array,btoa,atob,Error,Intl,Date,Promise,window,document,localStorage,fetch:async(url,options)=>{calls.push({url,options});return handler(new URL(url).pathname, options, calls);}});
  function load(path) {
    const absolute=resolve(root,path);
    let file=absolute;
    if(!existsSync(file)) file=['.tsx','.ts','.mjs'].map(extension=>absolute+extension).find(existsSync);
    if(!file) throw Error('Module missing: '+absolute);
    if(modules.has(file)) return modules.get(file).exports;
    const module={exports:{}};modules.set(file,module);
    const source=ts.transpileModule(readFileSync(file,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText;
    const localRequire=name=> {
      if(name.endsWith('.css')) return {};
      if(/\.(jpg|png|webp)$/.test(name)) return name;
      if(name==='react-native') return {Image:'img',View:'div',Text:'span',TextInput:'input',Pressable:'button',ScrollView:'div',Modal:({visible,children})=>visible?children:null,StyleSheet:{create:value=>value,flatten:value=>Array.isArray(value)?Object.assign({},...value.filter(Boolean)):value},Alert:{alert(){}},useWindowDimensions:()=>({width:1280,height:800}),Platform:{OS:'web'}};
      if(name==='@expo/vector-icons') return {Ionicons:props=>React.createElement('span',{'data-icon':props.name})};
      if(name==='expo-image-picker') return {};
      if(name.includes('AppIcons')) return {AppIonicons:props=>React.createElement('span',{'data-icon':props.name}),UniMateLogo:()=>React.createElement('span',null,'UniMate'),UniMateMomentsIcon:()=>React.createElement('span',null,'Moments')};
      if(name.includes('ForumIcon')) return {__esModule:true,default:()=>React.createElement('span',null,'Forum')};
      if(name.startsWith('.')) return load(resolve(dirname(file),name));
      return require(name);
    };
    const fn=vm.runInContext('(function(require,module,exports){'+source+'\n})',context,{filename:file});fn(localRequire,module,module.exports);return module.exports;
  }
  let value,renderer;
  const auth=load('auth.tsx');
  function Capture(){value=auth.useAuth();return null;}
  return {load,calls,writes,window,document,listeners,revoked,current:()=>value,renderer:()=>renderer,
    async mount(component){await act(async()=>{renderer=create(React.createElement(auth.AuthProvider,null,React.createElement(Capture),component));});},
    async update(component){await act(async()=>renderer.update(React.createElement(auth.AuthProvider,null,React.createElement(Capture),component)));},
    async unmount(){await act(async()=>renderer?.unmount());},
  };
}
export function textOf(node) { return typeof node==='string' ? node : Array.isArray(node) ? node.map(textOf).join(' ') : node?.children ? node.children.map(textOf).join(' ') : ''; }

import assert from 'node:assert/strict';
import test from 'node:test';
import { readFileSync } from 'node:fs';
import { createSharedChat, encodeChatAttachments, createComposerTools } from '../shared-chat.mjs';
import { harness, student, staff, session, json, act, deferred, React, textOf } from './frontend-harness.mjs';

const conversation = {
  id: 'support-a', subject: 'Fixture booking question', category: 'booking', status: 'open',
  participant: { id: student.id, name: student.name, role: 'student' },
  updatedAt: '2026-10-20T10:00:00Z', lastMessage: 'Fixture message', unreadCount: 1, bookingId: null,
};
const incoming = { id: 'message-a', body: 'Fixture reply', createdAt: conversation.updatedAt, sender: { id: 'support-user', name: 'Test Responder', kind: 'support' }, clientId: 'fixture-client' };
const detail = { conversation, messages: [incoming], total: 1, page: 1 };
const list = rows => ({ rows, total: rows.length, page: 1, counts: { open: rows.length, closed: 0 }, unread: rows.length });
const findButton = (h,label) => h.renderer().root.findAllByType('button').find(button => textOf(button).includes(label));
async function mountSupport(h) { const { SharedSupport } = h.load('SharedSupport.tsx'); await h.mount(React.createElement(SharedSupport)); }

class Element {
  constructor(tag, doc) { this.tagName = tag; this.ownerDocument = doc; this.children = []; this.attributes = {}; this.value = ''; this.text = ''; this.scrollTop = 0; this.scrollHeight = 500; this.clientHeight = 400; }
  set textContent(value) { this.text = String(value); this.children = []; }
  get textContent() { return this.text + this.children.map(child => child.textContent).join(''); }
  set innerHTML(_) { throw Error('HTML interpretation is forbidden in this renderer'); }
  append(...children) { for(const child of children)child.parentNode=this;this.children.push(...children); }
  replaceChildren(...children) { this.text = '';this.children.forEach(child=>child.parentNode=null); this.children = [];this.append(...children); }
  get lastChild(){return this.children.at(-1);}
  get isConnected(){return this.rooted||this.parentNode?.isConnected||false;}
  remove(){if(this.parentNode){this.parentNode.children=this.parentNode.children.filter(child=>child!==this);this.parentNode=null;}}
  focus(){this.ownerDocument.activeElement=this;}
  click(){this.onclick?.({});}
  setSelectionRange(start,end){this.selectionStart=start;this.selectionEnd=end;}
  setAttribute(name,value) { this.attributes[name] = value; }
  all(predicate) { return [this, ...this.children.flatMap(child => child.all(predicate))].filter(predicate); }
  byClass(className) { return this.all(item => item.className?.split(' ').includes(className))[0]; }
}
function view(overrides = {}) {
  const doc = { createElement: tag => new Element(tag, doc) };
  const container = new Element('div', doc);
  container.rooted=true;
  const renderer = createSharedChat(container);
  const props = { ...detail, viewer: 'member', draft: { body: '' }, onSend: async () => {}, onStatus: async () => {}, onPage() {}, ...overrides };
  renderer.update(props);
  return { container, renderer, props, input: container.all(item => item.tagName === 'textarea')[0], form: container.all(item => item.tagName === 'form')[0] };
}

test('member and admin ship identical conversation renderer and styles', () => {
  for (const filename of ['shared-chat.mjs', 'shared-chat.css']) {
    assert.equal(readFileSync(new URL('../'+filename, import.meta.url), 'utf8'),
      readFileSync(new URL('../../unimate-prototype/backend/public/'+filename, import.meta.url), 'utf8'));
  }
});
test('shared renderer treats markup as text, shows the team publicly and keeps the named responder internal', () => {
  const body = '<img src=x onerror=alert(1)> literal fixture';
  const { container } = view({ messages: [{ ...incoming, body }] });
  assert.ok(container.textContent.includes(body));
  assert.ok(container.textContent.includes('UniMate Support'));
  assert.ok(!container.textContent.includes('Test Responder'));
  assert.equal(container.all(item => item.tagName === 'img' && item.src).length, 0);
  assert.equal(container.byClass('shared-chat-message').className, 'shared-chat-message');
  const admin = view({ viewer: 'support' });
  assert.ok(admin.container.textContent.includes('UniMate Support · Test Responder'));
  assert.ok(admin.container.byClass('shared-chat-message').className.includes('is-own'));
  assert.ok(!container.textContent.includes('Delivered'));
  assert.ok(!container.textContent.includes('Read by'));
});
test('internal job chat shows its audience and shared job reference to staff and team',()=>{
  for(const viewer of ['member','support']){
    const {container}=view({viewer,conversation:{...conversation,bookingId:'booking-a',bookingReference:'UM-000042',audience:'staff_internal'}});
    assert.match(container.textContent,/UM-000042/);
    assert.match(container.textContent,/Internal staff chat — not visible to client/);
  }
});

test('refresh preserves the same composer element and unfinished draft', () => {
  const current = view();
  current.input.value = 'An unfinished reply';
  current.input.oninput();
  current.renderer.update({ ...current.props, messages: [incoming, { ...incoming, id: 'message-b' }] });
  assert.equal(current.input, current.container.all(item => item.tagName === 'textarea')[0]);
  assert.equal(current.input.value, 'An unfinished reply');
  assert.equal(current.props.draft.body, 'An unfinished reply');
});
test('failed send retains text and idempotency key; editing produces a new attempt key', async () => {
  const attempts = [];
  const current = view({ onSend: async (body, clientId) => { attempts.push({ body, clientId }); throw Error('Connection interrupted'); } });
  current.input.value = 'Please help'; current.input.oninput();
  await current.form.onsubmit({ preventDefault() {} });
  await current.form.onsubmit({ preventDefault() {} });
  assert.equal(attempts[0].clientId, attempts[1].clientId);
  assert.equal(current.input.value, 'Please help');
  assert.equal(current.container.byClass('shared-chat-error').textContent, 'Connection interrupted');
  current.input.value = 'Updated question'; current.input.oninput();
  await current.form.onsubmit({ preventDefault() {} });
  assert.notEqual(attempts[1].clientId, attempts[2].clientId);
});
test('send is pending until confirmed and closed conversations cannot send', async () => {
  const pending = deferred();
  const current = view({ onSend: () => pending.promise });
  current.input.value = 'Pending message'; current.input.oninput();
  const sending = current.form.onsubmit({ preventDefault() {} });
  assert.equal(current.input.disabled, true);
  assert.equal(current.input.value, 'Pending message');
  pending.resolve(); await sending;
  assert.equal(current.input.value, '');
  assert.equal(current.props.draft.body, '');
  current.renderer.update({ ...current.props, conversation: { ...conversation, status: 'closed' } });
  assert.equal(current.form.hidden, true);
  assert.equal(current.container.byClass('shared-chat-closed').hidden, false);
});
test('member API uses cookie/CSRF auth and server-owned sender identity', async t => {
  const h = harness({ handler: path => path.endsWith('/session') ? json(session(student)) : json({ ok: true }) });
  await h.mount(); t.after(() => h.unmount());
  const { supportApi } = h.load('support-api.ts');
  await supportApi(h.current().request).send('support-a', 'Fixture reply', 'fixture-id');
  const call = h.calls.find(call => call.url.endsWith('/support-a/messages'));
  assert.equal(call.options.credentials, 'include');
  assert.equal(call.options.headers['X-CSRF-Token'], 'test-csrf-token');
  assert.deepEqual(JSON.parse(call.options.body), { body: 'Fixture reply', clientId: 'fixture-id', attachments: [] });
});
test('member create waits for persistence, preserves failed inputs and retries the same payload safely', async t => {
  let fail = true;
  const h = harness({ handler: (path,options) => path.endsWith('/session') ? json(session(student,{mailMode:'local'})) : options.method === 'POST' ? fail ? json({error:'Please try again.'},503) : json(detail,201) : path.endsWith('/support-a') ? json(detail) : json(list([])) });
  await mountSupport(h); t.after(() => h.unmount());
  await act(async () => findButton(h,'New message').props.onClick());
  await act(async () => {
    h.renderer().root.findAllByType('input').find(input => input.props.minLength === 2).props.onChange({target:{value:'A fixture question'}});
    h.renderer().root.findByType('textarea').props.onChange({target:{value:'Fixture details'}});
  });
  await act(async () => h.renderer().root.findByType('form').props.onSubmit({preventDefault(){}}));
  assert.ok(textOf(h.renderer().toJSON()).includes('Please try again.'));
  assert.equal(h.renderer().root.findByType('textarea').props.value,'Fixture details');
  fail = false;
  await act(async () => h.renderer().root.findByType('form').props.onSubmit({preventDefault(){}}));
  const sent = h.calls.filter(call => call.options.method === 'POST').map(call => JSON.parse(call.options.body));
  assert.equal(sent[0].clientId, sent[1].clientId);
  assert.equal(sent[0].category, 'general');
  assert.ok(!('recipientId' in sent[0])); assert.ok(!('sender' in sent[0]));
  assert.ok(textOf(h.renderer().toJSON()).includes('Local testing.'));
  assert.equal(h.renderer().root.findAllByProps({className:'support-inbox has-selection'}).length,1);
  const opened=h.renderer().root.findAll(node=>node.type?.name==='Conversation')[0];
  assert.equal(opened.props.detail.conversation.id,conversation.id);
});
test('account change clears old conversations and ignores a stale inbox response', async t => {
  const pending = deferred(); let account = student; let lists = 0;
  const h = harness({ handler: path => path.endsWith('/session') ? json(session(account)) : ++lists === 1 ? pending.promise : json(list([])) });
  await mountSupport(h); t.after(() => h.unmount());
  account = staff; await act(async () => h.current().refreshSession());
  await act(async () => pending.resolve(json(list([conversation]))));
  assert.ok(!textOf(h.renderer().toJSON()).includes(conversation.subject));
  assert.ok(textOf(h.renderer().toJSON()).includes('No conversations yet'));
});
test('listing conversations does not mark them read', async t => {
  const h = harness({ handler: path => path.endsWith('/session') ? json(session(student)) : json(list([conversation])) });
  await mountSupport(h); t.after(() => h.unmount());
  assert.ok(textOf(h.renderer().toJSON()).includes(conversation.subject));
  assert.equal(h.calls.filter(call => call.options.method === 'POST').length,0);
});
test('attachment encoding rejects invalid types/count/size before reading',async()=>{
  await assert.rejects(()=>encodeChatAttachments([new File(['<svg/>'],'bad.svg',{type:'image/svg+xml'})]),/PNG, JPEG, WebP or PDF/);
  await assert.rejects(()=>encodeChatAttachments([new File([new Uint8Array(5*1024*1024+1)],'large.png',{type:'image/png'})]),/5 MB/);
  await assert.rejects(()=>encodeChatAttachments([new File(['x'],'fixture.pdf',{type:'application/pdf'})],3),/3 attachments/);
  const encoded=await encodeChatAttachments([new File(['%PDF-fixture'],'fixture.pdf',{type:'application/pdf'})]);
  assert.equal(encoded[0].base64,Buffer.from('%PDF-fixture').toString('base64'));
});
test('attachment-only replies retain files on failure and retry with the same key',async()=>{
  const attachment={filename:'fixture.pdf',mime:'application/pdf',base64:btoa('%PDF-fixture')};
  const attempts=[];const current=view({draft:{body:'',attachments:[attachment]},onSend:async(body,clientId,attachments)=>{attempts.push({body,clientId,attachments});throw Error('Offline');}});
  assert.equal(current.input.required,false);
  await current.form.onsubmit({preventDefault(){}});
  await current.form.onsubmit({preventDefault(){}});
  assert.equal(attempts[0].body,'');assert.equal(attempts[0].clientId,attempts[1].clientId);
  assert.deepEqual(current.props.draft.attachments,[attachment]);
  current.renderer.destroy();
});
test('emoji inserts at the caret and keeps the composer focused',()=>{
  const current=view();current.input.value='Hello there';current.input.selectionStart=6;current.input.selectionEnd=6;
  const emoji=current.container.all(node=>node.attributes['aria-label']==='Insert smile emoji')[0];
  emoji.click();
  assert.equal(current.input.value,'Hello 🙂there');
  assert.equal(current.props.draft.body,'Hello 🙂there');
  assert.equal(current.input.ownerDocument.activeElement,current.input);
  assert.equal(current.input.selectionStart,8);
  current.renderer.destroy();
});
test('private attachment paths cannot leave the selected conversation',()=>{
  const h=harness(),{privateSupportAttachmentPath}=h.load('support-api.ts');
  assert.equal(privateSupportAttachmentPath('support-a','/api/member/support/support-a/attachments/file-a'),'/api/member/support/support-a/attachments/file-a');
  for(const path of ['https://outside.invalid/a.pdf','/api/member/support/other/attachments/file-a','/api/support/support-a/attachments/file-a','/api/member/support/support-a/attachments/../file-a'])
    assert.throws(()=>privateSupportAttachmentPath('support-a',path),/unavailable/);
});
test('private PDFs become download links and object URLs are revoked on close',async()=>{
  const attachment={id:'file-a',filename:'fixture.pdf',mime:'application/pdf',bytes:12,url:'/api/member/support/support-a/attachments/file-a'};
  const revoked=[],original=URL.revokeObjectURL;URL.revokeObjectURL=url=>{revoked.push(url);original(url);};
  try{
    const current=view({messages:[{...incoming,body:'',attachments:[attachment]}],loadAttachment:async()=>new Blob(['%PDF-fixture'],{type:'application/pdf'})});
    await new Promise(resolve=>setImmediate(resolve));
    const link=current.container.all(node=>node.tagName==='a')[0];
    assert.equal(link.download,'fixture.pdf');assert.ok(link.href.startsWith('blob:'));
    assert.equal(current.container.all(node=>node.tagName==='iframe').length,0);
    current.renderer.destroy();assert.ok(revoked.includes(link.href));
  }finally{URL.revokeObjectURL=original;}
});

test('support button opens a message to UniMate for student, staff, seller and organisation accounts',async t=>{
 for(const user of [student,staff,{...student,requestedAccountType:'seller',approvalStatus:'pending'},{...student,requestedAccountType:'organisation',approvalStatus:'approved'}]){
  const h=harness({search:'#/profile',handler:path=>path==='/api/member/support'?json(list([])):json(session(user))});
  await h.mount(React.createElement(h.load('PublicWebsite.tsx').default));t.after(()=>h.unmount());
  await act(async()=>h.renderer().root.findByProps({'aria-label':'Contact UniMate Support'}).props.onClick());
  assert.match(textOf(h.renderer().toJSON()),/Contact UniMate Support/);
  assert.equal(h.window.location.hash,'#/support');
  assert.equal(findButton(h,'Send message').props.disabled,true);
  assert.ok(h.calls.every(call=>!call.options.method||call.options.method==='GET'));
 }
});

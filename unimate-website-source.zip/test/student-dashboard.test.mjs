import assert from 'node:assert/strict';
import test from 'node:test';
import { harness, student, session, json, act, deferred, React, textOf } from './frontend-harness.mjs';

const future = hours => new Date(Date.now() + hours * 3600000).toISOString();
const booking = (id, overrides = {}) => ({
  id, title: 'Fixture service request', customer: student.name, service: 'cleaning', status: 'requested',
  amount_pence: 0, pricingStatus: 'unquoted', created_at: new Date().toISOString(),
  submission: { intake: { fields: [{ label: 'Requested date', value: future(48).slice(0, 10) }] } },
  assignment: null, photos: [], ...overrides,
});
const assigned = (startsAt, overrides = {}) => ({
  member_id: 'fixture-staff', name: 'Fixture staff', team: 'cleaners',
  starts_at: startsAt, ends_at: future(96), ...overrides,
});
const bookingShortcut = h => h.renderer().root.findByProps({ className: 'student-shortcuts' }).findAllByType('button')[0];
async function mountDashboard(h, navigate = () => {}) {
  const { StudentDashboard } = h.load('StudentDashboard.tsx');
  await h.mount(React.createElement(StudentDashboard, { navigate }));
}

test('an unconfirmed service request is not presented as an upcoming confirmed booking', async t => {
  const row = booking('request-a', { assignment: assigned(future(24)) });
  const h = harness({ handler: path => path.endsWith('/session') ? json(session(student)) : json({ rows: [row] }) });
  await mountDashboard(h); t.after(() => h.unmount());
  const shortcut = textOf(bookingShortcut(h));
  assert.ok(shortcut.includes('View your requests')); assert.ok(!shortcut.includes('Cleaning'));
  assert.equal(bookingShortcut(h).findAllByType('small').length, 1, 'an unconfirmed requested date is not displayed as a confirmed appointment');
  const text = textOf(h.renderer().toJSON());
  assert.ok(text.includes('Hello, Test'));
  for (const demo of ['Sophie', 'River Cruise', 'Student verified', 'Movie Night']) assert.ok(!text.includes(demo), demo);
});

test('next booking chooses the earliest future confirmed assignment and excludes completed or unscheduled records', async t => {
  const h = harness({ handler: path => path.endsWith('/session') ? json(session(student)) : json({ rows: [
    booking('completed', { status: 'completed', pricingStatus: 'confirmed', assignment: assigned(future(1)), service: 'moving' }),
    booking('unassigned', { status: 'confirmed', pricingStatus: 'confirmed', service: 'moving' }),
    booking('past', { status: 'confirmed', pricingStatus: 'confirmed', assignment: assigned(future(-24)), service: 'moving' }),
    booking('later', { status: 'confirmed', pricingStatus: 'confirmed', assignment: assigned(future(72)), service: 'moving' }),
    booking('next', { status: 'confirmed', pricingStatus: 'confirmed', assignment: assigned(future(24)), service: 'airport_transfer' }),
  ] }) });
  const navigated = []; await mountDashboard(h, route => navigated.push(route)); t.after(() => h.unmount());
  assert.ok(textOf(bookingShortcut(h)).includes('Airport transfer')); assert.ok(!textOf(bookingShortcut(h)).includes('Moving'));
  assert.equal(bookingShortcut(h).findAllByType('small').length, 2);
  await act(async () => bookingShortcut(h).props.onClick()); assert.deepEqual(navigated, ['bookings']);
});

test('changing accounts immediately clears the booking summary and an old response cannot repopulate it', async t => {
  const oldResponse = deferred(), nextResponse = deferred();
  let account = student, lists = 0, csrf = 'first-session-csrf';
  const second = { ...student, id: 'student-b', name: 'Second Student', email: 'second@example.invalid' };
  const oldBooking = booking('first-private-booking', { status: 'confirmed', pricingStatus: 'confirmed', service: 'airport_transfer', assignment: assigned(future(48)) });
  const h = harness({ handler: path => {
    if (path.endsWith('/session')) return json(session(account, { csrf }));
    lists++;
    return lists === 1 ? json({ rows: [oldBooking] }) : lists === 2 ? oldResponse.promise : nextResponse.promise;
  } });
  await mountDashboard(h); t.after(() => h.unmount());
  assert.ok(textOf(bookingShortcut(h)).includes('Airport transfer'));
  // Change the confirmed session token to trigger an account-scoped refresh.
  await act(async () => {
    csrf = 'renewed-session-csrf';
    await h.current().refreshSession();
  });
  assert.ok(textOf(bookingShortcut(h)).includes('Checking your bookings'));
  await act(async () => { account = second; await h.current().refreshSession(); });
  assert.ok(textOf(h.renderer().toJSON()).includes('Hello, Second'));
  assert.ok(!textOf(bookingShortcut(h)).includes('Airport transfer'));
  await act(async () => oldResponse.resolve(json({ rows: [oldBooking] })));
  assert.ok(textOf(bookingShortcut(h)).includes('Checking your bookings'));
  assert.ok(!textOf(bookingShortcut(h)).includes('Airport transfer'));
  await act(async () => nextResponse.resolve(json({ rows: [] })));
  assert.ok(textOf(bookingShortcut(h)).includes('No upcoming bookings'));
  assert.equal(h.calls.filter(call => call.url.endsWith('/bookings'))[1].options.signal.aborted, true);
});

test('a booking fetch failure never restores demo details, and support stays reachable through dashboard search', async t => {
  const h = harness({ handler: path => path.endsWith('/session') ? json(session(student)) : json({ error: 'Offline fixture' }, 503) });
  const navigated = []; await mountDashboard(h, route => navigated.push(route)); t.after(() => h.unmount());
  assert.ok(textOf(bookingShortcut(h)).includes('Open your bookings'));
  assert.equal(bookingShortcut(h).findAllByType('small').length, 1);
  const search = h.renderer().root.findByProps({ type: 'search' });
  await act(async () => search.props.onChange({ target: { value: 'support' } }));
  const results = h.renderer().root.findByProps({ className: 'student-search-results' });
  const support = results.findAllByType('button').find(button => textOf(button).includes('Support'));
  assert.ok(support); await act(async () => support.props.onClick());
  assert.deepEqual(navigated, ['support']);
});

test('dashboard and owner layout preview keep services without fictional events',async t=>{
 const h=harness({handler:path=>path.endsWith('/session')?json(session(student)):json({rows:[]})});
 const {StudentDashboard}=h.load('StudentDashboard.tsx');await h.mount(React.createElement(StudentDashboard,{navigate(){}}));t.after(()=>h.unmount());
 const root=h.renderer().root;assert.equal(root.findByProps({className:'student-service-grid'}).findAllByType('button').length,6);
 for(const title of ['Cleaning Services','Student Moves','Student Marketplace','Places & Reviews','Featured events','Your space','My bookings','My events','My marketplace','Support'])assert.ok(textOf(root).includes(title),title);
 assert.deepEqual(root.findAllByType('h2').map(node=>textOf(node)).filter(title=>!title.includes('New friends')), ['Upcoming Stuff','Your space','What do you need today?','Featured events']);
 assert.ok(!textOf(root).includes('Thames River Cruise'));
 await h.update(React.createElement(StudentDashboard,{navigate(){},layoutPreview:true}));
 assert.ok(!textOf(h.renderer().toJSON()).includes('Thames River Cruise'));
 assert.ok(!textOf(h.renderer().toJSON()).includes('£25'));
});

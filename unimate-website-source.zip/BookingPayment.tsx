import {useUiText,useUiLocale} from './useUiText';
import React, {useEffect, useRef, useState} from 'react';
import {useAuth} from './auth';
import {apiMessage} from './member-api';

type Payment={orderId:string;status:string;amountPence:number;currency:'gbp';mode:'test'};
const labels:Record<string,string>={creating:'Preparing checkout',open:'Awaiting test payment',processing:'Test payment processing',paid:'Test payment confirmed',expired:'Checkout expired',failed:'Test payment needs review'};
export function BookingPayment({bookingId,bookingStatus,quoted}:{bookingId:string;bookingStatus:string;quoted:boolean}){
 const ui=useUiText();const locale=useUiLocale();
  const {user,request,sessionVersion}=useAuth();
  const [config,setConfig]=useState<{enabled:boolean;mode:string}|null>(null);
  const [payment,setPayment]=useState<Payment|null>(null);
  const [error,setError]=useState(''),[busy,setBusy]=useState(false),[refresh,setRefresh]=useState(0);
  const generation=useRef(0),checkoutRequest=useRef<AbortController|null>(null);
  useEffect(()=>{
    generation.current++;setBusy(false);
    return()=>{generation.current++;checkoutRequest.current?.abort();checkoutRequest.current=null;};
  },[user?.id,sessionVersion,bookingId]);
  useEffect(()=>{
    const controller=new AbortController();let current=true;
    setConfig(null);setPayment(null);setError('');
    void Promise.all([request<{enabled:boolean;mode:string}>('/api/member/payments/config',{signal:controller.signal}),request<{payment:Payment|null}>(`/api/member/bookings/${encodeURIComponent(bookingId)}/payment`,{signal:controller.signal})]).then(([settings,result])=>{if(current){setConfig(settings);setPayment(result.payment);}}).catch(problem=>{if(current&&!controller.signal.aborted)setError(apiMessage(problem));});
    return ()=>{current=false;controller.abort();};
  },[user?.id,sessionVersion,request,bookingId,refresh]);
  async function checkout(){
    if(busy||!user)return;
    const current=generation.current,controller=new AbortController();
    checkoutRequest.current=controller;setBusy(true);setError('');
    try{
      const data=await request<{url:string;mode:string}>(`/api/member/bookings/${encodeURIComponent(bookingId)}/checkout`,{method:'POST',body:{},signal:controller.signal});
      if(current!==generation.current||controller.signal.aborted)return;
      const url=new URL(data.url);
      if(data.mode!=='test'||url.protocol!=='https:'||url.hostname!=='checkout.stripe.com'||url.username||url.password)throw Error('Checkout could not be verified. Please contact support.');
      window.location.assign(url.href);
    }catch(problem){if(current===generation.current&&!controller.signal.aborted)setError(apiMessage(problem));}
    finally{if(checkoutRequest.current===controller)checkoutRequest.current=null;if(current===generation.current)setBusy(false);}
  }
  const canPay=config?.enabled&&quoted&&['confirmed','assigned'].includes(bookingStatus)&&(!payment||['open','creating','expired'].includes(payment.status));
  return <section className="booking-photo-section"><div className="booking-section-heading"><h3>{ui("Payment")}</h3><button type="button" className="fresh-text-button" disabled={busy} onClick={()=>setRefresh(value=>value+1)}>{ui("Refresh status")}</button></div>
    {config&&!config.enabled&&<p className="fresh-muted">{ui("Online payments are not connected yet. No payment is taken in this local setup.")}</p>}
    {config?.enabled&&<p className="fresh-notice">{ui("Stripe test mode · Use test payment details only. No real money is taken.")}</p>}
    {payment&&<p role="status"><strong>{ui(labels[payment.status])||ui("Payment under review")}</strong> · {new Intl.NumberFormat(locale,{style:'currency',currency:'GBP'}).format(payment.amountPence/100)}</p>}
    {canPay&&<button type="button" className="fresh-button" disabled={busy} onClick={()=>void checkout()}>{busy?ui("Opening secure checkout…"):payment&&payment.status!=='expired'?ui("Continue test checkout"):ui("Pay with Stripe · test")}</button>}
    {error&&<p className="fresh-error" role="alert">{ui(error)}</p>}
  </section>;
}

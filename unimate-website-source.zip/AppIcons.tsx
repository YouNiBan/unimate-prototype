import React from 'react';
import { Image, View } from 'react-native';
import Svg, { Path, type SvgProps } from 'react-native-svg';
import paths from './assets/icons/ionicons-paths.json';

type IconProps = Omit<SvgProps, 'color'> & {
  name: keyof typeof paths;
  size?: number;
  color?: string;
};

// These outlines are extracted from the app's original Ionicons font.
// SVG keeps the exact artwork without relying on a font download at runtime.
export function AppIonicons({ name, size = 24, color = '#000000', ...props }: IconProps) {
  return <Svg {...props} width={size} height={size} viewBox="0 0 512 512" color={color} fill="none">
    <Path d={paths[name]} transform="translate(0 448) scale(1 -1)" fill={color} />
  </Svg>;
}

// The original mobile Moments mark, using the same logo crop as the student app.
export function UniMateMomentsIcon({ size = 26, active = true }: { size?: number; active?: boolean }) {
  const scale = size / 26;
  return <View style={{ width: size, height: size, overflow: 'hidden' }}><Image source={require('./assets/unimate-logo.png')} resizeMode="contain" style={{ position: 'absolute', width: 88 * scale, height: 35 * scale, left: -3 * scale, top: -4 * scale, ...(!active ? { tintColor: '#71839B' } : {}) }}/></View>;
}

// Reuse the mobile header's dark treatment: white lettering with the original
// blue/green mark restored in a clipped overlay.
export function UniMateLogo({ darkMode = false }: { darkMode?: boolean }) {
  return <div className={'unimate-brand-logo' + (darkMode ? ' is-dark' : '')}>
    <Image source={require('./assets/unimate-logo.png')} accessibilityLabel="UniMate 优你伴" style={{ width: '100%', height: '100%' }} resizeMode="contain"/>
    {darkMode && <div className="unimate-brand-colour" aria-hidden="true"><Image source={require('./assets/unimate-logo.png')} style={{ width: '100%', height: '100%' }} resizeMode="contain"/></div>}
  </div>;
}

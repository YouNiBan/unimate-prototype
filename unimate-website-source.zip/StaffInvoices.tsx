import {useUiText,useUiLocale} from './useUiText';
import React,{useEffect,useState} from 'react';
import {useAuth} from './auth';
import {apiMessage} from './member-api';
type StaffInvoiceRow={bookingId:string;title:string;service:string;jobDate:string;completedAt:string;workStatus:string;reviewReason:string;invoice:null|{id:string;reference:string;revision:number;status:string;amountPence:number;currency:'GBP';billTo:'UniMate';issuedAt:string;reviewReason:string}};
const labels:Record<string,string>={pending:'Work awaiting review',changes_requested:'Changes requested',approved:'Work approved',awaiting_invoice_review:'Invoice awaiting review',approved_for_payment:'Invoice approved · payment pending'};
export function StaffInvoices(){
 const ui=useUiText();const locale=useUiLocale();
  const {user,request}=useAuth();
  const [rows,setRows]=useState<StaffInvoiceRow[]>([]),[page,setPage]=useState(1),[total,setTotal]=useState(0),[pageSize,setPageSize]=useState(25),[loading,setLoading]=useState(true),[error,setError]=useState(''),[refresh,setRefresh]=useState(0);
  useEffect(()=>{setPage(1);setRows([]);},[user?.id]);
  useEffect(()=>{
    const controller=new AbortController();let current=true;setLoading(true);setError('');setRows([]);
    void request<{rows:StaffInvoiceRow[];total:number;pageSize:number}>(`/api/member/staff-invoices?page=${page}`,{signal:controller.signal}).then(data=>{if(current){setRows(data.rows);setTotal(data.total);setPageSize(data.pageSize);}}).catch(problem=>{if(current&&!controller.signal.aborted)setError(apiMessage(problem));}).finally(()=>{if(current)setLoading(false);});
    return()=>{current=false;controller.abort();};
  },[user?.id,request,page,refresh]);
  return <><div className="fresh-page-heading"><p className="fresh-eyebrow">{ui("STAFF WORKSPACE")}</p><h1>{ui("My invoices")}</h1><p className="fresh-muted">{ui("Completed jobs are reviewed by UniMate before your invoice is approved for payment.")}</p><button className="fresh-text-button" disabled={loading} onClick={()=>setRefresh(value=>value+1)}>{ui("Refresh")}</button></div>
    <p className="fresh-notice">{ui("Invoice approval does not mean payment has been sent. Staff payments are not connected yet.")}</p>
    {loading&&<p role="status">{ui("Loading invoices…")}</p>}{error&&<p className="fresh-error" role="alert">{ui(error)}</p>}
    {!loading&&!error&&!rows.length&&<section className="booking-panel"><h2>{ui("No completed jobs to review yet")}</h2><p className="fresh-muted">{ui("Finish an assigned job to start the work and invoice review process.")}</p></section>}
    {rows.map(row=><section className="booking-panel" key={row.bookingId}><div className="booking-section-heading"><h2>{row.title}</h2><span className="booking-status">{ui(labels[row.invoice?.status||row.workStatus])||row.workStatus}</span></div><dl className="booking-facts"><div><dt>{ui("Booking reference")}</dt><dd>{row.bookingId}</dd></div><div><dt>{ui("Work completed")}</dt><dd>{new Date(row.completedAt).toLocaleDateString(locale)}</dd></div>{row.invoice&&<><div><dt>{ui("Invoice")}</dt><dd>{row.invoice.reference}  {ui("· revision")} {row.invoice.revision}</dd></div><div><dt>{ui("Billed to")}</dt><dd>UniMate</dd></div><div><dt>{ui("Agreed staff fee")}</dt><dd>{new Intl.NumberFormat(locale,{style:'currency',currency:'GBP'}).format(row.invoice.amountPence/100)}</dd></div></>}</dl>{(row.invoice?.reviewReason||row.reviewReason)&&<p className="fresh-notice">{ui("Review note:")} {row.invoice?.reviewReason||row.reviewReason}</p>}</section>)}
    {total>pageSize&&<div className="fresh-actions"><button className="fresh-button fresh-secondary" disabled={loading||page===1} onClick={()=>setPage(value=>value-1)}>{ui("Previous")}</button><span>{ui("Page")} {page}</span><button className="fresh-button fresh-secondary" disabled={loading||page*pageSize>=total} onClick={()=>setPage(value=>value+1)}>{ui("Next")}</button></div>}
  </>;
}

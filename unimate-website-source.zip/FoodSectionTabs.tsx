import React from 'react';
import {useUiText} from './useUiText';
import {AppIonicons} from './AppIcons';
export function FoodSectionTabs({active,onExplore,onLeaderboard}:{active:'places'|'leaderboard';onExplore:()=>void;onLeaderboard:()=>void}){
 const ui=useUiText();
 return <div className="prototype-food-section-tabs" role="tablist" aria-label={ui('Restaurants & Activities navigation')}>
  <button role="tab" aria-selected={active==='places'} onClick={onExplore}><AppIonicons name="restaurant-outline" size={17} color="currentColor"/>{ui('Restaurants & Activities')}</button>
  <button role="tab" aria-selected={active==='leaderboard'} onClick={onLeaderboard}><AppIonicons name="trophy-outline" size={17} color="currentColor"/>{ui('Leaderboard')}</button>
 </div>;
}

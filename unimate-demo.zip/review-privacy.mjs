export const publicReviewSql=(alias='r')=>`NOT EXISTS(SELECT 1 FROM restaurant_review_visibility rv WHERE rv.review_id=${alias}.id AND rv.visibility<>'public')`;
export function ensureReviewPrivacy(db){db.exec(`CREATE TABLE IF NOT EXISTS restaurant_review_visibility(review_id TEXT PRIMARY KEY REFERENCES restaurant_student_reviews(id) ON DELETE CASCADE,visibility TEXT NOT NULL CHECK(visibility IN ('public','friends','private')));`);}
export function canReadReview(db,row,viewer){
 if(row.user_id===viewer)return true;
 const has=name=>!!db.prepare("SELECT 1 FROM sqlite_master WHERE name=?").get(name);
 if(has('member_blocks')&&db.prepare('SELECT 1 FROM member_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?)').get(viewer,row.user_id,row.user_id,viewer))return false;
 const visibility=db.prepare('SELECT visibility FROM restaurant_review_visibility WHERE review_id=?').get(row.id)?.visibility||'public';
 if(visibility==='public')return true;
 if(visibility==='private')return false;
 if(db.prepare("SELECT 1 FROM student_connections WHERE status='accepted' AND ((sender_id=? AND recipient_id=?) OR (sender_id=? AND recipient_id=?))").get(viewer,row.user_id,row.user_id,viewer))return true;
 return has('member_follows')&&!!db.prepare('SELECT 1 FROM member_follows a JOIN member_follows b ON b.follower_id=a.followed_id AND b.followed_id=a.follower_id WHERE a.follower_id=? AND a.followed_id=?').get(viewer,row.user_id);
}

import {randomUUID} from 'node:crypto';
import {transaction, audit} from './database.mjs';
import {digest, hashPassword} from './security.mjs';
import {memberPasswordValid} from './public/member-password-policy.mjs';

const fail=(status,message)=>{throw Object.assign(new Error(message),{status});};
export function createAdminAccess(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS admin_access_requests(
    id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE COLLATE NOCASE, name TEXT NOT NULL,
    password_hash TEXT, reason TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending'
      CHECK(status IN ('pending','approved','rejected')),
    created_at TEXT NOT NULL, reviewed_at TEXT, reviewed_by TEXT REFERENCES admins(id),
    review_reason TEXT, admin_id TEXT REFERENCES admins(id));`);
  let hashing=0;
  const safe='id,email,name,reason,status,created_at,reviewed_at,review_reason,admin_id';
  return {
    async request(data,address) {
      if(!db.prepare("SELECT id FROM admins WHERE role='owner' AND active=1").get())fail(503,'Admin access requests are not available yet.');
      const email=typeof data.email==='string'?data.email.trim().toLowerCase():'';
      const name=typeof data.name==='string'?data.name.trim():'';
      const reason=typeof data.reason==='string'?data.reason.trim():'';
      if(email.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))fail(400,'Enter a valid email address.');
      if(name.length<2||name.length>80||reason.length<5||reason.length>500)fail(400,'Enter your name and why you need admin access (5–500 characters).');
      if(!memberPasswordValid(data.password))fail(400,'Use 10–128 characters, including uppercase and lowercase letters, a number and a special character.');
      if(data.password!==data.confirmPassword)fail(400,'Passwords do not match.');
      const now=Date.now(), keys=['admin-request-ip:'+address,'admin-request-email:'+digest(email)];
      db.prepare('DELETE FROM login_limits WHERE expires<?').run(now);
      if(keys.some(key=>(db.prepare('SELECT count FROM login_limits WHERE key=?').get(key)?.count||0)>=5))fail(429,'Too many requests. Try again in 15 minutes.');
      if(hashing>=2)fail(429,'Please try again shortly.');
      for(const key of keys)db.prepare('INSERT INTO login_limits VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1').run(key,now+15*60*1000);
      hashing++;let hash;try{hash=await hashPassword(data.password);}finally{hashing--;}
      transaction(db,()=>{
        // A repeat request never replaces somebody else's pending credentials.
        if(db.prepare('SELECT id FROM admins WHERE lower(email)=?').get(email)||db.prepare('SELECT id FROM admin_access_requests WHERE email=? COLLATE NOCASE').get(email))return;
        const id=randomUUID();
        db.prepare('INSERT INTO admin_access_requests(id,email,name,password_hash,reason,created_at) VALUES(?,?,?,?,?,?)').run(id,email,name,hash,reason,new Date().toISOString());
        audit(db,null,'admin_access.requested','admin_access_requests',id,null,{status:'pending'},'Admin access requested');
      });
      return {ok:true,message:'Your request has been received. You can sign in only after the UniMate Owner verifies and approves your access. If you already have an account or a pending request, it has not been changed.'};
    },
    list(actor) {
      if(actor?.role!=='owner')fail(403,'Only UniMate Owner can review admin access requests.');
      return {rows:db.prepare(`SELECT ${safe} FROM admin_access_requests ORDER BY status='pending' DESC,created_at DESC LIMIT 100`).all()};
    },
    review(actor,session,id,data) {
      if(actor?.role!=='owner')fail(403,'Only UniMate Owner can review admin access requests.');
      if(!['approve','reject'].includes(data.action))fail(400,'Choose approve or reject.');
      const reason=typeof data.reason==='string'?data.reason.trim():'';
      if(reason.length<5||reason.length>500)fail(400,'Enter a review reason (5–500 characters).');
      if(data.action==='approve'&&data.identityVerified!==true)fail(400,'Verify the applicant’s identity and email with them before approval.');
      return transaction(db,()=>{
        const owner=db.prepare('SELECT role,active FROM admins WHERE id=?').get(actor.id);
        const currentSession=db.prepare('SELECT expires FROM sessions WHERE token_hash=?').get(session.token_hash);
        if(owner?.role!=='owner'||!owner.active||!currentSession||currentSession.expires<=Date.now())fail(403,'Your access changed. Sign in again.');
        const row=db.prepare('SELECT * FROM admin_access_requests WHERE id=?').get(id);
        if(!row)fail(404,'Request not found.');
        if(row.status!=='pending')fail(409,'This request has already been reviewed.');
        let adminId=null;
        if(data.action==='approve'){
          if(db.prepare('SELECT id FROM admins WHERE lower(email)=?').get(row.email))fail(409,'An account with this email already exists.');
          adminId=randomUUID();
          // Public requests can only become regular Admins. Role promotion stays Owner-only.
          db.prepare("INSERT INTO admins VALUES(?,?,?,?,'admin',1)").run(adminId,row.email,row.name,row.password_hash);
        }
        const status=data.action==='approve'?'approved':'rejected';
        db.prepare('UPDATE admin_access_requests SET status=?,password_hash=NULL,reviewed_at=?,reviewed_by=?,review_reason=?,admin_id=? WHERE id=?').run(status,new Date().toISOString(),actor.id,reason,adminId,id);
        audit(db,actor,'admin_access.'+status,'admin_access_requests',id,{status:'pending'},{status,adminId,role:adminId?'admin':null,identityVerified:data.identityVerified===true},reason);
        return {ok:true,status,admin:adminId?{id:adminId,name:row.name,email:row.email,role:'admin',active:1}:null};
      });
    },
  };
}

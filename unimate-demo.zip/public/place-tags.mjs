import {translateCurrent as t} from './ui-i18n.mjs';
export function placeTags({initial=[],options=[],onChange}){
 let selected=[...new Set(initial.filter(Boolean))].slice(0,8);
 const root=document.createElement('section'),title=document.createElement('h3'),hint=document.createElement('p'),chips=document.createElement('div'),details=document.createElement('details'),summary=document.createElement('summary'),choices=document.createElement('div'),custom=document.createElement('input'),add=document.createElement('button');
 title.textContent=t('Categories & tags');hint.textContent=t('Choose up to 8. The first two appear on the card; all appear on the place page.');summary.textContent=t('Choose tags');custom.placeholder=t('Add your own tag');custom.setAttribute('aria-label',t('Add your own tag'));custom.maxLength=80;add.type='button';add.textContent=t('Add tag');
 root.append(title,hint,chips,details);details.append(summary,choices,custom,add);
 function draw(){chips.replaceChildren();choices.replaceChildren();for(const tag of selected){const b=document.createElement('button');b.type='button';b.textContent=t(tag)+' ×';b.setAttribute('aria-label',t('Remove tag')+': '+t(tag));b.onclick=()=>{selected=selected.filter(x=>x!==tag);draw();};chips.append(b);}
  for(const tag of [...new Set([...options,...selected])]){const label=document.createElement('label'),check=document.createElement('input');label.className='scope-checkbox';check.type='checkbox';check.checked=selected.includes(tag);check.disabled=selected.length>=8&&!check.checked;check.onchange=()=>{selected=check.checked?[...selected,tag]:selected.filter(x=>x!==tag);draw();};label.append(check,document.createTextNode(t(tag)));choices.append(label);}onChange([...selected]);
 }
 add.onclick=()=>{const tag=custom.value.trim();if(tag&&selected.length<8&&!selected.some(x=>x.toLowerCase()===tag.toLowerCase())){selected.push(tag);custom.value='';draw();}};
 custom.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();add.click();}};
 draw();return {root,get:()=>[...selected],reset(nextOptions){selected=[];options=nextOptions;draw();}};
}

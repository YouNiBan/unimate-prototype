import {translateCurrent as t} from './ui-i18n.mjs';
export function addressSearch({api,fields,form,priceBand}){
 const root=document.createElement('section'),label=document.createElement('label'),input=document.createElement('input'),results=document.createElement('div'),status=document.createElement('p');
 label.textContent=t('Find a place or address');input.placeholder=t('Restaurant name, postcode or address');input.autocomplete='off';input.maxLength=200;label.append(input);root.append(label,results,status);form.prepend(root);status.setAttribute('role','status');
 let generation=0,timer,available=false;
 api('address-search').then(r=>{available=r.configured;root.hidden=!available;}).catch(()=>{root.hidden=true;});
 input.oninput=()=>{clearTimeout(timer);const current=++generation;results.replaceChildren();status.textContent='';if(!available||input.value.trim().length<3)return;
  timer=setTimeout(async()=>{try{const data=await api('address-search/search',{query:input.value});if(current!==generation||!root.isConnected)return;
   for(const item of data.suggestions){const option=document.createElement('button');option.type='button';option.textContent=item.label;option.style.cssText='display:block;width:100%;text-align:left;margin:6px 0;min-height:44px';
    option.onclick=async()=>{const selected=++generation;results.replaceChildren();status.textContent=t('Loading address…');try{const place=await api('address-search/resolve',{id:item.id});if(selected!==generation||!root.isConnected)return;for(const key of ['address','city','postcode','phone','website'])if(place[key])fields[key].value=place[key];if(place.name)fields.name.value=place.name;if(place.priceBand&&priceBand)priceBand.value=place.priceBand;status.textContent=t('Available details filled in. Check the address, phone, website and price category; complete any missing fields.');}catch(e){if(selected===generation)status.textContent=t(e.message);}};results.append(option);
   }
   const attribution=document.createElement('small');attribution.textContent='Google Maps';results.append(attribution);if(!data.suggestions.length)status.textContent=t('No matching places. Enter the address manually.');
  }catch(e){if(current===generation)status.textContent=t(e.message);}},450);
 };
}

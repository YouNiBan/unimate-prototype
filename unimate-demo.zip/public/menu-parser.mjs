// Suggestions remain editable and require human review before publication.
const clean = value => String(value).normalize('NFKC').replace(/(?<=\p{Script=Han})\s+(?=\p{Script=Han})/gu,'').replace(/\s+/g,' ').trim();
const numbered = /^\s*(?:[Ss][Kk]\s*)?\d{1,3}[.)]?\s+/;
const money = /(?:£\s*|GBP\s*)?(\d{1,3}[.,]\d{2})(?!\d)/g;
const nameClean = value => clean(value.replace(numbered,'').replace(/[.·…_]{2,}.*$/u,'').replace(/[.·…\s:—-]+$/u,''));
function key(item){
 const name=clean(item.name).toLowerCase();
 // Use complete Latin names where available, so bilingual versions match.
 const latin=name.replace(/[\p{Script=Han}]+/gu,' ').replace(/[^a-z0-9]+/g,' ').trim();
 return (latin.length>5?latin:name.replace(/[^\p{L}\p{N}]+/gu,''))+(name.match(/\(per [^)]+\)$/)?.[0]||'');
}
export function mergeMenuItems(existing,incoming,{pricePolicy='review'}={}){
 const result=existing.map(i=>({...i})),index=new Map(result.map((i,n)=>[key(i),n]));
 for(const candidate of incoming){const k=key(candidate);if(!k)continue;const found=index.get(k);
  if(found===undefined){if(result.length<200){index.set(k,result.length);result.push({...candidate});}continue;}
  const item=result[found];
  if(!/\p{Script=Han}/u.test(item.name)&&/\p{Script=Han}/u.test(candidate.name))item.name=candidate.name;
  if(item.pricePence!==candidate.pricePence){const values=[...(item._prices||[]),item.pricePence,candidate.pricePence].filter(Number.isInteger);item._prices=[...new Set(values)];item._warning='Different prices found. Check the original menu photos.';item.pricePence=pricePolicy==='higher'&&values.length?Math.max(...values):null;}
 }
 return result;
}
export function parseMenuText(text){
 const items=[];let pending='',category='';
 for(const raw of String(text).split(/\r?\n/)){
  const line=clean(raw);if(/^(MENU|PRICE LIST)$/i.test(line)){pending='';continue;}if(!line){pending='';continue;}
  if(/^(?:AUTHENTIC\s+)?(?:SEAFOOD DISHES|VEGETABLE DISHES|MEAT DISHES|COLD STARTER DISHES|DRY POT|MAIN|SOUP|DESSERT|BBQ GRILL)[\s\p{Script=Han}]*$/iu.test(line)){category=line.slice(0,80);pending='';continue;}
  if(numbered.test(line))pending='';
  const matches=[...line.matchAll(money)];
  if(!matches.length){if(/price unclear|unreadable/i.test(line)){pending='';continue;}if(line.length<220&&!/^(?:all |two to |[£\d\s.,/-]+$)/i.test(line))pending=(pending+' '+line).trim().slice(-300);continue;}
  const prefix=line.slice(0,matches[0].index);
  const name=nameClean((pending?pending+' ':'')+prefix);pending='';
  if(name.length<2||!/[\p{L}]/u.test(name))continue;
  // More than one price without explicit portions is ambiguous (often joined columns).
  const variants=matches.map((m,n)=>({m,unit:clean(line.slice(m.index+m[0].length,matches[n+1]?.index??line.length).replace(/^[.\s]+|[.\s]+$/g,''))}));
  if(variants.length>1&&variants.some(v=>!/^\/\s*(?:\d+\s*)?(?:串|份|skewers?|portions?)$/i.test(v.unit))){items.push({name:name.slice(0,180),category,description:'',pricePence:null,_warning:'Multiple prices or columns found. Check this item.'});continue;}
  for(const {m,unit} of variants){
   const validUnit=/^\/\s*(?:\d+\s*)?(?:串|份|skewers?|portions?)$/i.test(unit);
   const suffix=validUnit?' ('+unit.replace(/^\/\s*/,'per ')+')':'';
   const trailing=unit&&!validUnit;
   items.push({name:(name+suffix).slice(0,180),category,description:'',pricePence:trailing?null:Math.round(Number(m[1].replace(',','.'))*100),...(trailing?{_warning:'The price or portion is unclear. Check the photo.'}:{})});
  }
  if(items.length>=200)break;
 }
 return mergeMenuItems([],items);
}
export function parseMenuOcr(data){
 const groups=(data.blocks||[]).flatMap(b=>(b.paragraphs||[]).map(p=>p));
 if(!groups.length)return parseMenuText(data.text||'').map(i=>({...i,pricePence:null,_warning:'Recognition confidence is unavailable. Check the name and enter the price.'}));
 const items=[];
 for(const group of groups){
  const parsed=parseMenuText(group.text||'');
  const words=(group.lines||[]).flatMap(l=>l.words||[]);
  for(const item of parsed){
   const price=item.pricePence;
   const priceWords=words.filter(w=>[...String(w.text).matchAll(money)].some(m=>Math.round(Number(m[1].replace(',','.'))*100)===price));
   if(price!==null&&(!priceWords.length||priceWords.some(w=>w.confidence<85))){item.pricePence=null;item._warning='Price recognition is uncertain. Enter it from the photo.';}
   if(group.confidence<75)item._warning=(item._warning?item._warning+' ':'')+'Check the bilingual dish name carefully.';
   items.push(item);
  }
 }
 return mergeMenuItems([],items);
}

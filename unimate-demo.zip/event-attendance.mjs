import {randomUUID} from 'node:crypto';
const fail=(status,message)=>{throw Object.assign(new Error(message),{status});};
export function createEventAttendance(db,{now=Date.now}={}){
 db.exec(`CREATE TABLE IF NOT EXISTS member_event_options(event_id TEXT PRIMARY KEY REFERENCES member_events(id),admission TEXT NOT NULL CHECK(admission IN ('first_come','host_select')));
 CREATE TABLE IF NOT EXISTS member_event_interest(event_id TEXT NOT NULL REFERENCES member_events(id),user_id TEXT NOT NULL REFERENCES users(id),created_at TEXT NOT NULL,PRIMARY KEY(event_id,user_id));
 CREATE TABLE IF NOT EXISTS member_event_chat(id TEXT PRIMARY KEY,event_id TEXT NOT NULL REFERENCES member_events(id),user_id TEXT NOT NULL REFERENCES users(id),body TEXT NOT NULL,client_id TEXT NOT NULL,created_at TEXT NOT NULL,UNIQUE(event_id,user_id,client_id));`);
 const admission=id=>db.prepare('SELECT admission FROM member_event_options WHERE event_id=?').get(id)?.admission||'first_come';
 function extra(user,event){return {admission:admission(event.id),interested:!!db.prepare('SELECT 1 FROM member_event_interest WHERE event_id=? AND user_id=?').get(event.id,user.id),interestedCount:db.prepare("SELECT count(*) n FROM member_event_interest i JOIN users u ON u.id=i.user_id WHERE i.event_id=? AND u.status='active'").get(event.id).n};}
 function people(user,event){if(event.user_id!==user.id)fail(403,'Only the host can manage attendees.');return {rows:db.prepare("SELECT i.user_id id,COALESCE(n.username,'Student') name,EXISTS(SELECT 1 FROM member_event_reservations r WHERE r.event_id=i.event_id AND r.user_id=i.user_id) confirmed FROM (SELECT event_id,user_id,created_at FROM member_event_interest UNION SELECT event_id,user_id,created_at FROM member_event_reservations WHERE NOT EXISTS(SELECT 1 FROM member_event_interest ii WHERE ii.event_id=member_event_reservations.event_id AND ii.user_id=member_event_reservations.user_id)) i JOIN users u ON u.id=i.user_id LEFT JOIN member_usernames n ON n.user_id=i.user_id WHERE i.event_id=? AND u.status='active' ORDER BY i.created_at,i.user_id").all(event.id)};}
 function action(user,event,action,data){
  const id=event.id;
  if(event.approval_status!=='approved'||event.cancelled_at)fail(409,'This event is not open.');
  if(action==='interested'){
   if(typeof data.value!=='boolean')fail(400,'Choose whether you are interested.');
   if(data.value){if(event.event_date<new Date(now()).toISOString().slice(0,10))fail(409,'This event has ended.');db.prepare('INSERT OR IGNORE INTO member_event_interest VALUES(?,?,?)').run(id,user.id,new Date(now()).toISOString());}
   else db.prepare('DELETE FROM member_event_interest WHERE event_id=? AND user_id=?').run(id,user.id);
  } else if(action==='select-attendee'){
   if(event.user_id!==user.id||admission(id)!=='host_select')fail(403,'Only this event host can select attendees.');
   if(typeof data.confirmed!=='boolean'||typeof data.userId!=='string')fail(400,'Choose an attendee.');
   if(event.event_date<new Date(now()).toISOString().slice(0,10))fail(409,'This event has ended.');
   if(data.confirmed){
    if(event.price_pence)fail(409,'Paid ticket checkout is not connected. No paid place has been confirmed.');
    if(!db.prepare("SELECT 1 FROM member_event_interest i JOIN users u ON u.id=i.user_id WHERE i.event_id=? AND i.user_id=? AND u.status='active'").get(id,data.userId))fail(409,'This student is no longer interested.');
    if(!db.prepare('SELECT 1 FROM member_event_reservations WHERE event_id=? AND user_id=?').get(id,data.userId)){
     if(db.prepare("SELECT count(*) n FROM member_event_reservations r JOIN users u ON u.id=r.user_id WHERE r.event_id=? AND u.status='active'").get(id).n>=event.capacity)fail(409,'This event is full.');
     db.prepare('INSERT INTO member_event_reservations VALUES(?,?,?)').run(id,data.userId,new Date(now()).toISOString());
    }
   }else db.prepare('DELETE FROM member_event_reservations WHERE event_id=? AND user_id=?').run(id,data.userId);
  }else fail(400,'Choose an attendance action.');
 }
 function chat(user,event,data){
  if(event.approval_status!=='approved'||event.cancelled_at||event.user_id!==user.id&&!db.prepare('SELECT 1 FROM member_event_reservations WHERE event_id=? AND user_id=?').get(event.id,user.id))fail(403,'Event chat is only for the host and confirmed attendees.');
  if(data){
   const body=typeof data.message==='string'?data.message.trim():'';
   if(!body||body.length>2000||typeof data.clientId!=='string'||!/^[a-zA-Z0-9_-]{16,100}$/.test(data.clientId))fail(400,'Write a message of up to 2000 characters.');
   const old=db.prepare('SELECT body FROM member_event_chat WHERE event_id=? AND user_id=? AND client_id=?').get(event.id,user.id,data.clientId);
   if(old&&old.body!==body)fail(409,'This message identifier was already used.');
   if(!old){if(db.prepare('SELECT count(*) n FROM member_event_chat WHERE user_id=? AND created_at>?').get(user.id,new Date(now()-60000).toISOString()).n>=20)fail(429,'Please wait before sending more messages.');db.prepare('INSERT INTO member_event_chat VALUES(?,?,?,?,?,?)').run(randomUUID(),event.id,user.id,body,data.clientId,new Date(now()).toISOString());}
  }
  return {messages:db.prepare("SELECT m.id,m.body,m.created_at createdAt,COALESCE(n.username,'Student') author,m.user_id=? own FROM member_event_chat m JOIN users u ON u.id=m.user_id LEFT JOIN member_usernames n ON n.user_id=m.user_id WHERE m.event_id=? AND u.status='active' ORDER BY m.created_at DESC,m.rowid DESC LIMIT 100").all(user.id,event.id).reverse()};
 }
 return {admission,extra,people,action,chat};
}

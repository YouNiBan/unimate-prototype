// Only explicitly named favourite dishes count; review prose is not sentiment-mined.
export function dishNames(value) {
 if(typeof value!=='string') return [];
 const unique=new Map();
 for(const part of value.split(/[,，;；\n]+/)) {
  const name=part.trim().replace(/\s+/g,' ');
  if(name && name.length<=100) unique.set(name.normalize('NFKC').toLocaleLowerCase(),name);
 }
 return [...unique.values()].slice(0,10);
}
export function aggregateDishes(reviews,{minimumStudents=3}={}) {
 const dishes=new Map();
 for(const review of reviews) for(const name of dishNames(review.dishes)) {
  const key=name.normalize('NFKC').toLocaleLowerCase();
  if(!dishes.has(key)) dishes.set(key,{name,students:new Set(),officials:new Set()});
  const item=dishes.get(key);
  (review.official?item.officials:item.students).add(review.authorId);
 }
 return [...dishes.values()].filter(x=>x.students.size>=minimumStudents||x.officials.size>0)
 .map(x=>({name:x.name,studentCount:x.students.size,officialCount:x.officials.size}))
 .sort((a,b)=>b.studentCount-a.studentCount||b.officialCount-a.officialCount||a.name.localeCompare(b.name));
}

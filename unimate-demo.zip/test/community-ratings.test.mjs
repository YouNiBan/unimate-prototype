import test from 'node:test';
import assert from 'node:assert/strict';
import {createApplication} from '../server.mjs';
import {createRestaurantCommunity} from '../restaurant-community.mjs';
import {createRestaurants} from '../restaurants.mjs';
const png={filename:'cover.png',data:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j5ZkAAAAASUVORK5CYII='};
test('category averages preserve missing old scores, update instead of double counting, and exclude suspended students',async t=>{
 const app=await createApplication({filename:':memory:'});t.after(()=>app.db.close());const db=app.db,now=new Date().toISOString();
 db.prepare('INSERT INTO admins VALUES(?,?,?,?,?,1)').run('owner','owner@example.invalid','Owner','unused','owner');
 const id=createRestaurants(db).save({id:'owner'},{name:'Test Restaurant',address:'10 Test Road',city:'London',postcode:'SW1A 1AA',cuisine:'Chinese',category:'Restaurant',previewPhoto:png,status:'published'}).id;
 for(const user of ['a','b','c']){db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?)').run(user,user,user+'@example.invalid','student','active',now);db.prepare('INSERT INTO student_verifications VALUES(?,?,?,?)').run(user,user+'@ucl.ac.uk','UCL',now);}
 const c=createRestaurantCommunity(db),input={restaurantId:id,body:'A helpful restaurant review with enough detail.',rating:3,version:0,dishes:'Duck, duck'};
 c.saveReview({id:'a'},input);
 const ratings={taste:5,atmosphere:4,value:3,service:2,overall:4};
 c.saveReview({id:'b'},{...input,ratings});c.saveReview({id:'c'},{...input,ratings});
 let result=c.reviews(id,'a');assert.equal(result.averages.metrics.taste.count,2);assert.equal(result.averages.metrics.overall.count,3);assert.equal(result.averages.metrics.overall.average,3.7);assert.equal(result.recommendations[0].studentCount,3);
 c.saveReview({id:'b'},{...input,version:1,ratings:{...ratings,taste:1}});result=c.reviews(id,'a');assert.equal(result.averages.metrics.taste.average,3);assert.equal(result.averages.metrics.taste.count,2);
 assert.throws(()=>c.saveReview({id:'b'},{...input,version:2,ratings:{taste:5}}),{status:400});
 db.prepare("UPDATE users SET status='suspended' WHERE id='c'").run();result=c.reviews(id,'a');assert.equal(result.averages.metrics.taste.count,1);assert.deepEqual(result.recommendations,[]);
});
test('private and friends-only reviews, photos, votes and public summaries enforce audience',async t=>{
 const app=await createApplication({filename:':memory:'});t.after(()=>app.db.close());const db=app.db,now=new Date().toISOString();db.prepare('INSERT INTO admins VALUES(?,?,?,?,?,1)').run('owner','owner@example.invalid','Owner','unused','owner');
 const id=createRestaurants(db).save({id:'owner'},{name:'Privacy Restaurant',address:'10 Test Road',city:'London',postcode:'SW1A 1AA',cuisine:'Chinese',category:'Restaurant',previewPhoto:png,status:'published'}).id;
 for(const user of ['a','b','c']){db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?)').run(user,user,user+'@example.invalid','student','active',now);db.prepare('INSERT INTO member_credentials VALUES(?,?,?,?)').run(user,'unused',now,now);db.prepare('INSERT INTO student_verifications VALUES(?,?,?,?)').run(user,user+'@ucl.ac.uk','UCL',now);}
 const c=createRestaurantCommunity(db),input={restaurantId:id,body:'A private detailed review of the restaurant.',rating:5,version:0,visibility:'private',dishes:'Duck',ratings:{taste:5,atmosphere:4,value:3,service:2,overall:5},experience:'loved',visitedOn:now.slice(0,10),photos:[{group:'visit',mime:'image/png',filename:'photo.png',base64:png.data.split(',')[1]}]};
 c.saveReview({id:'a'},input);const own=c.reviews(id,'a').rows[0],photoId=own.photos[0].id;
 assert.equal(c.reviews(id,'b').rows.length,0);assert.equal(c.reviews(id,'a').averages.reviewers,0);assert.ok(c.photo(photoId,'a'));assert.throws(()=>c.photo(photoId,'b'),{status:404});assert.throws(()=>c.vote({id:'b'},{reviewId:own.id,helpful:true}),{status:404});assert.equal(c.leaderboard({id:'a'},'all').rows.length,0);
 c.saveReview({id:'a'},{...input,version:1,photos:[],visibility:'friends'});c.connect({id:'a'},{userId:'b',action:'request'});c.connect({id:'b'},{userId:'a',action:'accept'});assert.equal(c.reviews(id,'b').rows.length,1);assert.ok(c.photo(photoId,'b'));assert.equal(c.reviews(id,'c').rows.length,0);assert.equal(c.reviews(id,'b').averages.reviewers,0);
 c.connect({id:'a'},{userId:'b',action:'remove'});assert.throws(()=>c.photo(photoId,'b'),{status:404});
 c.saveReview({id:'a'},{...input,version:2,photos:[],visibility:'public'});assert.equal(c.reviews(id,'c').rows.length,1);assert.equal(c.reviews(id,'c').averages.reviewers,1);
});

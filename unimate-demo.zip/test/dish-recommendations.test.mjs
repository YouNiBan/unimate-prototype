import test from 'node:test';
import assert from 'node:assert/strict';
import {dishNames,aggregateDishes} from '../dish-recommendations.mjs';
test('dish mentions count distinct reviewers, not repetitions',()=>{
 const rows=[{authorId:'a',dishes:'Crispy duck, crispy duck'},{authorId:'a',dishes:'crispy duck'},{authorId:'b',dishes:'Crispy Duck'}];
 assert.deepEqual(aggregateDishes(rows),[]);
 const result=aggregateDishes([...rows,{authorId:'c',dishes:'crispy duck'}]);assert.equal(result.length,1);assert.equal(result[0].studentCount,3);
});
test('official picks can appear independently without pretending student consensus',()=>{
 assert.deepEqual(aggregateDishes([{authorId:'official',official:true,dishes:'奶茶'},{authorId:'a',dishes:'奶茶'}]),[{name:'奶茶',studentCount:1,officialCount:1}]);
});
test('handles bilingual separators and avoids fuzzy merging distinct dishes',()=>{
 assert.deepEqual(dishNames('烤鸭，Milk tea；Noodles\nNoodles'),['烤鸭','Milk tea','Noodles']);
 assert.equal(aggregateDishes([{authorId:'a',official:true,dishes:'Duck, Duck noodles'}]).length,2);
});

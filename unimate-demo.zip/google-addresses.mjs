// All Google traffic goes through this service. Counts persist across restarts.
// The shared ceiling includes failed requests; retries never bypass it.
const fail=(status,message)=>{throw Object.assign(new Error(message),{status});};
export function createGoogleAddresses(db,{key=process.env.GOOGLE_PLACES_API_KEY||'',enabled=process.env.GOOGLE_PLACES_ENABLED==='true',fetcher=fetch,now=()=>new Date()}={}){
 db.exec(`CREATE TABLE IF NOT EXISTS google_address_usage (period TEXT PRIMARY KEY, count INTEGER NOT NULL DEFAULT 0)`);
 function reserve(actor,business=false){
  if(!enabled||!key)fail(503,'Address suggestions are unavailable. Please enter the address manually.');
  const date=now(),day=new Intl.DateTimeFormat('en-CA',{timeZone:'America/Los_Angeles',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);
  const limits=[[`month:${day.slice(0,7)}`,2500],[`day:${day}`,100],[`user:${actor}:${day}`,40],...(business?[[`business-month:${day.slice(0,7)}`,500],[`business-day:${day}`,20]]:[])];
  db.exec('BEGIN IMMEDIATE');
  try{for(const [period,limit] of limits){const count=db.prepare('SELECT count FROM google_address_usage WHERE period=?').get(period)?.count||0;if(count>=limit)fail(429,'Address search has reached its free-use limit. Please enter the address manually.');}
   for(const [period] of limits)db.prepare('INSERT INTO google_address_usage(period,count) VALUES (?,1) ON CONFLICT(period) DO UPDATE SET count=count+1').run(period);
   db.exec('COMMIT');
  }catch(e){db.exec('ROLLBACK');throw e;}
 }
 async function call(actor,url,options,business=false){reserve(actor,business);let response;
  try{response=await fetcher(url,{...options,headers:{'Content-Type':'application/json','X-Goog-Api-Key':key,...options.headers},signal:AbortSignal.timeout(8000)});}catch{fail(503,'Address search is temporarily unavailable. Please enter the address manually.');}
  if(!response.ok)fail(503,'Address search is temporarily unavailable. Please enter the address manually.');return response.json();
 }
 return {configured:()=>enabled&&!!key,async search(actor,data){
  const query=typeof data.query==='string'?data.query.trim():'';
  if(query.length<3)return {suggestions:[]};if(query.length>200)fail(400,'Please use a shorter address search.');
  const result=await call(actor,'https://places.googleapis.com/v1/places:autocomplete',{method:'POST',headers:{'X-Goog-FieldMask':'suggestions.placePrediction.placeId,suggestions.placePrediction.text,suggestions.placePrediction.structuredFormat'},body:JSON.stringify({input:query,includedRegionCodes:['gb'],regionCode:'uk',languageCode:'en'})});
  return {suggestions:(result.suggestions||[]).flatMap(({placePrediction:p})=>p?.placeId&&p?.text?.text?[{id:p.placeId,label:p.text.text,name:p.structuredFormat?.mainText?.text||''}]:[])};
 },async resolve(actor,data,{business=false}={}){
  if(typeof data.id!=='string'||!/^[-_a-zA-Z0-9]{1,250}$/.test(data.id))fail(400,'Select an address from the suggestions.');
  const result=await call(actor,`https://places.googleapis.com/v1/places/${encodeURIComponent(data.id)}`,{method:'GET',headers:{'X-Goog-FieldMask':'id,formattedAddress,addressComponents'+(business?',displayName,types,nationalPhoneNumber,internationalPhoneNumber,websiteUri,priceLevel':'')}},business);
  const component=type=>(result.addressComponents||[]).find(c=>c.types?.includes(type))?.longText||'';
  if(component('country')!=='United Kingdom')fail(400,'Please choose an address in the United Kingdom.');
  const businessFields=business?{name:(result.types||[]).includes('establishment')?result.displayName?.text||'':'',phone:result.nationalPhoneNumber||result.internationalPhoneNumber||'',website:result.websiteUri||'',priceBand:({PRICE_LEVEL_INEXPENSIVE:'£',PRICE_LEVEL_MODERATE:'££',PRICE_LEVEL_EXPENSIVE:'£££',PRICE_LEVEL_VERY_EXPENSIVE:'££££'})[result.priceLevel]||''}:{};
  return {...businessFields,id:result.id,formattedAddress:result.formattedAddress||'',address:[component('subpremise'),component('premise'),[component('street_number'),component('route')].filter(Boolean).join(' ')].filter(Boolean).join(', '),city:component('postal_town')||component('locality'),postcode:component('postal_code')};
 }};
}

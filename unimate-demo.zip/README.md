# UniMate isolated developer demo

Generated deployment bundle. Fictional data only. Start with `node demo-server.mjs`. Set `UNIMATE_MODE=hosted`, `UNIMATE_DATA_DIR=/var/data/unimate`, and the private initial `UNIMATE_DEMO_PASSWORD_HASHES` environment value. Attach persistent storage. Never deploy live Stripe keys here.

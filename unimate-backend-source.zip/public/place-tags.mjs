import {translateCurrent as t} from './ui-i18n.mjs';
export function placeTags({initial=[],options=[],onChange}){
 let selected=[...new Set(initial.filter(Boolean))].slice(0,8);
 const extras=['Best for birthdays','Date night','Family friendly','Good for groups','Student friendly'];
 const root=document.createElement('section');root.className='place-tags';
 const title=document.createElement('h3');title.textContent=t('Categories (required)');
 const hint=document.createElement('p');hint.className='place-tags-hint';hint.textContent=t('Choose at least one. Tap again to remove.');
 const count=document.createElement('span');count.className='place-tags-count';count.setAttribute('aria-live','polite');
 const header=document.createElement('div');header.className='place-tags-header';header.append(title,count);
 const categories=document.createElement('div');categories.className='place-tags-options';categories.setAttribute('role','group');categories.setAttribute('aria-label',t('Category'));
 const extraTitle=document.createElement('h4');extraTitle.textContent=t('Good for (optional)');
 const extraChoices=document.createElement('div');extraChoices.className='place-tags-options';extraChoices.setAttribute('role','group');extraChoices.setAttribute('aria-label',t('Good for (optional)'));
 const details=document.createElement('details');details.className='place-tags-custom';
 const summary=document.createElement('summary');summary.textContent=t('Add your own tag');
 const customRow=document.createElement('div');customRow.className='place-tags-custom-row';
 const custom=document.createElement('input');custom.placeholder=t('Add your own tag');custom.setAttribute('aria-label',t('Add your own tag'));custom.maxLength=80;
 const add=document.createElement('button');add.type='button';add.textContent=t('Add tag');customRow.append(custom,add);details.append(summary,customRow);
 root.append(header,hint,categories,extraTitle,extraChoices,details);
 const buttons=new Map();
 function createChoice(tag){
  const button=document.createElement('button');button.type='button';button.className='place-tag-choice';button.setAttribute('aria-label',t(tag));
  const check=document.createElement('span');check.className='place-tag-check';check.setAttribute('aria-hidden','true');check.textContent='✓';
  const label=document.createElement('span');label.textContent=t(tag);button.append(check,label);
  button.onclick=()=>{selected=selected.includes(tag)?selected.filter(x=>x!==tag):selected.length<8?[...selected,tag]:selected;draw();};
  buttons.set(tag,button);(extras.includes(tag)?extraChoices:categories).append(button);
 }
 function draw(){
  for(const tag of [...new Set([...options,...selected])])if(!buttons.has(tag))createChoice(tag);
  for(const [tag,button] of buttons){const active=selected.includes(tag);button.setAttribute('aria-pressed',String(active));button.disabled=selected.length>=8&&!active;}
  count.textContent=selected.length+' / 8';extraTitle.hidden=extraChoices.hidden=!extraChoices.childElementCount;
  custom.disabled=add.disabled=selected.length>=8;onChange([...selected]);
 }
 add.onclick=()=>{const tag=custom.value.trim();if(tag&&selected.length<8&&!selected.some(x=>x.toLowerCase()===tag.toLowerCase())){selected.push(tag);custom.value='';draw();custom.focus();}};
 custom.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();add.click();}};
 draw();return {root,get:()=>[...selected],reset(nextOptions){selected=[];options=nextOptions;buttons.clear();categories.replaceChildren();extraChoices.replaceChildren();draw();}};
}

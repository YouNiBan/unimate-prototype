import {cuisineOptions,parseCuisines} from './cuisines.mjs';
import {translateCurrent as t} from './ui-i18n.mjs';
export function cuisinePicker({initial=[],onChange=()=>{}}={}){
 let selected=parseCuisines(initial);const options=[...new Set([...cuisineOptions,...selected])];
 const root=document.createElement('section');root.className='cuisine-picker';
 const title=document.createElement('strong');title.textContent=t('Cuisines');
 const hint=document.createElement('p');hint.className='cuisine-picker-hint';hint.textContent=t('Select all that apply. For fusion, choose each cuisine.');
 const chips=document.createElement('div');chips.className='cuisine-picker-selected';chips.setAttribute('role','group');chips.setAttribute('aria-label',t('Selected cuisines'));
 const details=document.createElement('details');const summary=document.createElement('summary');summary.textContent=t('Choose cuisines');
 const search=document.createElement('input');search.type='search';search.placeholder=t('Search cuisines');search.setAttribute('aria-label',t('Search cuisines'));search.autocomplete='off';
 const choices=document.createElement('div');choices.className='cuisine-picker-options';choices.setAttribute('role','group');choices.setAttribute('aria-label',t('Cuisine choices'));
 const empty=document.createElement('p');empty.className='cuisine-picker-hint';empty.textContent=t('No matching cuisines.');empty.hidden=true;
 details.append(summary,search,choices,empty);root.append(title,hint,chips,details);
 function drawChoices(){choices.replaceChildren();const q=search.value.trim().toLocaleLowerCase();const filtered=options.filter(v=>(v+' '+t(v)).toLocaleLowerCase().includes(q));empty.hidden=!!filtered.length;for(const value of filtered){const b=document.createElement('button');b.type='button';b.className='cuisine-picker-choice';b.textContent=(selected.includes(value)?'✓ ':'')+t(value);b.setAttribute('aria-label',t(value));b.setAttribute('aria-pressed',String(selected.includes(value)));b.disabled=selected.length>=8&&!selected.includes(value);b.onclick=()=>{selected=selected.includes(value)?selected.filter(v=>v!==value):[...selected,value];draw();[...choices.children].find(c=>c.getAttribute('aria-label')===t(value))?.focus({preventScroll:true});};choices.append(b);}}
 function draw(){chips.replaceChildren();for(const value of selected){const b=document.createElement('button');b.type='button';b.textContent=t(value)+' ×';b.setAttribute('aria-label',t('Remove cuisine')+': '+t(value));b.onclick=()=>{selected=selected.filter(v=>v!==value);draw();};chips.append(b);}drawChoices();onChange([...selected]);}
 search.oninput=drawChoices;search.onkeydown=e=>{if(e.key==='Enter')e.preventDefault();};
 draw();return {root,get:()=>[...selected],set(values){selected=parseCuisines(values);draw();}};
}

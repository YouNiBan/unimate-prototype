import {createApplication} from './server.mjs';
const app=await createApplication({filename:':memory:'});
app.server.listen(8098,'127.0.0.1',()=>console.log('Privacy preview http://127.0.0.1:8098'));
process.on('SIGTERM',()=>app.server.close(()=>{app.db.close();process.exit(0);}));

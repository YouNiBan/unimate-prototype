import test from 'node:test';
import assert from 'node:assert/strict';
import {createApplication} from '../server.mjs';
import {digest,token} from '../security.mjs';
import {decodePhoto} from '../shared-bookings.mjs';
import {decodeSupportAttachments} from '../support-chat.mjs';
import {readFile} from 'node:fs/promises';
const MB=1024*1024;
function jpeg(size){const b=Buffer.alloc(size);b.set([255,216,255]);b.set([255,217],size-2);return b;}
test('10 MB photos save and download through listing and menu HTTP routes; larger photos reject',async t=>{
 const app=await createApplication({filename:':memory:'});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));t.after(async()=>{await new Promise(r=>app.server.close(r));app.db.close();});
 const key=token();app.db.prepare('INSERT INTO admins VALUES(?,?,?,?,?,1)').run('owner','owner@example.invalid','Owner','unused','owner');app.db.prepare('INSERT INTO sessions VALUES(?,?,?,?)').run(digest(key),'owner','csrf',Date.now()+60000);
 const origin='http://127.0.0.1:'+app.server.address().port;
 const call=(path,data)=>fetch(origin+'/api/'+path,{method:data?'POST':'GET',headers:{Origin:origin,Cookie:'unimate_admin='+key,'X-CSRF-Token':'csrf','Content-Type':'application/json'},body:data?JSON.stringify(data):undefined});
 const bytes=jpeg(10*MB),photo={filename:'large.jpg',data:'data:image/jpeg;base64,'+bytes.toString('base64')};
 let response=await call('restaurants',{name:'Large photo test',status:'draft',previewPhoto:photo});assert.equal(response.status,200);const {id}=await response.json();response=await call('restaurants/'+id+'/photo');assert.equal(response.status,200);assert.deepEqual(Buffer.from(await response.arrayBuffer()),bytes);
 response=await call('restaurants/'+id+'/menu',{version:0,status:'draft',items:[],photos:[photo]});assert.equal(response.status,200);const menu=await(await call('restaurants/'+id+'/menu')).json();response=await call('restaurants/'+id+'/menu/photos/'+menu.photos[0].id);assert.equal((await response.arrayBuffer()).byteLength,10*MB);
 response=await call('restaurants',{name:'Too large',status:'draft',previewPhoto:{...photo,data:'data:image/jpeg;base64,'+jpeg(10*MB+1).toString('base64')}});assert.equal(response.status,413);
 assert.equal(app.db.prepare('SELECT count(*) n FROM restaurants').get().n,1);
});
test('booking and message decoders accept 10 MB and reject one byte over',()=>{
 for(const size of [2*MB,10*MB,10*MB+1]){const p={mime:'image/jpeg',filename:'test.jpg',base64:jpeg(size).toString('base64')};for(const run of [()=>decodePhoto(p),()=>decodeSupportAttachments([p])[0]]){if(size<=10*MB)assert.equal(run().bytes.length,size);else assert.throws(run,/10 MB/);}}
});
test('menu picker offers existing photos without forcing camera capture',async()=>{
 const source=await readFile(new URL('../public/restaurant-menu-editor.mjs',import.meta.url),'utf8');assert.ok(source.includes("files.type='file'"));assert.ok(source.includes('files.multiple=true'));assert.ok(!source.includes("setAttribute('capture'"));
});
